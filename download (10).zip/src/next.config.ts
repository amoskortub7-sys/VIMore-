import type {NextConfig} from 'next';

const nextConfig: NextConfig = {
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  experimental: {
    // This is to allow cross-origin requests from the development environment.
  },
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'placehold.co',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'images.unsplash.com',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'picsum.photos',
        port: '',
        pathname: '/**',
      },
    ],
  },
  webpack: (config) => {
    // This prevents the Next.js dev server from restarting when Genkit
    // writes to its internal .genkit directory.
    const ignored = config.watchOptions.ignored ?? [];
    config.watchOptions.ignored = [
      ...(Array.isArray(ignored) ? ignored : [ignored]),
      '**/.genkit/**',
    ];
    return config;
  },
};

export default nextConfig;
