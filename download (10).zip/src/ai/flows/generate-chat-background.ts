'use server';
/**
 * @fileOverview Generates a themed chat background using an AI image model.
 *
 * - generateChatBackground - A function that handles the background generation.
 * - GenerateChatBackgroundInput - The input type for the function.
 * - GenerateChatBackgroundOutput - The return type for the function.
 */

// AI functionality is temporarily disabled.

export type GenerateChatBackgroundInput = any;
export type GenerateChatBackgroundOutput = any;


export async function generateChatBackground(input: GenerateChatBackgroundInput): Promise<GenerateChatBackgroundOutput> {
  console.warn("AI feature 'generateChatBackground' is temporarily disabled.");
  // Return a default placeholder image
  return { imageUrl: "https://picsum.photos/seed/default-chat-bg/1080/1920" };
}
