
'use server';
/**
 * @fileOverview A secure backend flow for processing in-app currency transactions.
 *
 * - processTransaction - A function that handles deducting currency from one user and awarding it to another.
 * - ProcessTransactionInput - The input type for the processTransaction function.
 * - ProcessTransactionOutput - The return type for the processTransaction function.
 */

// This flow is a wrapper and does not use Genkit directly.
import { processCurrencyTransaction } from '@/services/monetizationService';

export type ProcessTransactionInput = any;
export type ProcessTransactionOutput = any;

// This is the exported function that the client will call.
export async function processTransaction(input: ProcessTransactionInput): Promise<ProcessTransactionOutput> {
  try {
      const result = await processCurrencyTransaction(input);
      return result;
  } catch (error: any) {
    console.error('Transaction failed:', error);
    return { success: false, message: error.message || 'An unknown error occurred.' };
  }
}
