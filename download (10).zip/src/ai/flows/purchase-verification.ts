
'use server';
/**
 * @fileOverview A secure backend flow for purchasing a verification badge.
 *
 * - purchaseVerification - Handles the logic for deducting currency and updating user status.
 * - PurchaseVerificationInput - The input type for the function.
 * - PurchaseVerificationOutput - The return type for the function.
 */

// This flow is a wrapper and does not use Genkit directly.
import { executeVerificationPurchase } from '@/services/monetizationService';

export type PurchaseVerificationInput = any;
export type PurchaseVerificationOutput = any;

export async function purchaseVerification(input: PurchaseVerificationInput): Promise<PurchaseVerificationOutput> {
  try {
    const result = await executeVerificationPurchase(input.userId);
    return result;
  } catch (error: any) {
    console.error('Verification purchase failed:', error);
    return { success: false, message: error.message || 'An unknown error occurred.' };
  }
}
