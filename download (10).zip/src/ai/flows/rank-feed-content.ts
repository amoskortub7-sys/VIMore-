'use server';
/**
 * @fileOverview Ranks a list of posts for a user's feed based on their interests and content relevance.
 *
 * - rankFeedContent - A function that returns a personalized, ranked list of posts.
 * - RankFeedContentInput - The input type for the rankFeedContent function.
 * - RankFeedContentOutput - The return type for the rankFeedContent function.
 */

// AI functionality is temporarily disabled.

export type RankFeedContentInput = any;
export type RankFeedContentOutput = any;


export async function rankFeedContent(input: RankFeedContentInput): Promise<RankFeedContentOutput> {
  console.warn("AI feature 'rankFeedContent' is temporarily disabled. Returning original post order.");
  // Fallback to returning the original, unranked order of posts.
  return { rankedPostIds: input.posts.map(p => p.id) };
}
