
'use server';

/**
 * @fileOverview A flow to generate post suggestions based on trending news or user interests.
 *
 * - generatePostSuggestions - A function that generates post suggestions.
 * - GeneratePostSuggestionsInput - The input type for the generatePostSuggestions function.
 * - GeneratePostSuggestionsOutput - The return type for the generatePostSuggestions function.
 */

// AI functionality is temporarily disabled.

export type GeneratePostSuggestionsInput = any;
export type GeneratePostSuggestionsOutput = any;

export async function generatePostSuggestions(input: GeneratePostSuggestionsInput): Promise<GeneratePostSuggestionsOutput> {
  console.warn("AI feature 'generatePostSuggestions' is temporarily disabled.");
  return { suggestions: ["Feature temporarily disabled.", "Try creating a post about your favorite hobby!"] };
}
