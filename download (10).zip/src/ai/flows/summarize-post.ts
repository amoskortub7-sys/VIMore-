'use server';

/**
 * @fileOverview Summarizes a long post or article.
 *
 * - summarizePost - A function that summarizes the post content.
 * - SummarizePostInput - The input type for the summarizePost function.
 * - SummarizePostOutput - The return type for the summarizePost function.
 */

// AI functionality is temporarily disabled.

export type SummarizePostInput = any;
export type SummarizePostOutput = any;

export async function summarizePost(input: SummarizePostInput): Promise<SummarizePostOutput> {
  console.warn("AI feature 'summarizePost' is temporarily disabled.");
  return { summary: "AI summarization is currently unavailable." };
}
