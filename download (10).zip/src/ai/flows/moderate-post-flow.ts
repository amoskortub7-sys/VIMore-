
'use server';
/**
 * @fileOverview A flow to moderate post content against community guidelines.
 *
 * - moderatePost - A function that handles the post moderation process.
 * - ModeratePostInput - The input type for the moderatePost function.
 * - ModeratePostOutput - The return type for the moderatePost function.
 */

// AI functionality is temporarily disabled.
export type ModeratePostInput = any;
export type ModeratePostOutput = any;


export async function moderatePost(input: ModeratePostInput): Promise<ModeratePostOutput> {
  console.warn("AI feature 'moderatePost' is temporarily disabled.");
  // Default to not flagging any content.
  return { isFlagged: false };
}
