
'use client';

import * as React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { AppNotification, FollowNotification, LikeNotification, CommentNotification, MentionNotification, NewReleaseNotification, WelcomeNotification, User } from '@/lib/data';
import { UserAvatar } from '@/components/user-avatar';
import { Button } from '@/components/ui/button';
import { Heart, MessageSquare, UserPlus, AtSign, Music, Sparkles, Loader2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import Image from 'next/image';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { VerifiedBadge } from '@/components/verified-badge';
import { AppContext } from '@/components/app-shell';
import { getNotifications } from '@/services/notificationService';
import NotificationsLoading from './loading';

export default function NotificationsPage() {
  const [notifications, setNotifications] = React.useState<AppNotification[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const appContext = React.useContext(AppContext);

  React.useEffect(() => {
    const fetchNotifications = async () => {
      if (!appContext?.currentUser) return;
      setIsLoading(true);
      try {
        const userNotifications = await getNotifications(appContext.currentUser.id);
        setNotifications(userNotifications);
        // In a real app, you might also have a function to mark notifications as read on the backend here.
      } catch (error) {
        console.error("Failed to fetch notifications:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchNotifications();
  }, [appContext?.currentUser]);

  const today: AppNotification[] = [];
  const thisWeek: AppNotification[] = [];
  const thisMonth: AppNotification[] = [];

  const now = new Date();
  const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const oneMonthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

  notifications.forEach(notif => {
    if (notif.timestamp >= oneWeekAgo) {
      if (notif.timestamp.getDate() === now.getDate() && notif.timestamp.getMonth() === now.getMonth() && notif.timestamp.getFullYear() === now.getFullYear()) {
        today.push(notif);
      } else {
        thisWeek.push(notif);
      }
    } else if (notif.timestamp >= oneMonthAgo) {
      thisMonth.push(notif);
    }
  });

  if (isLoading) {
    return <NotificationsLoading />;
  }

  return (
    <div className="container mx-auto max-w-2xl py-4 sm:py-6">
       <header className="mb-6">
        <h1 className="font-headline text-3xl font-bold">Notifications</h1>
      </header>
      <ScrollArea className="h-[calc(100vh-150px)]">
        <div className="space-y-6">
            {today.length > 0 && <NotificationGroup title="Today" notifications={today} />}
            {thisWeek.length > 0 && <NotificationGroup title="This Week" notifications={thisWeek} />}
            {thisMonth.length > 0 && <NotificationGroup title="This Month" notifications={thisMonth} />}
             {notifications.length === 0 && (
                <div className="text-center py-20 text-muted-foreground">
                    <p className="font-semibold">No notifications yet</p>
                    <p>When you get notifications, they'll show up here.</p>
                </div>
            )}
        </div>
      </ScrollArea>
    </div>
  );
}

function NotificationGroup({ title, notifications }: { title: string; notifications: AppNotification[] }) {
  return (
    <div>
      <h2 className="text-lg font-bold mb-2 px-4">{title}</h2>
      <div className="flex flex-col">
        {notifications.map((notif, index) => (
          <React.Fragment key={notif.id}>
            <NotificationItem notification={notif} />
            {index < notifications.length - 1 && <Separator />}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}

function NotificationItem({ notification }: { notification: AppNotification }) {
    let icon, text, link, secondaryContent;

    const postImageUrl = (notification.type === 'like' || notification.type === 'comment' || notification.type === 'mention') ? notification.post.images?.[0]?.imageUrl : null;

    const UserName = ({ user }: { user: { name: string, isVerified?: boolean }}) => (
      <span className="font-bold inline-flex items-center">
        {user.name}
        <VerifiedBadge user={user as User} />
      </span>
    );
    
    const WelcomeBody = ({ body }: { body: string }) => {
      const parts = body.split(/(\*\*.*?\*\*)/g);
      return (
        <p className="text-sm text-muted-foreground whitespace-pre-wrap">
          {parts.map((part, index) => {
            if (part.startsWith('**') && part.endsWith('**')) {
              return (
                <Link key={index} href="/features" className="font-bold text-primary hover:underline">
                  {part.slice(2, -2)}
                </Link>
              );
            }
            return part;
          })}
        </p>
      );
    };


    switch (notification.type) {
        case 'welcome':
            icon = <div className="p-2 bg-purple-100 rounded-full"><Sparkles className="h-5 w-5 text-purple-500" /></div>;
            text = <><p className="font-bold">{notification.title}</p><WelcomeBody body={notification.body} /></>;
            link = '/features';
            break;
        case 'like':
            icon = <div className="p-2 bg-red-100 rounded-full"><Heart className="h-5 w-5 text-red-500" /></div>;
            text = <><UserName user={notification.user} /> liked your post.</>;
            link = `/post/${notification.post.id}`;
            secondaryContent = postImageUrl ? <Image src={postImageUrl} alt="post preview" width={44} height={44} className="rounded-md object-cover"/> : null;
            break;
        case 'comment':
            icon = <div className="p-2 bg-blue-100 rounded-full"><MessageSquare className="h-5 w-5 text-blue-500" /></div>;
            text = <><UserName user={notification.user} /> commented: "{notification.comment}"</>;
            link = `/post/${notification.post.id}`;
            secondaryContent = postImageUrl ? <Image src={postImageUrl} alt="post preview" width={44} height={44} className="rounded-md object-cover"/> : null;
            break;
        case 'follow':
            icon = <div className="p-2 bg-green-100 rounded-full"><UserPlus className="h-5 w-5 text-green-500" /></div>;
            text = <><UserName user={notification.user} /> started following you.</>;
            link = `/profile/${notification.user.username}`;
            secondaryContent = <Button size="sm">Follow Back</Button>;
            break;
        case 'mention':
            icon = <div className="p-2 bg-purple-100 rounded-full"><AtSign className="h-5 w-5 text-purple-500" /></div>;
            text = <><UserName user={notification.user} /> mentioned you in a post.</>;
            link = `/post/${notification.post.id}`;
            secondaryContent = postImageUrl ? <Image src={postImageUrl} alt="post preview" width={44} height={44} className="rounded-md object-cover"/> : null;
            break;
        case 'new_release':
            icon = <div className="p-2 bg-yellow-100 rounded-full"><Music className="h-5 w-5 text-yellow-500" /></div>;
            text = <><UserName user={notification.artist} /> released a new album: {notification.album.title}</>;
            link = `/music/album/${notification.album.id}`;
            secondaryContent = <Image src={notification.album.cover.imageUrl} alt="album cover" width={44} height={44} className="rounded-md object-cover"/>
            break;
    }

    return (
        <Link href={link}>
            <div className={cn("flex items-start gap-4 p-4 hover:bg-accent", !notification.read && "bg-primary/5")}>
                {icon}
                <div className="flex-1 space-y-1">
                    <div className="text-sm">{text}</div>
                    <p className="text-xs text-muted-foreground">{formatDistanceToNow(notification.timestamp, { addSuffix: true })}</p>
                </div>
                {secondaryContent}
            </div>
        </Link>
    );
}
