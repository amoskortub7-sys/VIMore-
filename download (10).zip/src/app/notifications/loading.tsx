import { Skeleton } from '@/components/ui/skeleton';

export default function NotificationsLoading() {
  return (
    <div className="container mx-auto max-w-2xl py-4 sm:py-6">
       <header className="mb-6">
        <Skeleton className="h-9 w-64" />
      </header>
      <div className="space-y-6">
        <NotificationGroupSkeleton title="Today" />
        <NotificationGroupSkeleton title="This Week" />
      </div>
    </div>
  );
}

function NotificationGroupSkeleton({ title }: { title: string }) {
  return (
    <div>
      <Skeleton className="h-6 w-24 mb-2 ml-4" />
      <div className="flex flex-col">
        {Array.from({ length: 3 }).map((_, i) => (
           <div key={i} className="flex items-center gap-4 p-4">
                <Skeleton className="h-10 w-10 rounded-full" />
                <div className="flex-1 space-y-2">
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-3 w-1/4" />
                </div>
                <Skeleton className="h-11 w-11 rounded-md" />
            </div>
        ))}
      </div>
    </div>
  );
}
