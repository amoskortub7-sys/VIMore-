
'use client';

import * as React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { PageHeader } from '@/components/music/page-header';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Song, Album, User } from '@/lib/data';
import { useMusicPlayer } from '@/components/music/music-player-provider';
import { Play, Loader2 } from 'lucide-react';
import { cn, formatNumber } from '@/lib/utils';
import { UserAvatar } from '@/components/user-avatar';
import { VerifiedBadge } from '@/components/verified-badge';
import { AdBanner } from '@/components/music/ad-banner';
import { getSongs, getAlbums, getArtists } from '@/services/musicService';

const CHART_LIMIT = 50;

export default function ChartsPage() {
  const [topSongs, setTopSongs] = React.useState<Song[]>([]);
  const [topAlbums, setTopAlbums] = React.useState<Album[]>([]);
  const [topArtists, setTopArtists] = React.useState<User[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);

  React.useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const [songs, albums, artists] = await Promise.all([
          getSongs(CHART_LIMIT, 'streams'),
          getAlbums(CHART_LIMIT, 'streams'),
          getArtists(CHART_LIMIT, 'monthlyListeners')
        ]);
        setTopSongs(songs);
        setTopAlbums(albums);
        setTopArtists(artists);
      } catch (error) {
        console.error("Failed to fetch chart data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, []);

  return (
    <div className="container mx-auto max-w-5xl py-4 sm:py-6">
      <PageHeader
        title="Charts"
        description="Top songs, albums, and artists."
      />
      <Tabs defaultValue="songs" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="songs">Top Songs</TabsTrigger>
          <TabsTrigger value="albums">Top Albums</TabsTrigger>
          <TabsTrigger value="artists">Top Artists</TabsTrigger>
        </TabsList>
        <TabsContent value="songs" className="mt-6">
            <ChartList title="Top 50 Songs" isLoading={isLoading}>
                {topSongs.map((song, index) => (
                    <RankedSongItem key={song.id} song={song} rank={index + 1} playlist={topSongs}/>
                ))}
            </ChartList>
            <AdBanner className="mt-6"/>
        </TabsContent>
        <TabsContent value="albums" className="mt-6">
             <ChartList title="Top 50 Albums" isLoading={isLoading}>
                {topAlbums.map((album, index) => (
                    <RankedAlbumItem key={album.id} album={album} rank={index + 1} />
                ))}
            </ChartList>
            <AdBanner className="mt-6"/>
        </TabsContent>
        <TabsContent value="artists" className="mt-6">
            <ChartList title="Top 50 Artists" isLoading={isLoading}>
                {topArtists.map((artist, index) => (
                    <RankedArtistItem key={artist.id} artist={artist} rank={index + 1} />
                ))}
            </ChartList>
            <AdBanner className="mt-6"/>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function ChartList({ title, children, isLoading }: { title: string, children: React.ReactNode, isLoading: boolean }) {
    if (isLoading) {
      return (
        <div className="flex items-center justify-center h-[70vh]">
          <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
        </div>
      );
    }

    return (
        <div>
            <h2 className="text-xl font-bold mb-4">{title}</h2>
            <ScrollArea className="h-[70vh]">
                <div className="flex flex-col gap-1 pr-4">
                    {children}
                </div>
            </ScrollArea>
        </div>
    )
}

function RankedSongItem({ song, rank, playlist }: { song: Song, rank: number, playlist: Song[] }) {
    const { playSong, currentSong } = useMusicPlayer();
    const isActive = currentSong?.id === song.id;

    return (
        <div className="flex items-center gap-4 p-2 rounded-md hover:bg-accent group">
            <div className="w-8 text-center text-muted-foreground font-mono text-lg">{rank}</div>
            <div className="relative w-12 h-12 shrink-0">
                <Image src={song.album.cover.imageUrl} alt={song.album.title} fill className="rounded-md object-cover"/>
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <button onClick={() => playSong(song, playlist)} className="text-white">
                        <Play className="h-6 w-6" />
                    </button>
                </div>
            </div>
            <div className="flex-1 overflow-hidden">
                <p className={cn("font-semibold truncate", isActive && 'text-primary')}>{song.title}</p>
                <p className="text-sm text-muted-foreground truncate inline-flex items-center">
                    {song.artist.name}
                    <VerifiedBadge user={song.artist} />
                </p>
            </div>
            <div className="text-sm text-muted-foreground font-mono">{formatNumber(song.streams)}</div>
        </div>
    );
}

function RankedAlbumItem({ album, rank }: { album: Album, rank: number }) {
    return (
         <Link href={`/music/album/${album.id}`}>
            <div className="flex items-center gap-4 p-2 rounded-md hover:bg-accent group">
                <div className="w-8 text-center text-muted-foreground font-mono text-lg">{rank}</div>
                <Image src={album.cover.imageUrl} alt={album.title} width={48} height={48} className="rounded-md object-cover w-12 h-12 shrink-0"/>
                <div className="flex-1 overflow-hidden">
                    <p className="font-semibold truncate">{album.title}</p>
                    <p className="text-sm text-muted-foreground truncate inline-flex items-center">
                        {album.artist.name}
                        <VerifiedBadge user={album.artist} />
                    </p>
                </div>
                <div className="text-sm text-muted-foreground font-mono">{formatNumber(album.streams)}</div>
            </div>
        </Link>
    );
}

function RankedArtistItem({ artist, rank }: { artist: User, rank: number }) {
    return (
        <div className="flex items-center gap-4 p-2 rounded-md hover:bg-accent">
            <div className="w-8 text-center text-muted-foreground font-mono text-lg">{rank}</div>
            <UserAvatar user={artist} className="w-12 h-12 shrink-0" />
            <div className="flex-1 overflow-hidden">
                <p className="font-semibold truncate inline-flex items-center">
                    {artist.name}
                    <VerifiedBadge user={artist} />
                </p>
            </div>
            <div className="text-sm text-muted-foreground font-mono">{formatNumber(artist.monthlyListeners || 0)}</div>
        </div>
    );
}
