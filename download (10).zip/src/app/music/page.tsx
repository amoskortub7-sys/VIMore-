// This page only redirects. 
// It is not part of the main music layout to avoid rendering the shell on a redirect.
import { redirect } from 'next/navigation';

export default function MusicPage() {
  // By default, redirect to the discover page
  redirect('/music/discover');
}
