
import { PageHeader } from '@/components/music/page-header';

export default function SearchPage() {
  return (
    <div className="container mx-auto max-w-5xl py-4 sm:py-6">
      <PageHeader
        title="Search"
        description="Search for your favorite songs, artists, albums, and playlists."
      />
       <div className="flex h-96 items-center justify-center rounded-lg border-2 border-dashed">
        <p className="text-muted-foreground">Search content coming soon...</p>
      </div>
    </div>
  );
}
