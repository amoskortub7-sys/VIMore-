

'use client';

import * as React from 'react';
import Image from 'next/image';
import { Music, UploadCloud, X, FileAudio, Check, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PageHeader } from '@/components/music/page-header';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { AppContext } from '@/components/app-shell';
import { uploadFile } from '@/services/storageService';
import { createAlbum, createSong } from '@/services/musicService';

const MAX_FILES = 12;
const ACCEPTED_AUDIO_TYPES = ['audio/mpeg', 'audio/wav', 'audio/mp3', 'audio/mp4', 'audio/x-m4a'];

type Track = {
  file: File;
  name: string;
};

export default function UploadPage() {
  const { toast } = useToast();
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const appContext = React.useContext(AppContext);

  const [tracks, setTracks] = React.useState<Track[]>([]);
  const [albumName, setAlbumName] = React.useState('');
  const [coverArt, setCoverArt] = React.useState<File | null>(null);
  const [coverArtPreview, setCoverArtPreview] = React.useState<string | null>(null);
  const [allowAsSound, setAllowAsSound] = React.useState(true);
  const [isUploading, setIsUploading] = React.useState(false);
  const [isDragOver, setIsDragOver] = React.useState(false);

  const isAlbum = tracks.length > 1;

  React.useEffect(() => {
    if (coverArt) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCoverArtPreview(reader.result as string);
      };
      reader.readAsDataURL(coverArt);
    } else {
      setCoverArtPreview(null);
    }
  }, [coverArt]);
  
  const resetState = () => {
    setTracks([]);
    setAlbumName('');
    setCoverArt(null);
    setCoverArtPreview(null);
    setAllowAsSound(true);
    if(fileInputRef.current) fileInputRef.current.value = '';
  }

  const handleFileSelect = (files: FileList | null) => {
    if (!files) return;
    
    if (files.length > MAX_FILES) {
        toast({ variant: 'destructive', title: `You can only upload up to ${MAX_FILES} files.` });
        return;
    }

    const audioFiles = Array.from(files).filter(file => ACCEPTED_AUDIO_TYPES.includes(file.type));

    if (audioFiles.length !== files.length) {
        toast({ variant: 'destructive', title: 'Invalid file type', description: 'Please upload only audio files (MP3, WAV, M4A).' });
    }

    setTracks(audioFiles.map(file => ({ file, name: file.name.replace(/\.[^/.]+$/, "") })));
  };

  const handleTrackNameChange = (index: number, name: string) => {
    const newTracks = [...tracks];
    newTracks[index].name = name;
    setTracks(newTracks);
  };
  
  const handleCoverArtSelect = (files: FileList | null) => {
    if (files && files[0]) {
        if (!files[0].type.startsWith('image/')) {
            toast({ variant: 'destructive', title: 'Invalid file type', description: 'Please select an image file for the cover art.' });
            return;
        }
        setCoverArt(files[0]);
    }
  };
  
  const handlePublish = async () => {
    if (!appContext?.currentUser) {
        toast({ variant: 'destructive', title: 'You must be logged in to upload music.' });
        return;
    }
    setIsUploading(true);

    try {
        let coverArtUrl = 'https://picsum.photos/seed/default/400/400';
        if (coverArt) {
            coverArtUrl = await uploadFile(coverArt);
        }

        const albumData = {
            title: isAlbum ? albumName : tracks[0].name,
            artist: appContext.currentUser,
            cover: { id: `cover-${Date.now()}`, imageUrl: coverArtUrl, description: 'Uploaded cover', imageHint: 'album cover' },
        };
        
        const newAlbumId = await createAlbum(albumData);

        for (const track of tracks) {
            const audioUrl = await uploadFile(track.file);
            
            // This is a mock duration. In a real app, you'd use a library 
            // to read audio metadata on the client or server.
            const newSongData = {
                title: track.name,
                artist: appContext.currentUser,
                album: { id: newAlbumId, ...albumData },
                duration: '3:00', 
                src: audioUrl,
                isUsableAsSound: allowAsSound,
            };
            await createSong(newSongData);
        }

        setIsUploading(false);
        toast({
            title: 'Upload Successful!',
            description: `${isAlbum ? 'Your album' : 'Your song'} has been published.`,
        });
        resetState();

    } catch (error: any) {
        console.error("Upload failed:", error);
        setIsUploading(false);
        toast({
            variant: 'destructive',
            title: 'Upload Failed',
            description: error.message || 'Could not publish your music. Please try again.',
        });
    }
  }


  const canPublish = coverArt && tracks.every(t => t.name.trim() !== '') && (isAlbum ? albumName.trim() !== '' : true);

  const handleDragEvents = (e: React.DragEvent<HTMLDivElement>, isOver: boolean) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(isOver);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    handleDragEvents(e, false);
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      handleFileSelect(files);
    }
  };


  if (tracks.length > 0) {
    return (
        <div className="container mx-auto max-w-3xl py-4 sm:py-6">
            <header className="flex items-center justify-between mb-6">
                 <h1 className="font-headline text-3xl font-bold">{isAlbum ? "Upload Album" : "Upload Single"}</h1>
                 <Button variant="ghost" onClick={resetState}>
                    <X className="mr-2 h-4 w-4" /> Cancel
                 </Button>
            </header>
            <div className="space-y-6">
                <Card>
                    <CardContent className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="md:col-span-1">
                            <Label htmlFor="coverArt" className={cn(
                                "aspect-square w-full border-2 border-dashed rounded-lg flex flex-col items-center justify-center text-muted-foreground cursor-pointer hover:border-primary hover:text-primary transition-colors",
                                coverArtPreview && "border-solid"
                            )}>
                                {coverArtPreview ? (
                                    <Image src={coverArtPreview} alt="Cover art preview" width={200} height={200} className="w-full h-full object-cover rounded-md" />
                                ) : (
                                    <>
                                        <UploadCloud className="h-8 w-8 mb-2"/>
                                        <span>Upload Cover Art</span>
                                    </>
                                )}
                            </Label>
                            <input id="coverArt" type="file" accept="image/*" className="hidden" onChange={(e) => handleCoverArtSelect(e.target.files)} />
                        </div>
                        <div className="md:col-span-2 space-y-4">
                           {isAlbum && (
                             <div>
                                <Label htmlFor="albumName">Album Name</Label>
                                <Input id="albumName" placeholder="Name of your album" value={albumName} onChange={(e) => setAlbumName(e.target.value)} />
                             </div>
                           )}
                           {!isAlbum && (
                             <div>
                                <Label htmlFor="trackName-0">Song Name</Label>
                                <Input id="trackName-0" placeholder="Name of your song" value={tracks[0]?.name || ''} onChange={(e) => handleTrackNameChange(0, e.target.value)} />
                             </div>
                           )}
                           <div className="flex items-center space-x-2 pt-2">
                                <Switch id="allow-sound" checked={allowAsSound} onCheckedChange={setAllowAsSound}/>
                                <Label htmlFor="allow-sound">Allow others to use as a sound</Label>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {isAlbum && (
                    <Card>
                         <CardContent className="p-6">
                            <h2 className="font-bold text-lg mb-4">Tracklist</h2>
                            <ScrollArea className="h-72">
                                <div className="space-y-4 pr-4">
                                {tracks.map((track, index) => (
                                    <div key={index} className="flex items-center gap-4">
                                        <div className="text-muted-foreground text-sm font-mono">{index + 1}</div>
                                        <FileAudio className="h-5 w-5 text-muted-foreground" />
                                        <Input 
                                            placeholder="Track name"
                                            value={track.name}
                                            onChange={(e) => handleTrackNameChange(index, e.target.value)}
                                        />
                                    </div>
                                ))}
                                </div>
                            </ScrollArea>
                         </CardContent>
                    </Card>
                )}

                 <div className="flex justify-end">
                    <Button size="lg" onClick={handlePublish} disabled={!canPublish || isUploading}>
                        {isUploading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Check className="mr-2 h-4 w-4" />}
                        {isUploading ? "Publishing..." : "Publish"}
                    </Button>
                </div>
            </div>
        </div>
    )
  }

  return (
    <div className="container mx-auto max-w-5xl py-4 sm:py-6">
      <PageHeader
        title="Upload Music"
        description="Share your songs and albums with the world."
      />
      <input 
        type="file" 
        ref={fileInputRef} 
        className="hidden" 
        multiple 
        accept={ACCEPTED_AUDIO_TYPES.join(',')}
        onChange={(e) => handleFileSelect(e.target.files)}
      />
      <div 
        className={cn(
            "mt-8 flex h-96 flex-col items-center justify-center rounded-lg border-2 border-dashed transition-colors",
            isDragOver ? "border-primary bg-accent" : ""
        )}
        onClick={() => fileInputRef.current?.click()}
        onDragOver={(e) => handleDragEvents(e, true)}
        onDragLeave={(e) => handleDragEvents(e, false)}
        onDrop={handleDrop}
      >
        <UploadCloud className="h-16 w-16 text-muted-foreground" />
        <p className="mt-4 text-lg font-semibold">Drag & drop your audio files here</p>
        <p className="text-muted-foreground">Up to {MAX_FILES} files (MP3, WAV, M4A)</p>
        <Button className="mt-6" variant="outline">Or Select Files</Button>
      </div>
    </div>
  );
}

    
