
'use client';

import * as React from 'react';
import { PageHeader } from '@/components/music/page-header';
import { AlbumCard } from '@/components/music/album-card';
import { Album, User } from '@/lib/data';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { AdBanner } from '@/components/music/ad-banner';
import { getAlbums, getArtists } from '@/services/musicService';
import { Skeleton } from '@/components/ui/skeleton';
import { UserAvatar } from '@/components/user-avatar';
import Link from 'next/link';

export default function DiscoverPage() {
  const [newReleases, setNewReleases] = React.useState<Album[]>([]);
  const [topAlbums, setTopAlbums] = React.useState<Album[]>([]);
  const [topArtists, setTopArtists] = React.useState<User[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);

  React.useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const [releases, albums, artists] = await Promise.all([
          getAlbums(10, '$createdAt'),
          getAlbums(10, 'streams'),
          getArtists(10, 'monthlyListeners')
        ]);
        setNewReleases(releases);
        setTopAlbums(albums);
        setTopArtists(artists);
      } catch (error) {
        console.error("Failed to fetch discover data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, []);

  return (
    <div className="container mx-auto max-w-5xl py-4 sm:py-6">
      <PageHeader
        title="Discover"
        description="Find new music, trending artists, and top albums."
      />
      <div className="space-y-8">
        <ContentSection title="New Releases">
          {isLoading ? <ContentSectionSkeleton /> : (
            <ScrollArea>
              <div className="flex space-x-4 pb-4">
                {newReleases.map((album) => (
                  <AlbumCard key={album.id} album={album} className="w-[200px]" width={200} height={200} />
                ))}
              </div>
              <ScrollBar orientation="horizontal" />
            </ScrollArea>
          )}
        </ContentSection>
        
        <AdBanner />

        <ContentSection title="Top Artists">
          {isLoading ? <ContentSectionSkeleton variant="artist" /> : (
            <ScrollArea>
              <div className="flex space-x-6 pb-4">
                {topArtists.map((artist) => (
                   <Link href={`/profile/${artist.username}`} key={artist.id} className="flex flex-col items-center gap-2 w-28 text-center shrink-0">
                      <UserAvatar user={artist} className="w-24 h-24"/>
                      <p className="text-sm font-semibold truncate w-full">{artist.name}</p>
                   </Link>
                ))}
              </div>
              <ScrollBar orientation="horizontal" />
            </ScrollArea>
          )}
        </ContentSection>

        <ContentSection title="Top Albums">
           {isLoading ? <ContentSectionSkeleton /> : (
            <ScrollArea>
                <div className="flex space-x-4 pb-4">
                    {topAlbums.map((album) => (
                        <AlbumCard key={album.id} album={album} className="w-[200px]" width={200} height={200} />
                    ))}
                </div>
                <ScrollBar orientation="horizontal" />
            </ScrollArea>
           )}
        </ContentSection>
      </div>
    </div>
  );
}

function ContentSection({ title, children }: { title: string, children: React.ReactNode }) {
    return (
        <section>
            <h2 className="text-2xl font-bold mb-4">{title}</h2>
            {children}
        </section>
    );
}

function ContentSectionSkeleton({ variant = 'album' }: { variant?: 'album' | 'artist'}) {
    return (
        <div className="flex space-x-4 pb-4">
            {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="w-[200px] shrink-0 space-y-2">
                    {variant === 'album' ? (
                      <>
                        <Skeleton className="h-[200px] w-full rounded-md" />
                        <Skeleton className="h-4 w-3/4" />
                        <Skeleton className="h-3 w-1/2" />
                      </>
                    ) : (
                      <div className="flex flex-col items-center gap-2">
                        <Skeleton className="h-24 w-24 rounded-full" />
                        <Skeleton className="h-4 w-20" />
                      </div>
                    )}
                </div>
            ))}
        </div>
    );
}
