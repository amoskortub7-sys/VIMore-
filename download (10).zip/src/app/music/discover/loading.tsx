import { Skeleton } from '@/components/ui/skeleton';

export default function MusicDiscoverLoading() {
  return (
    <div className="container mx-auto max-w-5xl py-4 sm:py-6">
      <header className="mb-6">
        <Skeleton className="h-10 w-48 mb-2" />
        <Skeleton className="h-6 w-72" />
      </header>
      <div className="space-y-8">
        <ContentSectionSkeleton />
        <ContentSectionSkeleton />
        <ContentSectionSkeleton />
      </div>
    </div>
  );
}

function ContentSectionSkeleton() {
    return (
        <section>
            <Skeleton className="h-8 w-56 mb-4" />
            <div className="flex space-x-4 pb-4">
                {Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} className="w-[180px] shrink-0 space-y-2">
                        <Skeleton className="h-[180px] w-full rounded-md" />
                        <Skeleton className="h-4 w-3/4" />
                        <Skeleton className="h-3 w-1/2" />
                    </div>
                ))}
            </div>
        </section>
    )
}
