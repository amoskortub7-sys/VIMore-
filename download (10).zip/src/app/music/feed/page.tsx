

'use client';

import * as React from 'react';
import { PageHeader } from '@/components/music/page-header';
import type { MusicFeedItem, User } from '@/lib/data';
import { FeedItemCard } from '@/components/music/feed-item-card';
import { AppContext } from '@/components/app-shell';
import { getMusicFeedForUser } from '@/services/musicService';
import { getFollowing, toggleFollow } from '@/services/userService';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function FeedPage() {
  const appContext = React.useContext(AppContext);
  const currentUser = appContext?.currentUser;
  const { toast } = useToast();

  const [feedItems, setFeedItems] = React.useState<MusicFeedItem[]>([]);
  const [followedUsers, setFollowedUsers] = React.useState<User[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  
  React.useEffect(() => {
    const fetchData = async () => {
      if (!currentUser) return;
      setIsLoading(true);
      try {
        const [feed, following] = await Promise.all([
          getMusicFeedForUser(currentUser.id),
          getFollowing(currentUser.id)
        ]);
        setFeedItems(feed);
        setFollowedUsers(following);
      } catch (error) {
        console.error("Failed to fetch music feed:", error);
        toast({
          variant: "destructive",
          title: "Could not load your feed.",
        });
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, [currentUser, toast]);


  const handleFollowToggle = async (userToToggle: User) => {
    if (!currentUser) return;

    const isFollowing = followedUsers.some(u => u.id === userToToggle.id);
    const oldFollowedUsers = [...followedUsers];

    // Optimistic update
    if (isFollowing) {
      setFollowedUsers(prev => prev.filter(u => u.id !== userToToggle.id));
    } else {
      setFollowedUsers(prev => [...prev, userToToggle]);
    }

    try {
        await toggleFollow(currentUser.id, userToToggle.id, isFollowing);
        toast({
            title: isFollowing ? `Unfollowed ${userToToggle.name}` : `Followed ${userToToggle.name}`,
        });
    } catch (error) {
        setFollowedUsers(oldFollowedUsers); // Revert on error
        toast({ variant: 'destructive', title: 'Action failed.' });
    }
  };

  return (
    <div className="container mx-auto max-w-5xl py-4 sm:py-6">
      <PageHeader
        title="Music Feed"
        description="Updates from artists you follow."
      />
       <div className="flex flex-col gap-6">
        {isLoading ? (
            <div className="flex h-96 items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin" />
            </div>
        ) : feedItems.length > 0 ? (
          feedItems.map((item) => <FeedItemCard key={item.id} item={item} followedUsers={followedUsers} onFollowToggle={handleFollowToggle} />)
        ) : (
          <div className="flex h-96 items-center justify-center rounded-lg border-2 border-dashed">
            <div className="text-center">
                <p className="text-lg font-semibold">Your feed is quiet...</p>
                <p className="text-muted-foreground mt-1">Follow artists to see their new releases here.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
