
'use client';

import * as React from 'react';
import Link from 'next/link';
import { Play, Download, Check, Loader2 } from 'lucide-react';
import { PageHeader } from '@/components/music/page-header';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import {
  type Song,
  type User,
  type Playlist,
  type Album,
} from '@/lib/data';
import { useMusicPlayer } from '@/components/music/music-player-provider';
import { PlaylistCard } from '@/components/music/playlist-card';
import { AlbumCard } from '@/components/music/album-card';
import { SongListItem } from '@/components/music/song-list-item';
import { UserAvatar } from '@/components/user-avatar';
import { AppContext } from '@/components/app-shell';
import { getFollowing } from '@/services/userService';
import { getSavedAlbums, getSavedPlaylists } from '@/services/musicService';
import { useToast } from '@/hooks/use-toast';
import { databases } from '@/lib/appwrite';

const DATABASE_ID = process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID!;
const SONGS_COLLECTION_ID = process.env.NEXT_PUBLIC_APPWRITE_SONGS_COLLECTION_ID!;

export default function LibraryPage() {
  const { likedSongs, downloadedSongs } = useMusicPlayer();
  const appContext = React.useContext(AppContext);
  const currentUser = appContext?.currentUser;
  const { toast } = useToast();

  const [followedArtists, setFollowedArtists] = React.useState<User[]>([]);
  const [savedPlaylists, setSavedPlaylists] = React.useState<Playlist[]>([]);
  const [savedAlbums, setSavedAlbums] = React.useState<Album[]>([]);
  const [likedSongsList, setLikedSongsList] = React.useState<Song[]>([]);

  const [isLoading, setIsLoading] = React.useState(true);

  React.useEffect(() => {
    const fetchData = async () => {
      if (!currentUser) return;
      setIsLoading(true);
      try {
        const followingPromise = getFollowing(currentUser.id);
        const albumsPromise = getSavedAlbums(currentUser.id);
        const playlistsPromise = getSavedPlaylists(currentUser.id);
        
        let likedSongsPromise: Promise<Song[]> = Promise.resolve([]);
        if (likedSongs.size > 0) {
            const likedSongIds = Array.from(likedSongs);
            likedSongsPromise = databases.listDocuments(DATABASE_ID, SONGS_COLLECTION_ID, [
                databases.Query.equal('$id', likedSongIds)
            ]).then(res => res.documents as Song[]);
        }

        const [following, albums, playlists, fetchedLikedSongs] = await Promise.all([followingPromise, albumsPromise, playlistsPromise, likedSongsPromise]);

        setFollowedArtists(following.filter(u => u.role === 'artist'));
        setSavedAlbums(albums);
        setSavedPlaylists(playlists);
        setLikedSongsList(fetchedLikedSongs);

      } catch (error) {
        toast({
          variant: 'destructive',
          title: 'Could not load your library.',
        });
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, [currentUser, likedSongs, toast]);


  if (!currentUser) {
    return <div className="flex h-screen items-center justify-center"><Loader2 className="animate-spin" /></div>;
  }

  const downloadedSongsList = React.useMemo(() => {
    // This is a simplified mock. In a real app, you'd fetch song details for downloaded IDs.
    return [];
  }, [downloadedSongs]);

  return (
    <div className="container mx-auto max-w-5xl py-4 sm:py-6">
      <PageHeader
        title="My Library"
        description="Your playlists, liked songs, followed artists, and downloads."
      />
      <Tabs defaultValue="playlists" className="w-full">
        <ScrollArea className="w-full whitespace-nowrap">
            <TabsList className="inline-flex">
              <TabsTrigger value="playlists">Playlists</TabsTrigger>
              <TabsTrigger value="songs">Liked</TabsTrigger>
              <TabsTrigger value="albums">Albums</TabsTrigger>
              <TabsTrigger value="artists">Artists</TabsTrigger>
              <TabsTrigger value="downloads">
                  <div className="flex items-center gap-2">
                    <Check className="h-4 w-4" /> Downloads
                  </div>
              </TabsTrigger>
            </TabsList>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>

        <TabsContent value="playlists" className="mt-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {isLoading ? <Loader2 className="animate-spin"/> : savedPlaylists.length > 0 ? (
              savedPlaylists.map((playlist) => (
                <PlaylistCard key={playlist.id} playlist={playlist} className="aspect-[4/3]"/>
              ))
            ) : <EmptyState message="You haven't created or saved any playlists yet." />}
          </div>
        </TabsContent>

        <TabsContent value="songs" className="mt-6">
          <SongListWithPlay songList={likedSongsList} playlistTitle="Liked Songs" isLoading={isLoading} />
        </TabsContent>

        <TabsContent value="albums" className="mt-6">
           <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {isLoading ? <Loader2 className="animate-spin"/> : savedAlbums.length > 0 ? (
              savedAlbums.map((album) => (
                <AlbumCard key={album.id} album={album} className="w-full" width={250} height={250}/>
              ))
            ) : <EmptyState message="You haven't saved any albums yet." />}
          </div>
        </TabsContent>

        <TabsContent value="artists" className="mt-6">
          <div className="flex flex-col gap-1 pr-4">
            {isLoading ? (
                <Loader2 className="mx-auto animate-spin" />
            ) : followedArtists.length > 0 ? (
                followedArtists.map((artist) => artist && (
                  <Link href={`/profile/${artist.username}`} key={artist.id}>
                    <div className="flex items-center gap-4 p-2 rounded-md hover:bg-accent">
                      <UserAvatar user={artist} className="w-12 h-12 shrink-0"/>
                      <p className="font-semibold truncate">{artist.name}</p>
                    </div>
                  </Link>
                ))
            ) : (
                <EmptyState message="You haven't followed any artists yet." />
            )}
          </div>
        </TabsContent>

        <TabsContent value="downloads" className="mt-6">
            <SongListWithPlay songList={downloadedSongsList} playlistTitle="Downloaded Songs" isLoading={isLoading} />
        </TabsContent>
      </Tabs>
    </div>
  );
}


function SongListWithPlay({ songList, playlistTitle, isLoading }: { songList: Song[], playlistTitle: string, isLoading: boolean }) {
  const { playSong } = useMusicPlayer();

  const handlePlay = () => {
    if (songList.length > 0) {
      playSong(songList[0], songList);
    }
  };
  
  if (isLoading) {
    return <div className="flex h-48 items-center justify-center"><Loader2 className="animate-spin" /></div>;
  }

  if (songList.length === 0) {
    return <EmptyState message={`You don't have any ${playlistTitle.toLowerCase()} yet.`} />;
  }

  return (
    <div>
        <Button onClick={handlePlay} className="mb-6 gap-2">
            <Play className="h-5 w-5" /> Play
        </Button>
        <div className="flex flex-col">
            {songList.map((song, index) => (
                <SongListItem key={song.id} song={song} playlist={songList} index={index} />
            ))}
        </div>
    </div>
  )
}

function EmptyState({ message }: { message: string }) {
    return (
        <div className="col-span-full flex h-48 items-center justify-center rounded-lg border-2 border-dashed">
            <p className="text-muted-foreground text-center">{message}</p>
        </div>
    );
}
