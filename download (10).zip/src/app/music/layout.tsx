
import { AdBanner } from "@/components/music/ad-banner";
import { MusicShell } from "@/components/music-shell";
import { useMusicPlayer } from "@/components/music/music-player-provider";


export default function MusicLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <MusicShell>
      {children}
      <AdBanner />
    </MusicShell>
  );
}

