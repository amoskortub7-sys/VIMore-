
'use client';

import * as React from 'react';
import Image from 'next/image';
import { notFound } from 'next/navigation';
import { PlayCircle, Shuffle, Gift, Download, Heart, TrendingUp, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { SongListItem } from '@/components/music/song-list-item';
import { useMusicPlayer } from '@/components/music/music-player-provider';
import { GiftingDialog } from '@/components/gifting-dialog';
import { SupportDialog } from '@/components/support-dialog';
import { VerifiedBadge } from '@/components/verified-badge';
import { BoostPostDialog } from '@/components/boost-post-dialog';
import { useToast } from '@/hooks/use-toast';
import { getAlbumById } from '@/services/musicService';
import { type Post, type Album } from '@/lib/data';
import { AppContext } from '@/components/app-shell';

export default function AlbumPage({ params }: { params: { albumId: string } }) {
  const { playSong, downloadPlaylist } = useMusicPlayer();
  const { albumId } = params;
  const { toast } = useToast();
  
  const [album, setAlbum] = React.useState<Album | null>(null);
  const [isLoading, setIsLoading] = React.useState(true);
  
  const appContext = React.useContext(AppContext);
  const currentUser = appContext?.currentUser;

  React.useEffect(() => {
    const fetchAlbum = async () => {
      setIsLoading(true);
      const fetchedAlbum = await getAlbumById(albumId);
      if (fetchedAlbum) {
        setAlbum(fetchedAlbum);
      } else {
        notFound();
      }
      setIsLoading(false);
    }
    fetchAlbum();
  }, [albumId]);
  
  if (isLoading || !album || !currentUser) {
    return <div className="flex h-screen items-center justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>;
  }
  
  // Create a mock post object for the boost dialog
  const mockPostForBoosting: Post = {
    id: `album-boost-${album.id}`,
    author: album.artist,
    content: `Check out my new album: ${album.title}!`,
    images: [album.cover],
    createdAt: 'Just now',
    comments: [],
    reactions: [],
    shares: 0,
  };

  const handlePlayAlbum = () => {
    if (album.songs.length > 0) {
      playSong(album.songs[0], album.songs);
    }
  };
  
  const handleDownloadAlbum = () => {
    if (album.songs.length > 0) {
      downloadPlaylist(album.songs);
    }
  }

  const creator = album.artist;
  const isOwnAlbum = creator?.id === currentUser.id;
  const canBeTipped = creator.followers >= 10000;


  return (
    <div className="container mx-auto max-w-5xl py-4 sm:py-6">
        <div className="flex flex-col sm:flex-row items-center gap-6 sm:gap-8">
            <div className="relative w-48 h-48 sm:w-56 sm:h-56 shrink-0">
                <Image
                    src={album.cover.imageUrl}
                    alt={album.title}
                    fill
                    className="rounded-lg object-cover shadow-lg"
                />
            </div>
            <div className="text-center sm:text-left">
                <p className="text-sm uppercase text-muted-foreground font-bold">Album</p>
                <h1 className="font-headline text-4xl sm:text-5xl md:text-6xl font-extrabold mt-2 break-words">{album.title}</h1>
                <p className="text-lg text-muted-foreground mt-4 inline-flex items-center">
                    By <span className="font-semibold text-foreground ml-1">{album.artist.name}</span>
                    <VerifiedBadge user={album.artist} />
                </p>
            </div>
        </div>

        <div className="flex flex-wrap items-center gap-4 my-8">
            <Button size="lg" className="rounded-full px-6 gap-2" onClick={handlePlayAlbum}>
                <PlayCircle className="h-6 w-6"/>
                Play
            </Button>
             <Button size="lg" variant="secondary" className="rounded-full px-6 gap-2">
                <Shuffle className="h-6 w-6"/>
                Shuffle
            </Button>
            <Button size="lg" variant="secondary" className="rounded-full px-6 gap-2" onClick={handleDownloadAlbum}>
                <Download className="h-6 w-6"/>
                Download
            </Button>
             {creator && !isOwnAlbum && (
                <GiftingDialog currentUser={currentUser} creator={creator}>
                    <Button size="lg" variant="secondary" className="rounded-full px-6 gap-2">
                        <Gift className="h-6 w-6"/>
                        Gift
                    </Button>
                </GiftingDialog>
            )}
             {creator && !isOwnAlbum && canBeTipped && (
                <SupportDialog currentUser={currentUser} creator={creator}>
                    <Button size="lg" variant="secondary" className="rounded-full px-6 gap-2 bg-amber-400/20 text-amber-600 hover:bg-amber-400/30">
                        <Heart className="h-6 w-6"/>
                        Support
                    </Button>
                </SupportDialog>
            )}
            {isOwnAlbum && (
                <BoostPostDialog post={mockPostForBoosting} user={currentUser} contentType="music" onBoost={() => toast({title: "Your album is now being boosted!"})}>
                     <Button size="lg" variant="secondary" className="rounded-full px-6 gap-2">
                        <TrendingUp className="h-6 w-6"/>
                        Boost Album
                    </Button>
                </BoostPostDialog>
            )}
        </div>

        <div className="flex flex-col">
            {album.songs.map((song, index) => (
                <SongListItem key={song.id} song={song} playlist={album.songs} index={index} />
            ))}
        </div>
    </div>
  );
}
