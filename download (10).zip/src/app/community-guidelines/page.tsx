
'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function CommunityGuidelinesPage() {
  const router = useRouter();

  return (
    <div className="bg-background min-h-screen">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft />
        </Button>
        <h1 className="text-xl font-bold">Community Guidelines</h1>
      </header>
      <main className="container mx-auto max-w-2xl py-6">
        <div className="prose dark:prose-invert">
            <h2>Community Guidelines</h2>
            <p>Our mission is to foster a positive and supportive community where everyone can create and share safely. These guidelines are our rules of the road to help us create a safe and welcoming environment for everyone on VIMore. Violating these guidelines may result in removed content, strikes on your account, disabled accounts, or other restrictions.</p>
            
            <h3>1. Share Only Authentic Content</h3>
            <p>We want to foster genuine connection, not misleading content. Be real, be you.</p>
            <ul>
                <li><strong>Impersonation:</strong> Do not impersonate others in a manner that is intended to or does mislead, confuse, or deceive others. Parody and fan accounts are generally permissible if they are clearly marked as such in the account bio and username.</li>
                <li><strong>Misinformation:</strong> Do not post content that is demonstrably false and has a high likelihood of causing public harm (e.g., misinformation about public health crises, civic processes, or proven violent events).</li>
                <li><strong>Spam:</strong> Do not create or use accounts for the primary purpose of posting repetitive, unsolicited, or commercial content. This includes creating misleading accounts or content to artificially inflate engagement.</li>
            </ul>

            <h3>2. Be Respectful to Other Members</h3>
            <p>We want to foster a positive, diverse community. We remove content that contains credible threats, hate speech, or targets private individuals. We do not tolerate bullying or harassment in any form.</p>
            <ul>
                <li><strong>Hate Speech:</strong> Do not post content that promotes violence, incites hatred, promotes discrimination, or disparages on the basis of race or ethnic origin, religion, disability, age, nationality, veteran status, sexual orientation, sex, gender, gender identity, caste, or any other characteristic that is associated with systemic discrimination or marginalization.</li>
                <li><strong>Bullying and Harassment:</strong> We remove content that targets private individuals with prolonged or malicious insults, degrading or shaming language, or unwanted sexualization. This includes posting someone's private information, like their phone number or address (doxing).</li>
                <li><strong>Threats:</strong> Do not post direct and credible threats of violence against any individual or group of people.</li>
            </ul>
            
            <h3>3. Promote Safety and Avoid Harmful Content</h3>
            <p>Content that encourages or glorifies self-harm, violence, or dangerous acts is not allowed on VIMore.</p>
            <ul>
                <li><strong>Self-Harm:</strong> We remove content that encourages or provides instructions on how to self-harm or commit suicide. We may, however, allow content that discusses these topics in a way that is supportive and aimed at recovery.</li>
                <li><strong>Dangerous Acts:</strong> Do not post content that encourages dangerous or illegal acts that have an inherent risk of serious physical harm or death. This includes challenges, pranks, or instructions for creating weapons or explosives.</li>
                <li><strong>Graphic Violence:</strong> Do not post content that is excessively gory or violent for sadistic pleasure. Content that is newsworthy or documentary in nature may be allowed with a warning screen.</li>
                <li><strong>Exploitation:</strong> We have a zero-tolerance policy for content that sexually exploits or endangers children. We report all such content to law enforcement authorities. We also remove non-consensual sexual content of any kind.</li>
            </ul>

            <h3>4. Follow the Law</h3>
            <p>VIMore is not a place to support or praise terrorism, organized crime, or hate groups. We also prohibit the sale of regulated goods.</p>
            <ul>
                <li><strong>Illegal Goods and Services:</strong> Offering sexual services, and buying or selling firearms, alcohol, and tobacco products between private individuals are not allowed. We also remove content that attempts to trade or sell regulated goods, such as pharmaceutical drugs, marijuana, or other controlled substances.</li>
                <li><strong>Terrorism and Organized Crime:</strong> We do not permit any organizations or individuals that proclaim a violent mission or are engaged in violence to have a presence on VIMore. This includes terrorist organizations, organized hate groups, and criminal organizations.</li>
            </ul>

            <h3>5. Respect Intellectual Property</h3>
            <p>Make sure you have the rights to the content you post. This includes music, video clips, and images. Respect copyrights, trademarks, and other legal rights.</p>
            <ul>
                <li><strong>Copyright:</strong> Only post content that you created or that you have permission to use. Simply giving credit to the creator is not always enough; you may need explicit permission.</li>
                <li><strong>Trademark:</strong> Do not use another person's or company's trademark in a way that is likely to cause confusion about who owns the trademark.</li>
            </ul>

             <h3>What to Do If You See Something That Violates Our Guidelines</h3>
            <p>If you see something that you think may violate our guidelines, please help us by using our built-in reporting option. We have a global team that reviews these reports and works as quickly as possible to remove content that doesn’t meet our guidelines. Reporting is confidential, and the person you are reporting will not know who filed the report.</p>
        </div>
      </main>
    </div>
  );
}
