
'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, CheckCircle, AlertTriangle, Gift, Tag, ReceiptText, Wallet, Info, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { cn, formatNumber } from '@/lib/utils';
import { type SupportTicket, type User } from '@/lib/data';
import type { Transaction, PurchaseRequest } from '@/lib/data';
import { format } from 'date-fns';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
  DialogDescription,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { UserAvatar } from '@/components/user-avatar';
import { Separator } from '@/components/ui/separator';
import { ContactSupportDialog } from '@/app/settings/page';
import type { CurrencyPackage, MobileMoneyAccount } from '@/lib/data';
import { getMonetizationConfig, getPaymentDetails, createPurchaseRequest, getTransactions } from '@/services/monetizationService';
import { AppContext } from '@/components/app-shell';


type Currency = 'gold' | 'diamond';
type PaymentMethod = 'USD' | 'LD';


export default function BuyCurrencyPage() {
  const router = useRouter();
  const appContext = React.useContext(AppContext);

  const [goldPackages, setGoldPackages] = React.useState<CurrencyPackage[]>([]);
  const [diamondPackages, setDiamondPackages] = React.useState<CurrencyPackage[]>([]);
  const [paymentDetails, setPaymentDetails] = React.useState<{ orange: MobileMoneyAccount, mtn: MobileMoneyAccount, momoPSB: MobileMoneyAccount }>({ orange: { name: '', number: '' }, mtn: { name: '', number: '' }, momoPSB: { name: '', number: '' } });
  
  React.useEffect(() => {
    const fetchConfig = async () => {
      const [config, payments] = await Promise.all([
        getMonetizationConfig(),
        getPaymentDetails(),
      ]);
      setGoldPackages(config.goldPackages);
      setDiamondPackages(config.diamondPackages);
      setPaymentDetails(payments);
    }
    fetchConfig();
  }, []);

  if (!appContext || !appContext.currentUser) return <div className="flex h-screen items-center justify-center"><Loader2 className="animate-spin" /></div>;
  const { currentUser } = appContext;


  return (
    <div className="container mx-auto max-w-4xl py-4 sm:py-6">
      <header className="mb-6 flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft />
        </Button>
        <h1 className="font-headline text-3xl font-bold">Buy Currency</h1>
      </header>
      
      <WalletStatus user={currentUser} />

      <Tabs defaultValue="gold" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="gold" className="gap-2">
            <span className="text-xl">🪙</span> Gold
          </TabsTrigger>
          <TabsTrigger value="diamond" className="gap-2">
            <span className="text-xl">💎</span> Diamond
          </TabsTrigger>
           <TabsTrigger value="history" className="gap-2">
            <ReceiptText className="h-5 w-5" /> History
          </TabsTrigger>
        </TabsList>
        <TabsContent value="gold" className="mt-6">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {goldPackages.map((pkg) => (
              <PackageCard key={pkg.id} pkg={pkg} currencyType="gold" paymentDetails={paymentDetails} />
            ))}
          </div>
        </TabsContent>
        <TabsContent value="diamond" className="mt-6">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {diamondPackages.map((pkg) => (
              <PackageCard key={pkg.id} pkg={pkg} currencyType="diamond" paymentDetails={paymentDetails} />
            ))}
          </div>
        </TabsContent>
        <TabsContent value="history" className="mt-6">
            <TransactionHistory userId={currentUser.id} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function WalletStatus({ user }: { user: User }) {
    return (
        <Card className="mb-6">
            <CardHeader className="flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-lg"><Wallet/> Your Wallet</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
                <div className="flex flex-col items-center gap-2 rounded-lg bg-secondary p-4">
                    <p className="text-3xl font-bold">{formatNumber(user.gold)}</p>
                    <p className="flex items-center gap-1 text-sm font-medium">🪙 Gold</p>
                </div>
                 <div className="flex flex-col items-center gap-2 rounded-lg bg-secondary p-4">
                    <p className="text-3xl font-bold">{formatNumber(user.diamonds)}</p>
                    <p className="flex items-center gap-1 text-sm font-medium">💎 Diamond</p>
                </div>
            </CardContent>
        </Card>
    )
}


function PackageCard({ pkg, currencyType, paymentDetails }: { pkg: CurrencyPackage; currencyType: Currency; paymentDetails: any; }) {
  // Only use USD prices
  const usdPrice = pkg.prices.find(p => p.currency === 'USD');

  if (!usdPrice) {
    return null; // Don't render card if no USD price is available
  }

  return (
    <Card className={cn("flex flex-col relative", pkg.isVIP && "border-primary border-2")}>
       {pkg.bonus && (
        <Badge className="absolute -top-2.5 left-1/2 -translate-x-1/2 flex items-center gap-1" variant="destructive">
            <Gift className="h-3 w-3"/> {pkg.bonus}
        </Badge>
      )}
      <CardHeader className="items-center text-center">
        <CardTitle className="flex items-center gap-2">
          <span className="text-3xl">{currencyType === 'gold' ? '🪙' : '💎'}</span>
          {pkg.amount}
        </CardTitle>
        <CardDescription className={cn(pkg.isVIP && "text-primary font-semibold")}>{pkg.name}</CardDescription>
      </CardHeader>
      <CardContent className="flex-1 text-center">
        <p className="text-3xl font-bold">
          {usdPrice.display}
        </p>
      </CardContent>
      <CardFooter>
        <PaymentDialog pkg={pkg} price={usdPrice} paymentDetails={paymentDetails}>
            <Button className="w-full" variant={pkg.isVIP ? 'default' : 'secondary'}>Purchase</Button>
        </PaymentDialog>
      </CardFooter>
    </Card>
  );
}


function PaymentDialog({ pkg, price, paymentDetails, children }: { pkg: CurrencyPackage, price: { currency: PaymentMethod; value: number; display: string; }, paymentDetails: any, children: React.ReactNode }) {
    const { toast } = useToast();
    const [screenshot, setScreenshot] = React.useState<File | null>(null);
    const [screenshotPreview, setScreenshotPreview] = React.useState<string | null>(null);
    const [isSubmitting, setIsSubmitting] = React.useState(false);
    const appContext = React.useContext(AppContext);

    const transactionCode = React.useMemo(() => {
        return `VIM-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
    }, []);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setScreenshot(file);
            const reader = new FileReader();
            reader.onloadend = () => setScreenshotPreview(reader.result as string);
            reader.readAsDataURL(file);
        }
    };
    
    const handleFinalSubmit = async () => {
        if (!screenshotPreview || !appContext?.currentUser) return;
        setIsSubmitting(true);
        try {
            const request: Omit<PurchaseRequest, 'id'|'timestamp'|'status'> = {
                user: appContext.currentUser,
                transaction: {
                    userId: appContext.currentUser.id,
                    id: '', // Will be generated by backend
                    date: new Date(),
                    package: pkg.name,
                    currency: pkg.id.includes('gold') ? 'gold' : 'diamond',
                    amount: pkg.amount,
                    price: price.display,
                    transactionCode,
                    status: 'Pending',
                },
                screenshot: screenshotPreview,
            };
            await createPurchaseRequest(request);

            toast({
                title: "Purchase Submitted",
                description: "Your purchase is under review. Currency will be added within 24 hours upon confirmation.",
            });
        } catch (error) {
            toast({ variant: 'destructive', title: 'Submission Failed', description: 'Could not submit your purchase request.' });
        } finally {
            setIsSubmitting(false);
        }
    }
    
    if (!appContext || !appContext.currentUser) return null;

    return (
        <Dialog>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent className="max-w-lg p-0">
                 <DialogHeader className="p-6 pb-0">
                    <DialogTitle>Complete Your Purchase</DialogTitle>
                    <DialogDescription>
                        You are purchasing the {pkg.name} package for {price.display}.
                    </DialogDescription>
                </DialogHeader>
                <ScrollArea className="max-h-[80vh] sm:max-h-none">
                    <div className="space-y-6 px-6 py-4">
                        <div>
                            <h3 className="font-semibold mb-2">1. Send Payment</h3>
                            <p className="text-sm text-muted-foreground mb-4">
                                Choose one of the mobile money accounts below and send the exact amount.
                            </p>
                            <Alert variant="destructive" className="mb-4">
                                <AlertTriangle className="h-4 w-4" />
                                <AlertTitle>Important: Use Your Transaction Code</AlertTitle>
                                <AlertDescription>
                                To ensure your purchase is approved quickly, please include your unique Transaction Code in the payment reference/note.
                                </AlertDescription>
                            </Alert>
                            <Card className="bg-blue-500/10 border-blue-500/30 text-center mb-4">
                                <CardHeader className="p-3">
                                    <CardTitle className="text-base text-blue-800 dark:text-blue-300">Your Transaction Code</CardTitle>
                                </CardHeader>
                                <CardContent className="p-3 pt-0">
                                    <p className="text-2xl font-mono font-bold tracking-widest text-blue-900 dark:text-blue-200">{transactionCode}</p>
                                </CardContent>
                            </Card>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                                <Card className="bg-secondary/50">
                                    <CardHeader>
                                        <CardTitle className="text-base text-orange-500">Orange Money (Liberia)</CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-1">
                                        <p><strong>Name:</strong> {paymentDetails.orange.name}</p>
                                        <p><strong>Number:</strong> {paymentDetails.orange.number}</p>
                                    </CardContent>
                                </Card>
                                <Card className="bg-secondary/50">
                                    <CardHeader>
                                        <CardTitle className="text-base text-yellow-500">Lonestar Cell MTN Momo</CardTitle>
                                        <CardDescription>For Liberia, Rwanda, Uganda, Zambia, South Africa, Cameroon, Ivory Coast, Ghana, Benin, Congo Brazzaville, Congo DRC, Gambia, Malawi, Sierra Leone & Togo.</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-1">
                                        <p><strong>Name:</strong> {paymentDetails.mtn.name}</p>
                                        <p><strong>Number:</strong> {paymentDetails.mtn.number}</p>
                                    </CardContent>
                                </Card>
                                <Card className="bg-secondary/50 sm:col-span-2">
                                    <CardHeader>
                                        <CardTitle className="text-base text-green-500">Momo PSB (for 🇳🇬 users)</CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-1">
                                        <p><strong>Name:</strong> {paymentDetails.momoPSB.name}</p>
                                        <p><strong>Number:</strong> {paymentDetails.momoPSB.number}</p>
                                    </CardContent>
                                </Card>
                            </div>
                        </div>
                        <div>
                            <h3 className="font-semibold mb-2">2. Submit Proof of Payment</h3>
                            <p className="text-sm text-muted-foreground mb-2">
                            Upload a screenshot of your payment confirmation. Make sure the date, time, and payment ID are clearly visible.
                            </p>
                            <Input type="file" accept="image/*" onChange={handleFileChange} />
                            {screenshotPreview && (
                                <div className="mt-4 p-2 border rounded-lg">
                                    <p className="text-xs text-muted-foreground mb-2">Screenshot Preview:</p>
                                    <img src={screenshotPreview} alt="Screenshot preview" className="max-w-full rounded-md" />
                                </div>
                            )}
                        </div>
                        <div className="text-center text-xs text-muted-foreground">
                            <ContactSupportDialog user={appContext.currentUser}>
                                <button className="hover:underline">Having an issue? Contact Support</button>
                            </ContactSupportDialog>
                        </div>
                    </div>
                </ScrollArea>
                <div className="p-6 pt-0">
                    <DialogClose asChild>
                        <Button onClick={handleFinalSubmit} disabled={!screenshot || isSubmitting} className="w-full">
                            {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CheckCircle className="mr-2 h-4 w-4" />}
                            {isSubmitting ? 'Submitting...' : 'Submit for Review'}
                        </Button>
                    </DialogClose>
                 </div>
            </DialogContent>
        </Dialog>
    )
}

function TransactionHistory({ userId }: { userId: string }) {
    const [transactions, setTransactions] = React.useState<Transaction[]>([]);

    React.useEffect(() => {
        const fetchTxs = async () => {
            if (!userId) return;
            const userTxs = await getTransactions(userId);
            setTransactions(userTxs);
        }
        fetchTxs();
    }, [userId]);

    const getStatusBadge = (status: Transaction['status']) => {
        switch (status) {
            case 'Completed': return <Badge variant="secondary" className="bg-green-100 text-green-800">Completed</Badge>;
            case 'Pending': return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">Pending</Badge>;
            case 'Rejected': return <Badge variant="destructive">Rejected</Badge>;
            default: return <Badge variant="secondary">{status}</Badge>;
        }
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle>Transaction History</CardTitle>
                <CardDescription>Your past currency purchases and their status.</CardDescription>
            </CardHeader>
            <CardContent>
                <ScrollArea className="h-96">
                     <div className="space-y-4">
                        {transactions.map(tx => (
                            <div key={tx.id} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 p-3 rounded-lg bg-secondary/50">
                                <div className="flex items-center gap-3">
                                    <div className="p-2 bg-background rounded-full">
                                        {tx.currency === 'gold' ? '🪙' : '💎'}
                                    </div>
                                    <div>
                                        <p className="font-bold">{tx.package} Package ({tx.amount})</p>
                                        <p className="text-xs text-muted-foreground">
                                            {format(tx.date, 'MMM d, yyyy')} • {tx.price}
                                        </p>
                                    </div>
                                </div>
                                <div className="flex items-center justify-between sm:justify-end gap-4">
                                     <p className="text-xs font-mono text-muted-foreground hidden sm:block">ID: {tx.transactionCode}</p>
                                    {getStatusBadge(tx.status)}
                                </div>
                            </div>
                        ))}
                         {transactions.length === 0 && <p className="text-center py-10 text-muted-foreground">No transactions yet.</p>}
                    </div>
                </ScrollArea>
            </CardContent>
        </Card>
    );
}
