
// This page is now obsolete as the project has been migrated to Appwrite.
// The custom action verification flow has been replaced with a more direct
// service-level implementation. This file is kept to prevent build errors
// from old references but is no longer used and can be deleted.

'use client';
import { useRouter } from 'next/navigation';
import * as React from 'react';
import { Loader2 } from 'lucide-react';

export default function DeprecatedVerifyActionPage() {
    const router = useRouter();
    React.useEffect(() => {
        router.replace('/login');
    }, [router]);

    return (
         <div className="flex min-h-screen w-full flex-col items-center justify-center bg-background p-4 text-center">
            <Loader2 className="h-16 w-16 animate-spin text-primary" />
            <h1 className="text-2xl font-bold mt-4">Redirecting...</h1>
        </div>
    );
}
