'use client';

import * as React from 'react';
import { useParams, notFound, useRouter } from 'next/navigation';
import { PostCard } from '@/components/post-card';
import { type Post, mockPosts } from '@/lib/data';
import { Loader2, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function PostPage() {
  const router = useRouter();
  const params = useParams();
  const postId = params.postId as string;
  const [post, setPost] = React.useState<Post | null>(null);
  const [isLoading, setIsLoading] = React.useState(true);
  
  React.useEffect(() => {
    // In a real app, you would fetch the post from your backend
    const foundPost = mockPosts.find(p => p.id === postId);
    if(foundPost) {
      setPost(foundPost);
    }
    setIsLoading(false);
  }, [postId]);

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!post) {
    return notFound();
  }

  return (
    <div className="container mx-auto max-w-2xl py-4 sm:py-6">
       <header className="mb-4">
        <Button variant="ghost" onClick={() => router.back()}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Feed
        </Button>
      </header>
      <PostCard post={post} onBoostPost={() => {}}/>
    </div>
  );
}
