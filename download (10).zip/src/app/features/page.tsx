
'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import {
  ArrowLeft,
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  Video,
  Send,
  Users,
  Palette,
  Music,
  Disc,
  UploadCloud,
  Gift,
  Lock,
  Diamond,
  LayoutDashboard,
  Sparkles,
  Award,
  Shield,
  FileText,
  Star,
  BarChart3,
  Mic,
  ImageIcon,
  Banknote,
  CheckCircle,
  UserPlus,
  MapPin,
  Smile,
  Sticker,
  Type as TypeIcon,
  Unlock,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

const features = [
  {
    icon: FileText,
    title: "The Social Feed",
    description: "Your central hub for connecting with others. Create posts with text, photos, videos, and interactive polls. Express yourself with reactions, join conversations in the comments, share content you love, and save posts to revisit later.",
  },
  {
    icon: Video,
    title: "Reels",
    description: "Immerse yourself in a world of short-form video. Any video you post automatically becomes part of the Reels feed, where it can be discovered by a global audience through personalized 'For You' and 'Following' tabs.",
  },
   {
    icon: Star,
    title: "Stories & Highlights",
    description: "Share ephemeral moments from your day with Stories. For your most cherished memories, you can group them into Highlights that remain permanently on your profile for everyone to see.",
  },
  {
    icon: Send,
    title: "Real-Time Messaging",
    description: "Stay in touch with friends and groups. Our chat system supports direct messages, group conversations, voice memos, image sharing, in-chat polls, and unique AI-generated chat backgrounds.",
  },
  {
    icon: Music,
    title: "Music Integration",
    description: "Discover, play, and share music. Explore trending charts, curated playlists, and new albums. Aspiring artists can even upload their own tracks and allow others to use their original sounds in video posts.",
  },
    {
    icon: Shield,
    title: "AI Content Moderation",
    description: "Our platform uses advanced AI to automatically review content for potential community guideline violations, helping to keep VIMore a safe and positive space for everyone.",
  },
];

const monetizationFeatures = [
    {
        icon: Gift,
        title: "Gifting & Tipping",
        description: "Show appreciation for your favorite creators by sending them virtual gifts or tips using Gold. It's a direct way to support the content you love."
    },
    {
        icon: Lock,
        title: "Locked Posts",
        description: "Creators can offer exclusive content to their supporters. For a small amount of Gold, you can unlock special posts and get access to content not available to anyone else."
    },
    {
        icon: Diamond,
        title: "Subscriptions",
        description: "Become a true fan by subscribing to a creator for a monthly Diamond fee. Subscriptions often unlock exclusive badges, content, and other special perks."
    },
     {
        icon: Banknote,
        title: "Cash Out",
        description: "Creators can convert their earned Gold and Diamonds into real currency. The Cash Out feature in the dashboard allows you to securely transfer your earnings to your mobile money account."
    }
]

const currencyInfo = [
    {
        icon: '🪙',
        title: "Gold",
        description: "Gold is the platform's primary currency. Use it to tip creators for their music, unlock exclusive locked posts, and send smaller, fun gifts."
    },
    {
        icon: '💎',
        title: "Diamonds",
        description: "Diamonds are the premium currency. Use them to purchase high-value gifts, subscribe to your favorite creators for exclusive perks, and get your account verified."
    }
]

const creatorTools = [
    {
        icon: LayoutDashboard,
        title: 'Creator Dashboard',
        description: 'Track your growth, see detailed post analytics, and monitor your earnings all in one place.'
    },
    {
        icon: Sparkles,
        title: 'AI-Powered Suggestions',
        description: 'Overcome creator\'s block with AI-generated post ideas and creative challenges tailored to you.'
    },
    {
        icon: CheckCircle,
        title: 'Profile Verification',
        description: 'Purchase a verification badge with Diamonds to prove your authenticity and build trust with your audience.'
    },
    {
        icon: BarChart3,
        title: 'Interactive Polls',
        description: 'Engage your audience directly by adding polls to your posts to gather opinions and feedback.'
    },
    {
        icon: UserPlus,
        title: 'Advanced Post Tools',
        description: 'Enhance your posts by adding relevant hashtags, tagging friends, checking in at a location, and sharing how you\'re feeling to make your content more discoverable and personal.'
    },
     {
        icon: Palette,
        title: 'Creative Editing Effects',
        description: 'Bring your video and story content to life with a variety of editing tools, including AI-powered visual effects, fun stickers, and custom text overlays.'
    }
]

export default function FeaturesPage() {
  const router = useRouter();

  return (
    <div className="bg-background min-h-screen">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft />
        </Button>
        <h1 className="text-xl font-bold">How VIMore Works</h1>
      </header>
      <main className="container mx-auto max-w-3xl py-6 space-y-8">
        <section className="text-center">
            <h2 className="font-headline text-3xl md:text-4xl font-bold">Our Story</h2>
            <div className="prose dark:prose-invert mx-auto mt-4">
                <p>VIMore was born from a simple yet powerful mission: to build a platform for creators, by a creator. This journey began with the vision of our Founder &amp; CEO, <strong>Amos B Kortu</strong> of <strong>Media Tech Liberia</strong>. Having witnessed firsthand the challenges and triumphs of the creative process, he was driven by a passion to design a digital sanctuary where artistry is truly celebrated.</p>
                <p>Proudly created in Liberia 🇱🇷, VIMore is the result of that vision—a space where community is nurtured and every creator has the tools they need not just to share, but to thrive. We believe in empowering voices, fostering genuine connections, and building a sustainable ecosystem where creativity can become a profession, not just a passion. Welcome to VIMore—a platform built on the foundation of creator empowerment.</p>
            </div>
        </section>

        <section className="text-center">
            <h2 className="font-headline text-3xl md:text-4xl font-bold">Welcome to VIMore</h2>
            <p className="text-muted-foreground mt-2 text-lg">Your guide to all the features on our platform.</p>
        </section>

        <Accordion type="multiple" defaultValue={['item-1', 'item-2', 'item-3']} className="w-full">
            <AccordionItem value="item-1">
                <AccordionTrigger className="text-2xl font-bold">Core Features</AccordionTrigger>
                <AccordionContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
                        {features.map((feature, index) => (
                        <Card key={index}>
                            <CardHeader>
                            <CardTitle className="flex items-center gap-3">
                                <feature.icon className="h-6 w-6 text-primary" />
                                {feature.title}
                            </CardTitle>
                            </CardHeader>
                            <CardContent>
                            <p className="text-sm text-muted-foreground">{feature.description}</p>
                            </CardContent>
                        </Card>
                        ))}
                    </div>
                </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-2">
                <AccordionTrigger className="text-2xl font-bold">Monetization</AccordionTrigger>
                <AccordionContent>
                     <p className="text-muted-foreground py-4">We believe in empowering creators. Here’s how you can support them and how they can earn on VIMore.</p>
                     <div className="space-y-4">
                        <Card>
                             <CardHeader><CardTitle>Virtual Currencies</CardTitle></CardHeader>
                             <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {currencyInfo.map(currency => (
                                    <div key={currency.title} className="p-4 rounded-lg bg-secondary">
                                        <p className="text-4xl">{currency.icon}</p>
                                        <h4 className="font-bold mt-2">{currency.title}</h4>
                                        <p className="text-xs text-muted-foreground mt-1">{currency.description}</p>
                                    </div>
                                ))}
                             </CardContent>
                        </Card>
                        
                        <Card>
                            <CardHeader><CardTitle>Conversion &amp; Payouts</CardTitle></CardHeader>
                             <CardContent className="space-y-4">
                                <p className="text-sm text-muted-foreground">When cashing out, your virtual currencies are converted to real money. Note: a 10% platform fee applies to all payouts.</p>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                                    <div className="space-y-2 rounded-lg bg-secondary p-4">
                                        <h3 className="font-bold">💎 Diamond Value</h3>
                                        <p>1 Diamond = <span className="font-semibold">$0.50 USD</span></p>
                                        <p>1 Diamond = <span className="font-semibold">100 LD</span></p>
                                    </div>
                                    <div className="space-y-2 rounded-lg bg-secondary p-4">
                                        <h3 className="font-bold">🪙 Gold Value</h3>
                                        <p>1 Gold = <span className="font-semibold">$0.01 USD</span></p>
                                        <p>1 Gold = <span className="font-semibold">1.9 LD</span></p>
                                    </div>
                                </div>
                             </CardContent>
                        </Card>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {monetizationFeatures.map((feature, index) => (
                                <Card key={index}>
                                    <CardHeader>
                                    <CardTitle className="flex items-center gap-2 text-lg">
                                        <feature.icon className="h-5 w-5 text-primary" />
                                        {feature.title}
                                    </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                    <p className="text-sm text-muted-foreground">{feature.description}</p>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    </div>
                </AccordionContent>
            </AccordionItem>
             <AccordionItem value="item-3">
                <AccordionTrigger className="text-2xl font-bold">Creator Tools</AccordionTrigger>
                 <AccordionContent>
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
                        {creatorTools.map((tool, index) => (
                        <Card key={index}>
                            <CardHeader>
                            <CardTitle className="flex items-center gap-3">
                                <tool.icon className="h-6 w-6 text-primary" />
                                {tool.title}
                            </CardTitle>
                            </CardHeader>
                            <CardContent>
                            <p className="text-sm text-muted-foreground">{tool.description}</p>
                            </CardContent>
                        </Card>
                        ))}
                     </div>
                </AccordionContent>
            </AccordionItem>
        </Accordion>
      </main>
    </div>
  );
}
