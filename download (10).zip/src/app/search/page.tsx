
'use client';

import * as React from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { ArrowLeft, Search as SearchIcon, X, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { searchAll } from '@/services/searchService';
import type { Song, Album, User, Post } from '@/lib/data';
import { PostCard } from '@/components/post-card';
import Link from 'next/link';
import { UserAvatar } from '@/components/user-avatar';
import Image from 'next/image';
import { useMusicPlayer } from '@/components/music/music-player-provider';
import { VerifiedBadge } from '@/components/verified-badge';

type SearchResults = {
  top: (User | Post | Song | Album)[];
  users: User[];
  posts: Post[];
  songs: Song[];
  albums: Album[];
  artists: User[];
};

export default function SearchPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get('q') || '';
  
  const [query, setQuery] = React.useState(initialQuery);
  const [results, setResults] = React.useState<SearchResults | null>(null);
  const [activeTab, setActiveTab] = React.useState('top');
  const [isLoading, setIsLoading] = React.useState(false);

  React.useEffect(() => {
    const handler = setTimeout(() => {
      if (query.length > 1) {
        setIsLoading(true);
        searchAll(query).then(res => {
          const topResults = [
            ...res.users.slice(0, 1),
            ...res.posts.slice(0, 1),
            ...res.songs.slice(0, 1),
            ...res.albums.slice(0, 1),
            ...res.artists.slice(0, 1),
          ];
          setResults({ top: topResults, ...res });
          setIsLoading(false);
        });
      } else {
        setResults(null);
      }
    }, 500); // Debounce search

    return () => clearTimeout(handler);
  }, [query]);
  
  const handleTabChange = (value: string) => {
    setActiveTab(value);
  }

  const renderTopResults = () => {
    if (!results || results.top.length === 0) return <EmptyState />;
    
    return results.top.map((item, index) => {
        if (!item) return null;
        if ('username' in item) return <UserResult key={`top-user-${item.id}`} user={item as User} />;
        if ('content' in item) return <PostCard key={`top-post-${item.id}`} post={item as Post} onBoostPost={()=>{}} />;
        if ('album' in item) return <SongResult key={`top-song-${item.id}`} song={item as Song} />;
        if ('cover' in item) return <AlbumResult key={`top-album-${item.id}`} album={item as Album} />;
        // 'artist' type is just a User, so it's caught by the first condition.
        return null;
    });
  }

  return (
    <div className="flex flex-col h-screen">
      <header className="flex items-center gap-2 border-b p-4 shrink-0">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft />
        </Button>
        <div className="relative flex-1">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            placeholder="Search for people, posts, music..."
            className="pl-10 text-base"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
          />
          {query && (
            <Button variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 rounded-full" onClick={() => setQuery('')}>
                <X className="h-4 w-4"/>
            </Button>
          )}
        </div>
      </header>
      
      {isLoading ? (
        <div className="flex flex-1 items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      ) : query.length > 1 && results ? (
        <Tabs value={activeTab} onValueChange={handleTabChange} className="flex-1 flex flex-col overflow-hidden">
            <TabsList className="grid w-full grid-cols-4 shrink-0">
                <TabsTrigger value="top">Top</TabsTrigger>
                <TabsTrigger value="people">People</TabsTrigger>
                <TabsTrigger value="posts">Posts</TabsTrigger>
                <TabsTrigger value="music">Music</TabsTrigger>
            </TabsList>
            <ScrollArea className="flex-1">
                <TabsContent value="top" className="mt-0 p-4 space-y-4">
                    {renderTopResults()}
                </TabsContent>
                <TabsContent value="people" className="mt-0 p-4 space-y-2">
                    {results.users.length > 0 ? results.users.map(u => <UserResult key={u.id} user={u}/>) : <EmptyState />}
                </TabsContent>
                <TabsContent value="posts" className="mt-0 p-4 space-y-4">
                    {results.posts.length > 0 ? results.posts.map(p => <PostCard key={p.id} post={p} onBoostPost={()=>{}}/>) : <EmptyState />}
                </TabsContent>
                <TabsContent value="music" className="mt-0 p-4 space-y-4">
                    {results.songs.length > 0 && <section>
                        <h2 className="font-bold text-lg mb-2">Songs</h2>
                        {results.songs.map(s => <SongResult key={s.id} song={s}/>)}
                    </section>}
                    {results.albums.length > 0 && <section>
                        <h2 className="font-bold text-lg mb-2">Albums</h2>
                        {results.albums.map(a => <AlbumResult key={a.id} album={a}/>)}
                    </section>}
                     {results.artists.length > 0 && <section>
                        <h2 className="font-bold text-lg mb-2">Artists</h2>
                        {results.artists.map(a => <ArtistResult key={a.id} artist={a}/>)}
                    </section>}
                    {(results.songs.length + results.albums.length + results.artists.length) === 0 && <EmptyState />}
                </TabsContent>
            </ScrollArea>
        </Tabs>
      ) : (
        <div className="flex flex-col items-center justify-center text-center flex-1 text-muted-foreground p-4">
          <SearchIcon className="h-16 w-16 mb-4"/>
          <h2 className="font-bold text-xl text-foreground">Find anything</h2>
          <p>Search for people, posts, music, and more.</p>
        </div>
      )}
    </div>
  );
}

function EmptyState() {
  return (
    <div className="text-center py-12 text-muted-foreground">
      <p>No results found.</p>
    </div>
  )
}

function UserResult({ user }: { user: User }) {
  return (
    <Link href={`/profile/${user.username}`} className="flex items-center gap-3 p-3 rounded-lg hover:bg-accent -m-3">
      <UserAvatar user={user} className="h-12 w-12"/>
      <div>
        <p className="font-semibold inline-flex items-center">
          {user.name}
          <VerifiedBadge user={user} />
        </p>
        <p className="text-sm text-muted-foreground">@{user.username}</p>
      </div>
    </Link>
  )
}

function SongResult({ song }: { song: Song }) {
    const { playSong } = useMusicPlayer();
    
    return (
        <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-accent -m-2">
            <Image src={song.album.cover.imageUrl} alt={song.album.title} width={40} height={40} className="w-10 h-10 rounded-md"/>
            <div className="flex-1">
                <p className="font-semibold">{song.title}</p>
                <p className="text-sm text-muted-foreground">{song.artist.name}</p>
            </div>
            <Button variant="ghost" size="sm" onClick={() => playSong(song)}>Play</Button>
        </div>
    )
}

function AlbumResult({ album }: { album: Album }) {
    return (
        <Link href={`/music/album/${album.id}`} className="flex items-center gap-3 p-2 rounded-lg hover:bg-accent -m-2">
            <Image src={album.cover.imageUrl} alt={album.title} width={40} height={40} className="w-10 h-10 rounded-md"/>
            <div className="flex-1">
                <p className="font-semibold">{album.title}</p>
                <p className="text-sm text-muted-foreground">{album.artist.name} • Album</p>
            </div>
        </Link>
    )
}

function ArtistResult({ artist }: { artist: User }) {
    return (
        <Link href={`/profile/${artist.username}`} className="flex items-center gap-3 p-2 rounded-lg hover:bg-accent -m-2">
            <UserAvatar user={artist} className="w-10 h-10" />
            <div className="flex-1">
                <p className="font-semibold inline-flex items-center">
                  {artist.name}
                  <VerifiedBadge user={artist} />
                </p>
                <p className="text-sm text-muted-foreground">Artist</p>
            </div>
        </Link>
    )
}
