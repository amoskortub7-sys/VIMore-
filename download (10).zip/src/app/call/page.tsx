
'use client';

import * as React from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { Mic, MicOff, PhoneOff, Video, VideoOff, Loader2, AlertTriangle, User } from 'lucide-react';
import AgoraRTC, { IAgoraRTCClient, IAgoraRTCRemoteUser, IMicrophoneAudioTrack, ICameraVideoTrack } from 'agora-rtc-sdk-ng';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { formatTime } from '@/lib/utils';
import { Card, CardContent } from '@/components/ui/card';
import { generateAgoraToken } from '@/app/actions/agora';

const client: IAgoraRTCClient = AgoraRTC.createClient({ mode: 'rtc', codec: 'vp8' });

export default function CallPage() {
  const router = useRouter();
  const { toast } = useToast();
  const searchParams = useSearchParams();
  const callType = searchParams.get('type') || 'video';
  const conversationId = searchParams.get('conversationId');
  const remoteUserName = searchParams.get('remoteUserName') || 'the user';

  const localVideoRef = React.useRef<HTMLDivElement>(null);
  const remoteVideoRef = React.useRef<HTMLDivElement>(null);
  
  const [localTracks, setLocalTracks] = React.useState<{ audio: IMicrophoneAudioTrack | null, video: ICameraVideoTrack | null }>({ audio: null, video: null });
  const [remoteUser, setRemoteUser] = React.useState<IAgoraRTCRemoteUser | null>(null);

  const [status, setStatus] = React.useState<'connecting' | 'connected' | 'denied'>('connecting');
  const [isMuted, setIsMuted] = React.useState(false);
  const [isCameraOff, setIsCameraOff] = React.useState(callType === 'audio');
  const [callDuration, setCallDuration] = React.useState(0);
  
  // --- Call Duration Timer ---
  React.useEffect(() => {
    let timer: NodeJS.Timeout | undefined;
    if (status === 'connected') {
      timer = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [status]);

  // --- Agora Call Logic ---
  React.useEffect(() => {
    const channelName = conversationId || 'default-channel';
    const uid = Math.floor(Math.random() * 10000);

    const handleUserPublished = async (user: IAgoraRTCRemoteUser, mediaType: 'audio' | 'video') => {
      await client.subscribe(user, mediaType);
      setRemoteUser(user);
      setStatus('connected');
      
      if (mediaType === 'video' && remoteVideoRef.current) {
        user.videoTrack?.play(remoteVideoRef.current);
      }
      if (mediaType === 'audio') {
        user.audioTrack?.play();
      }
    };
    
    const handleUserUnpublished = () => {
        setRemoteUser(null);
    };

    const joinChannel = async () => {
      try {
        const { token, appId } = await generateAgoraToken(channelName, uid);

        if (!appId) {
            throw new Error('Agora App ID not returned from server.');
        }

        await client.join(appId, channelName, token, uid);
        
        const audioTrack = await AgoraRTC.createMicrophoneAudioTrack();
        let videoTrack: ICameraVideoTrack | null = null;
        if (callType === 'video') {
            videoTrack = await AgoraRTC.createCameraVideoTrack();
             if (localVideoRef.current) {
                videoTrack.play(localVideoRef.current);
            }
        }
        
        await client.publish(Object.values({ audioTrack, videoTrack }).filter(Boolean) as (IMicrophoneAudioTrack | ICameraVideoTrack)[]);
        setLocalTracks({ audio: audioTrack, video: videoTrack });
        
        // If not a video call, immediately disable the video track
        if (callType === 'audio' && videoTrack) {
            await videoTrack.setEnabled(false);
            setIsCameraOff(true);
        }

      } catch (error) {
        console.error('Agora join failed:', error);
        setStatus('denied');
        toast({
            variant: 'destructive',
            title: 'Call Failed',
            description: 'Could not connect to the call service. Ensure all API keys and certificates are set correctly.',
        });
      }
    };

    client.on('user-published', handleUserPublished);
    client.on('user-unpublished', handleUserUnpublished);

    joinChannel();

    return () => {
      localTracks.audio?.close();
      localTracks.video?.close();
      client.leave();
      client.off('user-published', handleUserPublished);
      client.off('user-unpublished', handleUserUnpublished);
    };
  }, [conversationId, callType, toast]);

  // --- UI Handlers ---
  const handleEndCall = () => {
    localTracks.audio?.close();
    localTracks.video?.close();
    client.leave();
    
    const params = new URLSearchParams();
    if (conversationId) {
      params.set('conversationId', conversationId);
      if (callDuration > 0) {
        params.set('callEnded', 'true');
        params.set('callDuration', callDuration.toString());
        params.set('callType', callType);
      }
    }
    router.push(`/messages?${params.toString()}`);
  };

  const toggleMute = async () => {
    if (localTracks.audio) {
      await localTracks.audio.setEnabled(!isMuted);
      setIsMuted(!isMuted);
    }
  };

  const toggleCamera = async () => {
    if (callType !== 'video' || !localTracks.video) return;
    await localTracks.video.setEnabled(!isCameraOff);
    setIsCameraOff(!isCameraOff);
  };


  if (status === 'connecting') {
    return (
      <div className="flex h-screen w-full flex-col items-center justify-center gap-4 bg-gray-900 text-white p-4 text-center">
        <div className="h-32 w-32 mb-4 rounded-full bg-gray-700 flex items-center justify-center">
          <User className="h-16 w-16 text-gray-500" />
        </div>
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="text-lg">Calling {remoteUserName}...</p>
      </div>
    );
  }
  
   if (status === 'denied') {
    return (
      <div className="flex h-screen w-full flex-col items-center justify-center gap-4 bg-background p-4">
        <Alert variant="destructive" className="max-w-md">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Call Failed</AlertTitle>
            <AlertDescription>
                Could not establish a connection. Please check your permissions and network. If you haven't already, make sure to add your Agora App ID and Certificate to the .env file.
            </AlertDescription>
        </Alert>
        <Button onClick={() => router.push('/messages')}>Back to Messages</Button>
      </div>
    );
  }

  const showRemoteVideo = callType === 'video' && status === 'connected' && remoteUser?.hasVideo;

  return (
    <div className="relative flex h-screen w-full flex-col bg-gray-900 text-white">
      {/* Header */}
      <header className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between p-4">
        <div className="text-center text-white">
            <p className="text-xl font-bold">{remoteUserName}</p>
        </div>
        {status === 'connected' && 
            <div className="flex items-center gap-2 rounded-full bg-black/30 px-3 py-1 text-sm font-mono">
                <div className="h-2 w-2 rounded-full bg-red-500 animate-pulse" />
                {formatTime(callDuration)}
            </div>
        }
      </header>

      {/* Main content */}
      <main className="flex-1 flex items-center justify-center overflow-hidden p-4">
        <div className="relative w-full h-full max-w-6xl max-h-[80vh]">
            <div ref={remoteVideoRef} className={cn("h-full w-full rounded-xl bg-black", !showRemoteVideo && 'hidden')} />

            {!showRemoteVideo && (
                <Card className="h-full w-full bg-gray-800/50 border-gray-700 flex flex-col items-center justify-center text-center">
                    <CardContent className="flex flex-col items-center justify-center p-6">
                        <div className="h-40 w-40 mb-6 rounded-full bg-gray-700 flex items-center justify-center">
                            <User className="h-24 w-24 text-gray-500" />
                        </div>
                        <h2 className="text-3xl font-bold">{remoteUserName}</h2>
                        {callType === 'video' && status === 'connected' ? (
                            <p className="text-muted-foreground mt-2">Camera is off</p>
                        ) : (
                             <p className="text-muted-foreground mt-2">Audio Call</p>
                        )}
                    </CardContent>
                </Card>
            )}

            {callType === 'video' && <LocalVideoPreview videoRef={localVideoRef} isCameraOff={isCameraOff} />}
        </div>
      </main>

      {/* Call Controls */}
      <footer className="absolute bottom-0 left-0 right-0 z-20 flex justify-center p-6">
        <div className="flex items-center gap-4 rounded-full bg-black/50 p-3 backdrop-blur-sm">
          <Button
            variant="ghost"
            size="icon"
            className={cn("h-14 w-14 rounded-full hover:bg-white/20", isMuted ? "bg-white/10" : "bg-primary/80")}
            onClick={toggleMute}
          >
            {isMuted ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
          </Button>

          {callType === 'video' && (
            <Button
              variant="ghost"
              size="icon"
              className={cn("h-14 w-14 rounded-full hover:bg-white/20", isCameraOff ? "bg-white/10" : "bg-primary/80")}
              onClick={toggleCamera}
            >
              {isCameraOff ? <VideoOff className="h-6 w-6" /> : <Video className="h-6 w-6" />}
            </Button>
          )}

          <Button
            size="icon"
            className="h-14 w-14 rounded-full bg-destructive hover:bg-destructive/80"
            onClick={handleEndCall}
          >
            <PhoneOff className="h-6 w-6" />
          </Button>
        </div>
      </footer>
    </div>
  );
}


// --- Local Video Preview ---
interface LocalVideoPreviewProps {
    videoRef: React.RefObject<HTMLDivElement>;
    isCameraOff: boolean;
}

function LocalVideoPreview({ videoRef, isCameraOff }: LocalVideoPreviewProps) {
    return (
        <div
            className="absolute h-48 w-36 bottom-24 right-4 overflow-hidden rounded-lg border-2 border-primary bg-black group shadow-lg"
        >
            <div ref={videoRef} className={cn("h-full w-full object-cover scale-x-[-1]", isCameraOff && 'hidden')} />
            {isCameraOff && (
              <div className="flex h-full w-full items-center justify-center">
                <VideoOff className="h-8 w-8 text-muted-foreground" />
              </div>
            )}
            <div className="absolute bottom-1 left-1 text-xs bg-black/50 px-1 rounded z-10">You</div>
        </div>
    );
}
