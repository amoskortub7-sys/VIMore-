
'use client';

import * as React from 'react';
import type { Post } from '@/lib/data';
import { VideoPost } from '@/components/video-post';
import { AdVideoPost } from '@/components/ad-video-post';
import { ArrowLeft, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useRouter } from 'next/navigation';
import { cn } from '@/lib/utils';
import { getPosts } from '@/services/postService';
import { getFollowing } from '@/services/userService';
import { AppContext } from '@/components/app-shell';

export default function ReelsPage() {
  const router = useRouter();
  const [activeTab, setActiveTab] = React.useState<'forYou' | 'following'>('forYou');
  
  const [allVideoPosts, setAllVideoPosts] = React.useState<Post[]>([]);
  const [followedUserIds, setFollowedUserIds] = React.useState<Set<string>>(new Set());
  const [isLoading, setIsLoading] = React.useState(true);

  const appContext = React.useContext(AppContext);
  const currentUser = appContext?.currentUser;

  React.useEffect(() => {
    const fetchData = async () => {
      if (!currentUser) return;
      setIsLoading(true);
      try {
        const [posts, following] = await Promise.all([
          getPosts(),
          getFollowing(currentUser.id),
        ]);
        setAllVideoPosts(posts.filter(p => p.video));
        setFollowedUserIds(new Set(following.map(f => f.id)));
      } catch (error) {
        console.error("Failed to fetch reels data", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, [currentUser]);


  const rawPosts = React.useMemo(() => {
    if (activeTab === 'following') {
      return allVideoPosts.filter(post => followedUserIds.has(post.author.id));
    }
    // For 'For You', we can just show all videos for now. A real algorithm would be more complex.
    return allVideoPosts;
  }, [activeTab, allVideoPosts, followedUserIds]);

  const feedItems = React.useMemo(() => {
    const items: (Post | { isAd: true; id: string })[] = [];
    const adFrequency = 5;
    
    rawPosts.forEach((post, index) => {
      items.push(post);
      if ((index + 1) % adFrequency === 0) {
        items.push({ isAd: true, id: `ad-${index}` });
      }
    });
    
    return items;
  }, [rawPosts]);

  if (isLoading) {
    return (
      <div className="flex h-screen w-screen items-center justify-center bg-black text-white">
        <Loader2 className="h-12 w-12 animate-spin" />
      </div>
    );
  }

  return (
    <div className="relative h-screen w-screen overflow-hidden snap-y snap-mandatory bg-black">
      <header className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between p-4">
        <Button variant="ghost" size="icon" className="rounded-full bg-black/30 text-white" onClick={() => router.back()}>
            <ArrowLeft />
        </Button>
        <div className="flex items-center gap-4">
            <button 
                onClick={() => setActiveTab('following')}
                className={cn(
                    "font-semibold text-lg text-white/70 transition-colors",
                    activeTab === 'following' && 'text-white scale-110'
                )}
            >
                Following
            </button>
             <button 
                onClick={() => setActiveTab('forYou')}
                className={cn(
                    "font-semibold text-lg text-white/70 transition-colors",
                    activeTab === 'forYou' && 'text-white scale-110'
                )}
            >
                For You
            </button>
        </div>
        <div className="w-10"></div>
      </header>
      {feedItems.map((item) => (
        <div key={item.id} className="relative h-screen w-screen snap-start">
          {'isAd' in item ? <AdVideoPost /> : <VideoPost post={item} />}
        </div>
      ))}
      {feedItems.length === 0 && (
        <div className="flex h-screen w-screen items-center justify-center text-center text-white">
            <div>
                <h2 className="text-2xl font-bold">No videos to show</h2>
                <p className="text-muted-foreground mt-2">Follow more people to see their videos here.</p>
            </div>
        </div>
      )}
    </div>
  );
}
