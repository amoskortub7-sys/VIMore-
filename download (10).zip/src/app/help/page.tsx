'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Input } from '@/components/ui/input';

const faqs = [
  {
    question: "How do I change my username?",
    answer: "You can change your username from the Settings page under the Account section. Click on 'Change Username' to enter a new one."
  },
  {
    question: "How does two-factor authentication (2FA) work?",
    answer: "2FA adds an extra layer of security to your account. Once enabled in Security settings, you will need to enter a code from your authenticator app each time you log in."
  },
  {
    question: "How can I get a verified badge?",
    answer: "You can purchase a verified badge using Diamonds from your profile page. This helps confirm your identity to the community."
  },
  {
    question: "What are Gold and Diamonds used for?",
    answer: "Gold and Diamonds are virtual currencies. Gold is used for tipping creators and unlocking content, while Diamonds are used for purchasing verification and premium gifts."
  },
  {
    question: "How do I report a post or user?",
    answer: "You can report a post or user by clicking the 'More' (three dots) icon on a post or profile and selecting the 'Report' option. Our moderation team will review it."
  }
]

export default function HelpPage() {
  const router = useRouter();
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredFaqs = faqs.filter(faq => 
    faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
    faq.answer.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-background min-h-screen">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft />
        </Button>
        <h1 className="text-xl font-bold">Help Center</h1>
      </header>
      <main className="container mx-auto max-w-2xl py-6">
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input 
            placeholder="Search for help articles..."
            className="pl-10 text-base"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <Accordion type="single" collapsible className="w-full">
          {filteredFaqs.map((faq, index) => (
            <AccordionItem key={index} value={`item-${index}`}>
              <AccordionTrigger className="text-left">{faq.question}</AccordionTrigger>
              <AccordionContent>
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
        
        {filteredFaqs.length === 0 && (
            <div className="text-center py-20 text-muted-foreground">
                <p className="font-semibold">No results found</p>
                <p>Try searching for a different keyword.</p>
            </div>
        )}
      </main>
    </div>
  );
}
