import { PostCardSkeleton } from '@/components/post-card-skeleton';
import { Skeleton } from '@/components/ui/skeleton';

export default function HomeLoading() {
  return (
    <div className="container mx-auto max-w-2xl py-4 sm:py-6">
      <div className="flex flex-col gap-4">
        {/* Stories Skeleton */}
        <div className="flex gap-2 p-2">
           <div className="h-48 w-28 shrink-0 space-y-2">
                <Skeleton className="h-full w-full rounded-lg"/>
            </div>
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="h-48 w-28 shrink-0 space-y-2">
                <Skeleton className="h-full w-full rounded-lg"/>
            </div>
          ))}
        </div>

        {/* Post Feed Skeleton */}
        <div className="flex flex-col">
          <PostCardSkeleton />
          <PostCardSkeleton />
          <PostCardSkeleton />
        </div>
      </div>
    </div>
  );
}
