'use client';

import { Stories } from '@/components/stories';
import { PostCard } from '@/components/post-card';
import { AdPostCard } from '@/components/ad-post-card';
import { Post } from '@/lib/data';
import * as React from 'react';
import { useToast } from '@/hooks/use-toast';
import { FollowSuggestionsCard } from '@/components/follow-suggestions-card';
// import { rankFeedContent } from '@/ai/flows/rank-feed-content';
import { PostCardSkeleton } from '@/components/post-card-skeleton';
import { AppContext } from '@/components/app-shell';
import { getPosts, updatePost } from '@/services/postService';
import { Loader2 } from 'lucide-react';

export default function HomePage() {
  const [posts, setPosts] = React.useState<Post[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  
  const { toast } = useToast();
  const appContext = React.useContext(AppContext);
  const currentUser = appContext?.currentUser;

  React.useEffect(() => {
    const fetchPosts = async () => {
      if (!currentUser) return;
      
      setIsLoading(true);
      try {
        const allPosts = await getPosts();
        
        // AI ranking is disabled.
        const rankedPosts = allPosts.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

        setPosts(rankedPosts);

      } catch (error) {
        console.error("Failed to get posts:", error);
        toast({
          variant: "destructive",
          title: "Could not load feed",
          description: "There was an issue fetching posts from the server.",
        });
        setPosts([]); // Set to empty on error
      } finally {
        setIsLoading(false);
      }
    };

    fetchPosts();
  }, [currentUser, toast]);


  const handleBoostPost = async (postId: string) => {
    try {
        await updatePost(postId, { isBoosted: true });
        setPosts(prevPosts => 
          prevPosts.map(p => 
            p.id === postId ? { ...p, isBoosted: true } : p
          )
        );
        toast({
          title: "Post Boosted!",
          description: "Your post is now being shown to a wider audience.",
        });
    } catch (error) {
        toast({
            variant: 'destructive',
            title: 'Failed to boost post',
        })
    }
  };

  const adFrequency = 4;

  const renderFeed = () => {
    if (isLoading) {
        return (
             <div className="flex flex-col">
                <PostCardSkeleton />
                <PostCardSkeleton />
                <PostCardSkeleton />
            </div>
        )
    }
    
    return (
        <div className="flex flex-col gap-4">
           <FollowSuggestionsCard />
           {posts.map((post, index) => (
            <React.Fragment key={post.id}>
              <PostCard post={post} onBoostPost={() => handleBoostPost(post.id)} />
              {(index + 1) % adFrequency === 0 && <AdPostCard />}
            </React.Fragment>
          ))}
        </div>
    )
  }

  return (
    <div className="container mx-auto max-w-2xl py-4 sm:py-6">
      <div className="flex flex-col gap-4">
        <Stories />
        {renderFeed()}
      </div>
    </div>
  );
}
