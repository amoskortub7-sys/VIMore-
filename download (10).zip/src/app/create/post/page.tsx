

'use client';

import * as React from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Image from 'next/image';
import {
  ArrowLeft,
  Hash,
  AtSign,
  Link as LinkIcon,
  Globe,
  Users,
  Lock,
  MoreHorizontal,
  Folder,
  Sparkles,
  ChevronDown,
  MessageCircle,
  Save,
  X,
  Search,
  Pencil,
  Wallet,
  Unlock,
  Loader2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Post, LinkPreview as LinkPreviewType, User } from '@/lib/data';
import { useToast } from '@/hooks/use-toast';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetClose } from '@/components/ui/sheet';
import { Input } from '@/components/ui/input';
import { useIsMobile } from '@/hooks/use-mobile';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { LinkPreviewCard } from '@/components/link-preview-card';
import { getImage } from '@/lib/data';
import { ScrollArea } from '@/components/ui/scroll-area';
import { UserAvatar } from '@/components/user-avatar';
// import { manageBoost } from '@/ai/flows/manage-boost-flow';
import { Badge } from '@/components/ui/badge';
import { AppContext } from '@/components/app-shell';
import { createPost } from '@/services/postService';
import { uploadFile } from '@/services/storageService';
import { getUsers } from '@/services/userService';
import { canUserLockContent, CONTENT_LOCK_ELIGIBILITY_FOLLOWERS } from '@/lib/monetization-rules';
import { formatNumber } from '@/lib/utils';


const audienceOptions = [
  { value: 'public', label: 'Everyone', icon: Globe },
  { value: 'followers', label: 'Followers', icon: Users },
  { value: 'private', label: 'Only me', icon: Lock },
];

function dataURLtoFile(dataurl: string, filename: string): File {
    const arr = dataurl.split(',');
    if (arr.length < 2) {
        throw new Error('Invalid data URL');
    }
    const mimeMatch = arr[0].match(/:(.*?);/);
    if (!mimeMatch) {
        throw new Error('Invalid data URL: mime type not found');
    }
    const mime = mimeMatch[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
}


export default function CreatePostPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const appContext = React.useContext(AppContext);
  const currentUser = appContext?.currentUser;

  const mediaUrls = searchParams.getAll('mediaUrl');
  const mediaType = searchParams.get('mediaType');
  const mediaUrl = mediaUrls[0]; // For single media preview

  // --- State for new features ---
  const [content, setContent] = React.useState('');
  const [audience, setAudience] = React.useState(audienceOptions[0]);
  const [link, setLink] = React.useState('');
  const [linkPreview, setLinkPreview] = React.useState<LinkPreviewType | null>(null);
  const [allowComments, setAllowComments] = React.useState(true);
  const [saveToDevice, setSaveToDevice] = React.useState(false);
  const [unlockPrice, setUnlockPrice] = React.useState<number | null>(null);
  const [isPosting, setIsPosting] = React.useState(false);
  
  if (!currentUser) return null; // Should be handled by AppShell
  const isEligibleForLock = canUserLockContent(currentUser);


  React.useEffect(() => {
    // Redirect if no media is provided, as this is the final step
    if (mediaUrls.length === 0) {
      router.replace('/create/video'); // Default to video creation if no media
    }
  }, [mediaUrls, router]);

  const handlePost = async () => {
    if (!currentUser || mediaUrls.length === 0) return;
    setIsPosting(true);

    try {
        let uploadedMediaUrls: string[] = [];

        if (mediaType === 'image') {
            const uploadPromises = mediaUrls.map((dataUrl, index) => {
                const file = dataURLtoFile(dataUrl, `post-image-${Date.now()}-${index}.jpg`);
                return uploadFile(file);
            });
            uploadedMediaUrls = await Promise.all(uploadPromises);
        } else if (mediaType === 'video') {
            // Assuming video is also passed as a data URI for consistency
            const file = dataURLtoFile(mediaUrl, `post-video-${Date.now()}.webm`);
            const uploadedUrl = await uploadFile(file);
            uploadedMediaUrls = [uploadedUrl];
        }

        const newPost: Omit<Post, 'id' | 'createdAt' | 'shares' | 'comments' | 'reactions' | 'likedBy'> = {
            author: currentUser,
            content: content,
            video: mediaType === 'video' ? uploadedMediaUrls[0] : undefined,
            images: mediaType === 'image' ? uploadedMediaUrls.map((url, i) => ({ id: `img-${Date.now()}-${i}`, imageUrl: url, description: 'new post', imageHint: 'new post' })) : undefined,
            linkPreview: linkPreview,
            unlockPrice: unlockPrice ?? undefined,
        };
        
        const newPostId = await createPost(newPost);
        
        const authorIsSuperAdmin = !!currentUser.isSuperAdmin;
        const authorIsAdmin = !!currentUser.adminRole;

        if (authorIsSuperAdmin || authorIsAdmin) {
            console.log("Admin post created, skipping AI boost call as it is disabled.");
        }
        
        toast({
            title: "Post Published!",
            description: `Your post is now live for: ${audience.label}.`,
        });

        router.push('/');
    } catch (error) {
        console.error("Failed to create post:", error);
        toast({
            variant: "destructive",
            title: "Failed to publish post",
            description: "There was an error uploading your media or saving your post. Please try again."
        });
    } finally {
        setIsPosting(false);
    }
  }

  const handleSaveDraft = () => {
    if (!content && !linkPreview) {
        toast({
            variant: "destructive",
            title: "Nothing to save",
            description: "Write a description or add a link to save a draft."
        });
        return;
    }
    
    toast({
        title: "Draft Saved!",
        description: `Your post has been saved as a draft.`,
    });

    // In a real app, you might route to a drafts page or just clear the form
    setContent('');
    setLinkPreview(null);
    setAudience(audienceOptions[0]);
    router.push('/');
  }
  
  const appendToContent = (text: string) => {
    setContent(prev => prev ? `${prev} ${text}` : text);
  }

  if (mediaUrls.length === 0 || !currentUser) {
    // Render a loading state or null while redirecting
    return null;
  }

  const MoreOptionsContent = (
     <div className="p-4 space-y-4">
        <div className="flex items-center justify-between">
          <Label htmlFor="allow-comments" className="flex flex-col gap-1">
            <span className="font-semibold">Allow Comments</span>
            <span className="text-xs text-muted-foreground">Let others comment on your post.</span>
          </Label>
          <Switch id="allow-comments" checked={allowComments} onCheckedChange={setAllowComments} />
        </div>
        <Separator />
         <div className="flex items-center justify-between">
          <Label htmlFor="save-to-device" className="flex flex-col gap-1">
            <span className="font-semibold">Save to Device</span>
            <span className="text-xs text-muted-foreground">Automatically save the final post to your device.</span>
          </Label>
          <Switch id="save-to-device" checked={saveToDevice} onCheckedChange={setSaveToDevice} />
        </div>
      </div>
  );
  
  const MediaPreview = () => {
      if (mediaUrls.length > 1) {
          return (
            <div className="grid grid-cols-2 gap-1 w-24 shrink-0">
                {mediaUrls.slice(0, 4).map((url, i) => (
                    <div key={i} className="relative aspect-square">
                        <Image src={url} alt={`Preview ${i+1}`} fill className="object-cover rounded-md"/>
                        {i === 3 && mediaUrls.length > 4 && (
                            <div className="absolute inset-0 bg-black/50 flex items-center justify-center text-white font-bold text-xs">
                                +{mediaUrls.length - 4}
                            </div>
                        )}
                    </div>
                ))}
            </div>
          )
      }
      
      return (
        <div className="relative h-32 w-24 shrink-0 overflow-hidden rounded-lg">
              {mediaType === 'video' ? (
                  <video src={mediaUrl} className="h-full w-full object-cover" muted loop autoPlay />
              ) : (
                  <Image src={mediaUrl} alt="Post preview" fill className="object-cover" />
              )}
              <div className="absolute inset-0 bg-black/30 flex flex-col items-center justify-between p-1">
                  <p className="text-xs font-semibold text-white">Preview</p>
                  <Button variant="secondary" size="sm" className="h-6 text-xs bg-black/50 text-white border-none" onClick={() => toast({ title: "Edit Cover", description: "This would open an interface to edit the cover image."})}>Edit cover</Button>
              </div>
          </div>
      )
  }

  return (
    <div className="flex h-screen flex-col bg-background">
      <header className="flex h-16 shrink-0 items-center gap-4 border-b p-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft />
        </Button>
        <h1 className="text-xl font-bold">New Post</h1>
      </header>
      <main className="flex-1 overflow-y-auto p-4">
        <div className="flex gap-4">
          <div className="w-2/3">
            <Textarea
              placeholder="Add description..."
              className="min-h-[120px] border-0 px-0 shadow-none focus-visible:ring-0"
              value={content}
              onChange={(e) => setContent(e.target.value)}
            />
             <div className="mt-4 flex gap-2">
                <MentionPeopleDialog onMention={appendToContent}>
                    <Button variant="secondary" size="sm"><AtSign className="h-4 w-4 mr-1"/> Mention</Button>
                </MentionPeopleDialog>
            </div>
          </div>
          <MediaPreview />
        </div>
        
        {linkPreview && (
            <div className="mt-4">
                <LinkPreviewCard preview={linkPreview} onRemove={() => setLinkPreview(null)} />
            </div>
        )}

        <div className="mt-6 space-y-2">
            <AddLinkDialog setLinkPreview={setLinkPreview}>
                <button className="w-full">
                  <SettingsRow icon={LinkIcon} title="Add link" />
                </button>
            </AddLinkDialog>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="w-full">
                    <SettingsRow icon={audience.icon} title={`${audience.label} can view this post`} hasChevron />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                {audienceOptions.map(option => (
                  <DropdownMenuItem key={option.value} onClick={() => setAudience(option)}>
                    <option.icon className="mr-2 h-4 w-4" />
                    <span>{option.label}</span>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <div className="w-full">
                {isEligibleForLock ? (
                    <LockPostButton onSetPrice={setUnlockPrice} isLocked={!!unlockPrice}>
                        <SettingsRow 
                            icon={unlockPrice ? Unlock : Lock} 
                            title="Lock Post"
                            subtitle={unlockPrice ? `Unlock for ${unlockPrice} 🪙` : 'Set an unlock price'}
                            hasChevron 
                        />
                    </LockPostButton>
                ) : (
                    <div className="flex w-full items-center gap-3 py-3 text-left opacity-50 cursor-not-allowed">
                        <Lock className="h-5 w-5 text-muted-foreground" />
                        <div className="flex-1">
                            <p className="font-medium">Lock Post</p>
                            <p className="text-xs text-muted-foreground">Requires {formatNumber(CONTENT_LOCK_ELIGIBILITY_FOLLOWERS)}+ followers to use</p>
                        </div>
                    </div>
                )}
            </div>

            {isMobile ? (
                <Sheet>
                    <SheetTrigger asChild>
                         <button className="w-full">
                           <SettingsRow icon={MoreHorizontal} title="More options" subtitle="Manage comments & saving" hasChevron />
                         </button>
                    </SheetTrigger>
                    <SheetContent side="bottom" className="rounded-t-2xl">
                        <SheetHeader><SheetTitle>More Options</SheetTitle></SheetHeader>
                        {MoreOptionsContent}
                    </SheetContent>
                </Sheet>
            ) : (
                 <Dialog>
                    <DialogTrigger asChild>
                        <button className="w-full">
                           <SettingsRow icon={MoreHorizontal} title="More options" subtitle="Manage comments & saving" hasChevron />
                        </button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader><DialogTitle>More Options</DialogTitle></DialogHeader>
                        {MoreOptionsContent}
                    </DialogContent>
                </Dialog>
            )}

        </div>

        <div className="mt-6">
            <p className="font-semibold text-sm mb-2">Share to</p>
             <div className="flex gap-4">
                <button onClick={() => toast({title: "Sharing to Other Platforms", description: "This would toggle sharing to another platform."})}><div className="h-10 w-10 rounded-full bg-muted"></div></button>
                <button onClick={() => toast({title: "Sharing to Other Platforms", description: "This would toggle sharing to another platform."})}><div className="h-10 w-10 rounded-full bg-muted"></div></button>
                <button onClick={() => toast({title: "Sharing to Other Platforms", description: "This would toggle sharing to another platform."})}><div className="h-10 w-10 rounded-full bg-muted"></div></button>
                <button onClick={() => toast({title: "Sharing to Other Platforms", description: "This would toggle sharing to another platform."})}><div className="h-10 w-10 rounded-full bg-muted"></div></button>
            </div>
        </div>
      </main>
      <footer className="mt-auto shrink-0 border-t p-4">
         <div className="mb-4 flex items-center space-x-2">
            <Checkbox id="music-confirm" />
            <Label htmlFor="music-confirm" className="text-xs text-muted-foreground">
                I accept the <span className="text-primary">Music Usage Confirmation</span>
            </Label>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <Button variant="secondary" size="lg" onClick={handleSaveDraft}>
            <Folder className="mr-2 h-5 w-5" />
            Drafts
          </Button>
          <Button size="lg" onClick={handlePost} disabled={isPosting} className="bg-red-500 hover:bg-red-600">
            {isPosting ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Sparkles className="mr-2 h-5 w-5" />}
            Post
          </Button>
        </div>
      </footer>
    </div>
  );
}

function SettingsRow({ icon: Icon, title, subtitle, hasChevron = false }: { icon: React.ElementType, title: string, subtitle?: string, hasChevron?: boolean }) {
    return (
        <div className="flex w-full items-center gap-3 py-3 text-left">
            <Icon className="h-5 w-5 text-muted-foreground" />
            <div className="flex-1">
                <p className="font-medium">{title}</p>
                {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
            </div>
             {hasChevron && <ChevronDown className="h-5 w-5 text-muted-foreground -rotate-90" />}
        </div>
    )
}

function AddLinkDialog({ children, setLinkPreview }: { children: React.ReactNode, setLinkPreview: (preview: LinkPreviewType | null) => void }) {
    const [url, setUrl] = React.useState('');
    const [isOpen, setIsOpen] = React.useState(false);

    const handleAddLink = () => {
        if (url) {
            // In a real app, you'd fetch metadata from this URL.
            // For now, we'll simulate it.
            const simulatedPreview: LinkPreviewType = {
                url: url,
                title: 'Simulated Link Title',
                description: 'This is a simulated description from the URL you provided. In a real app, this would be fetched from the website\'s metadata.',
                image: getImage('link-nextjs'),
            };
            setLinkPreview(simulatedPreview);
        }
        setIsOpen(false);
    }
    
    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent>
                <DialogHeader><DialogTitle>Add a link</DialogTitle></DialogHeader>
                <div className="py-4">
                    <Input 
                        placeholder="https://example.com"
                        value={url}
                        onChange={(e) => setUrl(e.target.value)}
                    />
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => setIsOpen(false)}>Cancel</Button>
                    <Button onClick={handleAddLink} disabled={!url}>Add Link</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    )
}

function MentionPeopleDialog({ children, onMention }: { children: React.ReactNode; onMention: (text: string) => void; }) {
  const [searchQuery, setSearchQuery] = React.useState('');
  const [allUsers, setAllUsers] = React.useState<User[]>([]);

  React.useEffect(() => {
    getUsers().then(setAllUsers);
  }, []);
  
  const filteredUsers = allUsers.filter(u => 
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    u.username.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  return (
    <Dialog>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Mention People</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col gap-4">
            <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search people..." className="pl-9" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
            </div>
            <ScrollArea className="h-80">
                <div className="flex flex-col gap-2 p-1">
                    {filteredUsers.map(user => (
                        <DialogClose key={user.id} asChild>
                            <button className="flex items-center gap-3 p-2 rounded-md hover:bg-accent text-left w-full" onClick={() => onMention(`@${user.username}`)}>
                                <UserAvatar user={user} />
                                <div>
                                    <p className="font-semibold">{user.name}</p>
                                    <p className="text-sm text-muted-foreground">@{user.username}</p>
                                </div>
                            </button>
                        </DialogClose>
                    ))}
                </div>
            </ScrollArea>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function LockPostButton({ onSetPrice, children, isLocked }: { onSetPrice: (price: number | null) => void; children: React.ReactNode; isLocked: boolean }) {
    const [price, setPrice] = React.useState('');
    
    const handleSave = () => {
        const priceNum = parseInt(price, 10);
        if (!isNaN(priceNum) && priceNum > 0) {
            onSetPrice(Math.min(priceNum, 200)); // Cap at 200
        }
    };

    return (
        <Dialog>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent className="max-w-sm">
                <DialogHeader>
                    <DialogTitle>Lock Post</DialogTitle>
                    <p className="text-sm text-muted-foreground pt-2">Set an unlock price in Gold 🪙. Viewers will have to pay this amount to see your post. Max 200 🪙.</p>
                </DialogHeader>
                <div className="flex items-center gap-2">
                    <Input
                        type="number"
                        placeholder="Unlock price (1-200)"
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                        min="1"
                        max="200"
                    />
                    <span className="text-xl">🪙</span>
                </div>
                <DialogFooter className="gap-2 sm:gap-0">
                     {isLocked && (
                        <DialogClose asChild>
                            <Button variant="outline" onClick={() => onSetPrice(null)}>
                                <Unlock className="mr-2 h-4 w-4"/> Remove Lock
                            </Button>
                        </DialogClose>
                     )}
                    <DialogClose asChild>
                        <Button onClick={handleSave} disabled={!price}>Set Price</Button>
                    </DialogClose>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}



    
