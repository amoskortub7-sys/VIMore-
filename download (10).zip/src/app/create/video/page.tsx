
'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { 
    X, 
    Music, 
    RotateCcw,
    Zap,
    ZapOff,
    Loader2,
    Check,
    Search,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn, parseDurationToSeconds } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogClose } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { Song } from '@/lib/data';
import { allMockSongs } from '@/lib/data';
import { Input } from '@/components/ui/input';
import { AppContext } from '@/components/app-shell';


export default function CreateVideoPage() {
  const router = useRouter();
  const { toast } = useToast();
  const videoRef = React.useRef<HTMLVideoElement>(null);
  const audioRef = React.useRef<HTMLAudioElement>(null);
  const mediaRecorderRef = React.useRef<MediaRecorder | null>(null);
  const videoInputRef = React.useRef<HTMLInputElement>(null);
  const streamRef = React.useRef<MediaStream | null>(null);

  const [hasCameraPermission, setHasCameraPermission] = React.useState(true);
  const [recordingStatus, setRecordingStatus] = React.useState<'idle' | 'recording' | 'recorded'>('idle');
  const [duration, setDuration] = React.useState(15);
  const [elapsedTime, setElapsedTime] = React.useState(0);
  const [facingMode, setFacingMode] = React.useState<'user' | 'environment'>('user');
  const [isFlashOn, setIsFlashOn] = React.useState(false);
  const [recordedBlob, setRecordedBlob] = React.useState<Blob | null>(null);
  const [selectedSong, setSelectedSong] = React.useState<Song | null>(null);
  
  const appContext = React.useContext(AppContext);
  if (!appContext) return null;
  const { isFreeMode } = appContext;
  
  React.useEffect(() => {
    if (isFreeMode) {
      toast({
        variant: 'destructive',
        title: 'Video Disabled',
        description: 'Video uploads are disabled in Free Mode to save data.',
      });
      router.push('/');
    }
  }, [isFreeMode, router, toast]);


  // Cleanup stream on component unmount
  React.useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  // Get and set up camera stream
  React.useEffect(() => {
    if (isFreeMode) return;
    
    const getCameraStream = async () => {
      // Stop previous stream
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
      setIsFlashOn(false); // Reset flash state on camera switch

      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
            video: { facingMode: facingMode }, 
            audio: true 
        });
        streamRef.current = stream;
        setHasCameraPermission(true);

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.src = '';
          setRecordedBlob(null);
        }

        mediaRecorderRef.current = new MediaRecorder(stream, { mimeType: 'video/webm' });
        
        mediaRecorderRef.current.ondataavailable = (event) => {
          if (event.data.size > 0) {
            const blob = new Blob([event.data], { type: 'video/webm' });
            setRecordedBlob(blob);
            if (videoRef.current) {
              videoRef.current.srcObject = null;
              videoRef.current.src = URL.createObjectURL(blob);
            }
          }
        };

      } catch (error) {
        console.error('Error accessing camera:', error);
        setHasCameraPermission(false);
        toast({
          variant: 'destructive',
          title: 'Camera Access Denied',
          description: 'Please enable camera permissions in your browser settings to use this app.',
        });
      }
    };

    getCameraStream();
    
  }, [facingMode, toast, isFreeMode]);
  
   React.useEffect(() => {
    let timer: NodeJS.Timeout | undefined;
    if (recordingStatus === 'recording') {
      const startTime = Date.now();
      timer = setInterval(() => {
        const currentElapsedTime = Date.now() - startTime;
        setElapsedTime(currentElapsedTime);

        if (currentElapsedTime >= duration * 1000) {
          handleStopRecording();
        }
      }, 100);
    }
    return () => clearInterval(timer);
  }, [recordingStatus, duration]);

  // Effect to handle selected song
  React.useEffect(() => {
    if (selectedSong && audioRef.current) {
      audioRef.current.src = selectedSong.src;
      audioRef.current.load();
      setDuration(parseDurationToSeconds(selectedSong.duration));
    } else {
        setDuration(15);
    }
  }, [selectedSong]);

  const handleStartRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'inactive') {
      setRecordedBlob(null);
      setElapsedTime(0);
      mediaRecorderRef.current.start();
      setRecordingStatus('recording');
      if (audioRef.current && selectedSong) {
        audioRef.current.currentTime = 0;
        audioRef.current.play();
      }
    }
  };

  const handleStopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
        mediaRecorderRef.current.stop();
        setRecordingStatus('recorded');
        if (audioRef.current && selectedSong) {
          audioRef.current.pause();
          audioRef.current.currentTime = 0;
        }
    }
  };
  
  const handleRetake = () => {
    setRecordingStatus('idle');
    setElapsedTime(0);
    setRecordedBlob(null);
    if (audioRef.current && selectedSong) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    // Re-attach camera stream
    if(videoRef.current && streamRef.current) {
        videoRef.current.srcObject = streamRef.current;
        videoRef.current.src = '';
        videoRef.current.play();
    }
  }
  
  const handleNext = () => {
    if (!recordedBlob) {
        toast({
            variant: "destructive",
            title: "No video recorded",
            description: "Please record a video before proceeding."
        });
        return;
    }
    
    const objectUrl = URL.createObjectURL(recordedBlob);
    router.push(`/create/preview?videoUrl=${encodeURIComponent(objectUrl)}`);
  }

  const handleUploadClick = () => {
    videoInputRef.current?.click();
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const video = document.createElement('video');
      video.preload = 'metadata';
      video.onloadedmetadata = () => {
        window.URL.revokeObjectURL(video.src);
        if (video.duration > 600) {
            toast({
                variant: 'destructive',
                title: 'Video Too Long',
                description: 'Please upload videos that are 10 minutes or less.'
            });
            // Clear the input value so the same file can be selected again
            if (videoInputRef.current) {
                videoInputRef.current.value = '';
            }
        } else {
            setRecordedBlob(file);
            setRecordingStatus('recorded');
            if (videoRef.current) {
                videoRef.current.srcObject = null;
                videoRef.current.src = URL.createObjectURL(file);
            }
        }
      }
      video.src = URL.createObjectURL(file);
    }
  };

  const formatTime = (ms: number) => {
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60).toString().padStart(2, '0');
    const seconds = (totalSeconds % 60).toString().padStart(2, '0');
    return `${minutes}:${seconds}`;
  }
  
  const handleFlipCamera = () => {
    setFacingMode(prev => prev === 'user' ? 'environment' : 'user');
  }

  const handleToggleFlash = async () => {
    if (streamRef.current) {
        const videoTrack = streamRef.current.getVideoTracks()[0];
        if (videoTrack) {
            const capabilities = videoTrack.getCapabilities();
            // @ts-ignore
            if (capabilities.torch) {
                try {
                    // @ts-ignore
                    await videoTrack.applyConstraints({ advanced: [{ torch: !isFlashOn }] });
                    setIsFlashOn(!isFlashOn);
                } catch (e) {
                    console.error('Failed to toggle flash:', e);
                    toast({
                        variant: 'destructive',
                        title: 'Flash Error',
                        description: 'Could not toggle the flash.'
                    });
                }
            } else {
                 toast({
                    variant: 'destructive',
                    title: 'Flash Unavailable',
                    description: 'Flash is not available on this device or camera.'
                });
            }
        }
    }
  };

  if (isFreeMode) {
    return (
      <div className="h-screen w-screen bg-black text-white flex flex-col items-center justify-center p-4">
        <Alert variant="destructive" className="max-w-sm">
            <AlertTitle>Free Mode Active</AlertTitle>
            <AlertDescription>
                Video features are disabled in Free Mode to save data.
            </AlertDescription>
        </Alert>
         <Button className="mt-4" onClick={() => router.back()}>Go Back</Button>
      </div>
    );
  }

  if (recordingStatus === 'recorded') {
    return <VideoEditor blob={recordedBlob!} onRetake={handleRetake} onNext={handleNext} />;
  }

  return (
    <div className="h-screen w-screen bg-black text-white flex flex-col">
      {/* Hidden file input for upload */}
      <input 
        type="file" 
        ref={videoInputRef}
        className="hidden"
        accept="video/*"
        onChange={handleFileSelect}
      />
      {/* Hidden audio element for playback */}
      <audio ref={audioRef} />

      {/* Header */}
      <header className="absolute top-0 left-0 right-0 z-10 flex items-center justify-between p-4">
        <Button variant="ghost" size="icon" className="rounded-full" onClick={() => router.back()}>
          <X />
        </Button>
        <AddSoundButton onSelectSong={setSelectedSong} selectedSong={selectedSong} />
        <div /> 
      </header>

      {/* Camera View */}
      <div className="relative flex-1 flex items-center justify-center overflow-hidden">
        <video 
            ref={videoRef} 
            className="w-full h-full object-cover"
            autoPlay 
            playsInline 
            muted
        />

         { !hasCameraPermission && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/80 p-4">
                <Alert variant="destructive" className="max-w-sm">
                    <AlertTitle>Camera Access Required</AlertTitle>
                    <AlertDescription>
                        Please allow camera access in your browser settings to record video.
                    </AlertDescription>
                </Alert>
            </div>
         )}
         {/* Recording Timer */}
        {recordingStatus === 'recording' && (
            <div className="absolute top-16 left-1/2 -translate-x-1/2 text-white font-mono text-lg bg-black/50 px-2 py-1 rounded-md">
                {formatTime(elapsedTime)}
            </div>
        )}
      </div>

      {/* Right Sidebar Controls */}
       <aside className="absolute top-1/2 -translate-y-1/2 right-4 z-10 flex flex-col gap-6">
            <IconButton icon={RotateCcw} label="Flip" onClick={handleFlipCamera} disabled={recordingStatus !== 'idle'} />
            <IconButton icon={isFlashOn ? Zap : ZapOff} label="Flash" onClick={handleToggleFlash} />
       </aside>

      {/* Footer */}
      <footer className="w-full p-4 z-10 flex flex-col items-center gap-4">
          <>
            {selectedSong ? (
                 <div className="text-center text-sm font-medium text-white bg-black/30 px-3 py-1 rounded-full">
                    Max duration: {duration}s
                 </div>
            ) : (
                <div className="flex items-center gap-4 text-sm font-medium">
                  {[15, 60, 180, 600].map(d => (
                    <button key={d} onClick={() => setDuration(d)} className={cn(duration === d ? 'text-white' : 'text-gray-400', 'disabled:opacity-50')} disabled={recordingStatus !== 'idle'}>
                      {d === 600 ? '10m' : `${d}s`}
                    </button>
                  ))}
                </div>
            )}
          </>

        <div className="w-full flex items-center justify-center gap-4">
            <div className="w-24 flex justify-center">
              {/* This space is for the retake button after recording */}
            </div>

            <button onClick={recordingStatus === 'recording' ? handleStopRecording : handleStartRecording} disabled={!hasCameraPermission} className="relative h-20 w-20 rounded-full border-4 border-white flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed">
                {recordingStatus === 'idle' && <div className="h-full w-full rounded-full bg-primary" />}
                {recordingStatus === 'recording' && <div className="h-8 w-8 bg-primary rounded-sm" />}
            </button>


             <div className="w-24 flex justify-center">
              {recordingStatus === 'idle' && (
                <Button variant="outline" onClick={handleUploadClick} className="bg-white/90 text-black">Upload</Button>
              )}
               {/* This space is for the next button after recording */}
            </div>
        </div>
      </footer>
    </div>
  );
}


function VideoEditor({ blob, onRetake, onNext }: { blob: Blob; onRetake: () => void; onNext: () => void }) {
  const videoRef = React.useRef<HTMLVideoElement>(null);
  const timelineRef = React.useRef<HTMLDivElement>(null);
  const [duration, setDuration] = React.useState(0);
  const [startTime, setStartTime] = React.useState(0);
  const [endTime, setEndTime] = React.useState(0);
  const [isTrimming, setIsTrimming] = React.useState(false);
  const [trimmingHandle, setTrimmingHandle] = React.useState<'start' | 'end' | null>(null);

  React.useEffect(() => {
    const video = videoRef.current;
    if (!video || !blob) return;

    // Ensure blob is a Blob object before creating a URL
    if (!(blob instanceof Blob)) {
        console.error("Invalid blob type provided to VideoEditor");
        return;
    }
    
    const url = URL.createObjectURL(blob);
    video.src = url;

    const handleLoadedMetadata = () => {
      setDuration(video.duration);
      setEndTime(video.duration);
    };

    video.addEventListener('loadedmetadata', handleLoadedMetadata);

    return () => {
      URL.revokeObjectURL(url);
      video.removeEventListener('loadedmetadata', handleLoadedMetadata);
    };
  }, [blob]);

  // Keep video playing in loop between start/end times
  React.useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const interval = setInterval(() => {
      if (video.currentTime >= endTime) {
        video.currentTime = startTime;
      }
    }, 100);

    return () => clearInterval(interval);

  }, [startTime, endTime]);


  const handleTrimChange = (e: React.MouseEvent | React.TouchEvent) => {
    if (!trimmingHandle || !timelineRef.current) return;

    const timeline = timelineRef.current;
    const rect = timeline.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const position = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
    
    const newTime = position * duration;

    if (trimmingHandle === 'start') {
      if (newTime < endTime) {
        setStartTime(newTime);
        if (videoRef.current) videoRef.current.currentTime = newTime;
      }
    } else {
      if (newTime > startTime) {
        setEndTime(newTime);
      }
    }
  };
  
  const handlePointerDown = (handle: 'start' | 'end') => {
    setTrimmingHandle(handle);
    setIsTrimming(true);
  };
  
  const handlePointerUp = () => {
    setTrimmingHandle(null);
    setIsTrimming(false);
  };
  
  React.useEffect(() => {
    if (isTrimming) {
        window.addEventListener('mousemove', handleTrimChange);
        window.addEventListener('touchmove', handleTrimChange);
        window.addEventListener('mouseup', handlePointerUp);
        window.addEventListener('touchend', handlePointerUp);
    }
    
    return () => {
        window.removeEventListener('mousemove', handleTrimChange);
        window.removeEventListener('touchmove', handleTrimChange);
        window.removeEventListener('mouseup', handlePointerUp);
        window.removeEventListener('touchend', handlePointerUp);
    }
  }, [isTrimming, handleTrimChange]);


  const handleNext = () => {
    // In a real app, we'd use FFmpeg.wasm or a server to actually trim the video.
    // For this simulation, we'll just pass the original blob.
    console.log(`Proceeding with video trimmed from ${startTime.toFixed(2)}s to ${endTime.toFixed(2)}s`);
    onNext();
  }

  return (
    <div className="h-screen w-screen bg-black text-white flex flex-col">
      <header className="absolute top-0 left-0 right-0 z-10 flex items-center justify-between p-4">
        <Button variant="ghost" size="icon" className="rounded-full" onClick={onRetake}>
          <X />
        </Button>
        <p className="font-semibold">Trim Video</p>
        <Button variant="ghost" size="icon" className="rounded-full bg-primary/80" onClick={handleNext}>
          <Check />
        </Button>
      </header>

      <div className="relative flex-1 flex items-center justify-center overflow-hidden my-24">
        <video ref={videoRef} className="w-full h-full object-contain" autoPlay loop muted playsInline />
      </div>

      <footer className="absolute bottom-0 left-0 right-0 z-10 p-6 flex flex-col items-center gap-4">
          <div ref={timelineRef} className="w-full h-10 bg-gray-700 rounded-lg flex items-center relative cursor-ew-resize">
              {/* Timeline background */}
              <div 
                className="absolute h-full bg-primary/50"
                style={{
                    left: `${(startTime / duration) * 100}%`,
                    width: `${((endTime - startTime) / duration) * 100}%`
                }}
              />
              {/* Start Handle */}
              <div 
                className="absolute top-1/2 -translate-y-1/2 w-4 h-14 bg-white rounded-md cursor-ew-resize"
                style={{ left: `${(startTime / duration) * 100}%`, transform: 'translateX(-50%) translateY(-50%)' }}
                onMouseDown={() => handlePointerDown('start')}
                onTouchStart={() => handlePointerDown('start')}
              />
              {/* End Handle */}
              <div 
                className="absolute top-1/2 -translate-y-1/2 w-4 h-14 bg-white rounded-md cursor-ew-resize"
                style={{ left: `${(endTime / duration) * 100}%`, transform: 'translateX(-50%) translateY(-50%)' }}
                onMouseDown={() => handlePointerDown('end')}
                onTouchStart={() => handlePointerDown('end')}
              />
          </div>
          <p className="text-sm text-muted-foreground">
            Trimmed duration: { (endTime - startTime).toFixed(1) }s
          </p>
      </footer>
    </div>
  );
}


function IconButton({ icon: Icon, label, ...props }: { icon: React.ElementType, label: string } & React.ComponentProps<'button'>) {
  return (
    <button className="flex flex-col items-center gap-1 text-xs text-white/90 disabled:opacity-50" {...props}>
      <Icon className="h-7 w-7 drop-shadow-md" />
      <span>{label}</span>
    </button>
  )
}

function AddSoundButton({ selectedSong, onSelectSong }: { selectedSong: Song | null; onSelectSong: (song: Song) => void; }) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" className="rounded-full max-w-[200px] truncate">
          <Music className="mr-2 h-4 w-4" /> 
          {selectedSong ? selectedSong.title : 'Add sound'}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md bg-black/80 border-gray-700 text-white">
        <DialogHeader>
          <DialogTitle>Add Sound</DialogTitle>
        </DialogHeader>
        <SoundBrowser onSelectSong={onSelectSong} />
      </DialogContent>
    </Dialog>
  )
}

function SoundBrowser({ onSelectSong }: { onSelectSong: (song: Song) => void; }) {
    const [search, setSearch] = React.useState('');
    const usableSongs = allMockSongs.filter(s => s.isUsableAsSound);
    const filteredSongs = usableSongs.filter(s => 
        s.title.toLowerCase().includes(search.toLowerCase()) || 
        s.artist.name.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <div className="flex flex-col gap-4">
            <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search songs..." className="pl-9 bg-white/10" value={search} onChange={(e) => setSearch(e.target.value)} />
            </div>
            <ScrollArea className="h-96">
                <div className="flex flex-col gap-2 p-1">
                    {filteredSongs.map(song => (
                        <DialogClose key={song.id} asChild>
                            <button className="flex items-center gap-3 p-2 rounded-md hover:bg-white/20 text-left" onClick={() => onSelectSong(song)}>
                                <div className="p-2 bg-gray-700 rounded-md">
                                    <Music className="w-5 h-5" />
                                </div>
                                <div className="flex-1 overflow-hidden">
                                    <p className="font-semibold truncate">{song.title}</p>
                                    <p className="text-sm text-gray-400 truncate">{song.artist.name}</p>
                                </div>
                                <p className="text-sm text-gray-400">{song.duration}</p>
                            </button>
                        </DialogClose>
                    ))}
                </div>
                 {filteredSongs.length === 0 && (
                    <div className="text-center text-muted-foreground py-10">
                        <p>No songs found.</p>
                    </div>
                )}
            </ScrollArea>
        </div>
    )
}
