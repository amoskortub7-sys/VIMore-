
'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { 
    X,
    UploadCloud,
    Plus,
    Loader2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';

export default function CreatePhotoPage() {
  const router = useRouter();
  const { toast } = useToast();
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const [imageFiles, setImageFiles] = React.useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = React.useState<string[]>([]);
  const [isDragOver, setIsDragOver] = React.useState(false);


  const handleFileSelect = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    
    const newFiles = Array.from(files).filter(file => {
        if (!file.type.startsWith('image/')) {
            toast({ variant: 'destructive', title: 'Invalid file type', description: 'Please upload an image file.' });
            return false;
        }
        return true;
    });

    if (imageFiles.length + newFiles.length > 10) {
        toast({ variant: 'destructive', title: 'Maximum 10 images allowed.' });
        return;
    }

    setImageFiles(prev => [...prev, ...newFiles]);

    newFiles.forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
            setImagePreviews(prev => [...prev, reader.result as string]);
        };
        reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
      setImageFiles(prev => prev.filter((_, i) => i !== index));
      setImagePreviews(prev => prev.filter((_, i) => i !== index));
  }
  
  const handleNext = () => {
    if (imageFiles.length === 0) {
        toast({
            variant: "destructive",
            title: "No image selected",
            description: "Please upload an image before proceeding."
        });
        return;
    }
    
    // The `imagePreviews` state already holds the base64 data URIs.
    const urls = imagePreviews;
    
    const params = new URLSearchParams();
    urls.forEach(url => params.append('mediaUrl', url));
    params.set('mediaType', 'image');

    router.push(`/create/post?${params.toString()}`);
  }

  const handleDragEvents = (e: React.DragEvent<HTMLDivElement>, isOver: boolean) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(isOver);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    handleDragEvents(e, false);
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      handleFileSelect(files);
    }
  };

  return (
    <div className="h-screen w-screen bg-black text-white flex flex-col">
      <input 
        type="file" 
        ref={fileInputRef} 
        className="hidden" 
        accept="image/*"
        multiple
        onChange={(e) => handleFileSelect(e.target.files)}
      />

      <header className="absolute top-0 left-0 right-0 z-10 flex items-center justify-between p-4">
        <Button variant="ghost" size="icon" className="rounded-full" onClick={() => router.back()}>
          <X />
        </Button>
        <h1 className="font-semibold">Upload Photos</h1>
        <Button disabled={imageFiles.length === 0} onClick={handleNext}>
            Next
        </Button>
      </header>
      
      <main className="flex-1 flex items-center justify-center p-4">
        {imagePreviews.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 w-full max-w-2xl h-full max-h-[80vh] overflow-y-auto p-4">
                {imagePreviews.map((preview, index) => (
                    <div key={index} className="relative aspect-square">
                        <Image 
                            src={preview}
                            alt={`Image preview ${index + 1}`}
                            fill
                            className="object-cover rounded-lg"
                        />
                         <Button
                            variant="destructive"
                            size="icon"
                            className="absolute top-1 right-1 h-6 w-6 rounded-full"
                            onClick={() => removeImage(index)}
                            >
                            <X className="h-4 w-4" />
                        </Button>
                    </div>
                ))}
                {imageFiles.length < 10 && (
                     <button
                        onClick={() => fileInputRef.current?.click()}
                        className="aspect-square flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-gray-600 hover:border-primary transition-colors"
                    >
                        <Plus className="h-8 w-8 text-gray-500" />
                        <p className="mt-2 text-sm">Add Photo</p>
                    </button>
                )}
            </div>
        ) : (
             <div 
                className={cn(
                    "w-full h-2/3 max-w-2xl flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-gray-600 transition-colors",
                    isDragOver ? "border-primary bg-gray-900" : ""
                )}
                onClick={() => fileInputRef.current?.click()}
                onDragOver={(e) => handleDragEvents(e, true)}
                onDragLeave={(e) => handleDragEvents(e, false)}
                onDrop={handleDrop}
            >
                <UploadCloud className="h-16 w-16 text-gray-500" />
                <p className="mt-4 text-lg font-semibold">Drag & drop your photos here</p>
                <p className="text-gray-400">or</p>
                <Button className="mt-4" variant="outline">Select Files</Button>
            </div>
        )}
      </main>
    </div>
  );
}
