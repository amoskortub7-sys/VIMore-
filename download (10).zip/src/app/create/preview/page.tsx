'use client';

import * as React from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Image from 'next/image';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function CreatePreviewPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const videoSrc = searchParams.get('videoUrl');
  const imageSrc = searchParams.get('imageUrl');
  const mediaType = videoSrc ? 'video' : 'image';
  const mediaUrl = videoSrc || imageSrc;

  React.useEffect(() => {
    if (!videoSrc && !imageSrc) {
      router.replace('/create/video');
      return;
    }
  }, [videoSrc, imageSrc, router]);

  // Cleanup object URL on unmount
  React.useEffect(() => {
    return () => {
      if (videoSrc) {
        URL.revokeObjectURL(videoSrc);
      }
    };
  }, [videoSrc]);
  
  const handleNext = () => {
    if (!mediaUrl) return;
    const params = new URLSearchParams();
    params.set('mediaUrl', mediaUrl);
    params.set('mediaType', mediaType);
    router.push(`/create/post?${params.toString()}`);
  }

  const handleBack = () => {
    router.back();
  }

  if (!mediaUrl) {
    return (
      <div className="h-screen w-screen bg-black flex items-center justify-center text-white">
        <p>Loading preview...</p>
      </div>
    );
  }

  return (
    <div className="relative h-screen w-screen bg-black text-white flex flex-col">
      <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
        {videoSrc ? (
            <video src={videoSrc} className="w-full h-full object-cover" autoPlay loop playsInline />
        ) : imageSrc ? (
            <Image src={imageSrc} alt="Preview" layout="fill" objectFit="contain" />
        ) : null}
      </div>

      <header className="absolute top-0 left-0 right-0 z-10 flex items-center justify-between p-4">
        <Button variant="ghost" size="icon" className="rounded-full bg-black/30" onClick={handleBack}>
          <ArrowLeft />
        </Button>
      </header>

      <footer className="absolute bottom-0 left-0 right-0 z-10 p-4">
        <div className="flex items-center justify-end gap-4">
            <Button className="w-1/2 bg-primary" onClick={handleNext}>Next</Button>
        </div>
      </footer>
    </div>
  );
}
