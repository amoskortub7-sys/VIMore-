
'use client';

import * as React from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Loader2, CheckCircle, AlertTriangle, Eye, EyeOff } from 'lucide-react';
import { account } from '@/lib/appwrite';
import Link from 'next/link';

export default function ResetPasswordPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();

  const userId = searchParams.get('userId');
  const secret = searchParams.get('secret');

  const [newPassword, setNewPassword] = React.useState('');
  const [confirmPassword, setConfirmPassword] = React.useState('');
  const [showPassword, setShowPassword] = React.useState(false);
  const [isLoading, setIsLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const isLinkInvalid = !userId || !secret;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    if (newPassword.length < 8) {
      setError("Password must be at least 8 characters long.");
      return;
    }
    if (isLinkInvalid) return;

    setIsLoading(true);
    setError(null);
    try {
      await account.updateRecovery(userId, secret, newPassword, confirmPassword);
      toast({
        title: 'Password Reset Successful!',
        description: 'You can now log in with your new password.',
      });
      router.push('/login');
    } catch (error: any) {
      setError("Failed to reset password. The link may have expired or is invalid.");
    } finally {
      setIsLoading(false);
    }
  };

  const renderContent = () => {
    if (isLinkInvalid) {
        return (
          <div className="flex flex-col items-center justify-center text-center space-y-4">
            <AlertTriangle className="h-12 w-12 text-destructive" />
            <h1 className="text-2xl font-bold">Invalid Link</h1>
            <p className="text-muted-foreground">This password reset link is invalid. Please request a new one.</p>
            <Link href="/forgot-password">
              <Button>Request a New Link</Button>
            </Link>
          </div>
        );
    }

    return (
        <div className="w-full max-w-sm mx-auto space-y-6">
        <div className="text-center">
            <CheckCircle className="mx-auto h-12 w-12 text-green-500 mb-4" />
            <h1 className="text-3xl font-bold">Create New Password</h1>
            <p className="text-muted-foreground mt-2">Your new password must be at least 8 characters long.</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
            <Label htmlFor="newPassword">New Password</Label>
            <div className="relative">
                <Input
                id="newPassword"
                type={showPassword ? 'text' : 'password'}
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                disabled={isLoading}
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute inset-y-0 right-0 flex items-center pr-3 text-muted-foreground">
                {showPassword ? <EyeOff className="h-5 w-5"/> : <Eye className="h-5 w-5"/>}
                </button>
            </div>
            </div>
            <div className="space-y-2">
            <Label htmlFor="confirmPassword">Confirm New Password</Label>
            <Input
                id="confirmPassword"
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                disabled={isLoading}
            />
            </div>
            {error && (
            <div className="flex items-center gap-2 text-sm text-destructive">
                <AlertTriangle className="h-4 w-4" />
                <p>{error}</p>
            </div>
            )}
            <Button type="submit" className="w-full" disabled={isLoading || !newPassword || !confirmPassword}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Reset Password
            </Button>
        </form>
        </div>
    );
  };

  return (
    <div className="flex min-h-screen w-full flex-col items-center justify-center bg-background p-4">
      {renderContent()}
    </div>
  );
}
