

'use client';

import Image from 'next/image';
import { useParams, notFound, useRouter } from 'next/navigation';
import * as React from 'react';
import { MessageCircle, MoreHorizontal, Rss, UserPlus, Pin, Link as LinkIcon, AlertTriangle, ShieldX, Check, UserCheck, Camera, Pencil, LayoutDashboard, Diamond, Bookmark, Image as ImageIcon, Loader2, Unlock } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { UserAvatar } from '@/components/user-avatar';
import { mockStories, type User, Story, StoryHighlight, ImagePlaceholder, Post, type Conversation } from '@/lib/data';
import { Button } from '@/components/ui/button';
import { PostCard } from '@/components/post-card';
import { Separator } from '@/components/ui/separator';
import { formatNumber } from '@/lib/utils';
import { cn } from '@/lib/utils';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { ImageLightbox } from '@/components/image-lightbox';
import { ShareDialog } from '@/components/share-dialog';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogClose, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetClose } from '@/components/ui/sheet';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { UserListDialog } from '@/components/user-list-dialog';
import { useIsMobile } from '@/hooks/use-mobile';
import Link from 'next/link';
import { VerifiedBadge } from '@/components/verified-badge';
import { GetVerifiedDialog } from '@/components/get-verified-dialog';
import { AppContext } from '@/components/app-shell';
import { getUser, updateUser, getFollowers, getFollowing, toggleFollow } from '@/services/userService';
import { subscribeToCreator } from '@/services/monetizationService';
import ProfileLoading from './loading';
import { getPosts, updatePost } from '@/services/postService';
import { processTransaction } from '@/ai/flows/process-transaction';
import { canUserReceiveSubscriptions } from '@/lib/monetization-rules';


export default function ProfilePage() {
  const params = useParams();
  const router = useRouter();
  const { toast } = useToast();
  const username = params.username as string;
  
  const [isLightboxOpen, setIsLightboxOpen] = React.useState(false);
  const [lightboxImages, setLightboxImages] = React.useState<string[]>([]);
  const [lightboxStartIndex, setLightboxStartIndex] = React.useState(0);
  
  const [user, setUser] = React.useState<User | null>(null);
  const [userPosts, setUserPosts] = React.useState<Post[]>([]);
  const [followers, setFollowers] = React.useState<User[]>([]);
  const [following, setFollowing] = React.useState<User[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  
  const appContext = React.useContext(AppContext);
  const currentUser = appContext?.currentUser;
  const isFreeMode = appContext?.isFreeMode;

  const [isFollowing, setIsFollowing] = React.useState(false);
  const [isSubscribed, setIsSubscribed] = React.useState(false);

  React.useEffect(() => {
    const fetchData = async () => {
      if (!username) return;
      setIsLoading(true);
      try {
        const fetchedUser = await getUser(username as string, 'username');
        if (fetchedUser) {
          setUser(fetchedUser);
          
          const [userPosts, userFollowers, userFollowing] = await Promise.all([
            getPosts(fetchedUser.id),
            getFollowers(fetchedUser.id),
            getFollowing(fetchedUser.id)
          ]);

          setUserPosts(userPosts);
          setFollowers(userFollowers);
          setFollowing(userFollowing);

          if (currentUser) {
             setIsFollowing(userFollowers.some(f => f.id === currentUser.id));
             setIsSubscribed(currentUser.subscriptions?.includes(fetchedUser.id) ?? false);
          }
        } else {
          notFound();
        }
      } catch (error) {
        console.error("Failed to fetch profile data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, [username, currentUser]);

  const isCurrentUserProfile = user?.id === currentUser?.id;


  if (isLoading || !user || !currentUser || !appContext) {
    return <ProfileLoading />;
  }

  const handleFollowToggle = async () => {
    if (isCurrentUserProfile || !currentUser) return;
    
    // Optimistic UI update
    const currentlyFollowing = isFollowing;
    setIsFollowing(!currentlyFollowing);
    
    // Optimistically update followers list for the viewed profile
    if (currentlyFollowing) {
        setFollowers(prev => prev.filter(f => f.id !== currentUser.id));
    } else {
        setFollowers(prev => [...prev, currentUser]);
    }


    try {
        await toggleFollow(currentUser.id, user.id, currentlyFollowing);
        toast({ title: currentlyFollowing ? `Unfollowed ${user.name}` : `You are now following ${user.name}` });
    } catch (error) {
        // Revert UI on error
        setIsFollowing(currentlyFollowing);
         if (currentlyFollowing) {
            setFollowers(prev => [...prev, currentUser]);
        } else {
            setFollowers(prev => prev.filter(f => f.id !== currentUser.id));
        }
        toast({ variant: 'destructive', title: 'Action failed', description: 'Please try again.' });
    }
  };

  const handleMessage = () => {
    if (isCurrentUserProfile || !currentUser || !appContext || !user) return;
    const { conversations, createConversation } = appContext;

    const existingConvo = conversations.find(c => 
      c.type === 'direct' &&
      c.participants.length === 2 &&
      c.participants.some(p => p.id === user.id) &&
      c.participants.some(p => p.id === currentUser.id)
    );

    if (existingConvo) {
      router.push(`/messages?conversationId=${existingConvo.id}`);
    } else {
      // Create a new conversation
      const newConvo: Conversation = {
        id: `dm-${Date.now()}`,
        type: 'direct',
        participants: [currentUser, user],
        messages: [],
        unreadCount: 0,
      };
      createConversation(newConvo);
    }
  };
  
  const handleSubscribe = async () => {
    if (isCurrentUserProfile || !user.creatorBalance || !appContext || !currentUser) return;
    const { setCurrentUser } = appContext;
    const currentlySubscribed = isSubscribed;
    
    // Optimistic UI update
    setIsSubscribed(!currentlySubscribed);

    try {
      const result = await subscribeToCreator(currentUser.id, user.id, currentlySubscribed);
      
      if (result.success) {
        if (result.newBalance !== undefined) {
           setCurrentUser({ ...currentUser!, diamonds: result.newBalance });
        }
        toast({ title: result.message });
      } else {
        // Revert UI on failure
        setIsSubscribed(currentlySubscribed);
        toast({
            variant: 'destructive',
            title: 'Subscription Failed',
            description: result.message,
            action: result.message === 'Insufficient funds.' ? <Link href="/buy-currency"><Button variant="secondary">Buy Diamonds</Button></Link> : undefined
        });
      }
    } catch (error: any) {
        setIsSubscribed(currentlySubscribed);
        toast({ variant: 'destructive', title: 'Subscription Error', description: error.message || 'Could not complete the transaction.' });
    }
  };
  
  const pinnedPost = userPosts.find(post => post.isPinned);
  const otherPosts = userPosts.filter(post => !post.isPinned);
  const videoPosts = userPosts.filter(post => post.video);
  const imagePosts = userPosts.filter(post => post.images && post.images.length > 0);
  const savedPosts = userPosts.filter(post => currentUser?.savedPostIds?.includes(post.id));


  const handleBlock = () => {
    toast({
      title: `Blocked ${user.name}`,
      description: "You will no longer see their posts or profile.",
    });
    router.push('/');
  };

  const handleReport = () => {
    toast({
      title: `Reported ${user.name}`,
      description: "Thank you for helping keep the community safe.",
    });
  };

  const openLightbox = (images: string[], startIndex: number) => {
    setLightboxImages(images);
    setLightboxStartIndex(startIndex);
    setIsLightboxOpen(true);
  };
  const closeLightbox = () => setIsLightboxOpen(false);
  
  const handleHighlightClick = (highlight: StoryHighlight) => {
    const storyId = `story-highlight-${highlight.id}`;
    const story: Story = {
      id: storyId,
      user: user,
      pages: highlight.pages,
      createdAt: "Highlights"
    }
    if (!mockStories.find(s => s.id === storyId)) {
        mockStories.unshift(story);
    }
    router.push(`/stories/${user.username}?storyId=${storyId}`);
  };

  const handleProfileUpdate = async (updatedData: Partial<User>, avatarFile?: File | null, coverFile?: File | null) => {
    try {
      await updateUser(user.id, updatedData, avatarFile, coverFile);

      // Create temporary local URLs for optimistic update
      const newAvatarUrl = avatarFile ? URL.createObjectURL(avatarFile) : user.avatar.imageUrl;
      const newCoverUrl = coverFile ? URL.createObjectURL(coverFile) : user.coverPhoto.imageUrl;

      setUser(prevUser => ({
        ...prevUser!,
        ...updatedData,
        avatar: { ...prevUser!.avatar, imageUrl: newAvatarUrl },
        coverPhoto: { ...prevUser!.coverPhoto, imageUrl: newCoverUrl },
      }));

      toast({ title: 'Profile Updated', description: 'Your changes have been saved.' });
    } catch (error) {
      console.error("Failed to update profile:", error);
      toast({ variant: 'destructive', title: 'Update Failed', description: 'Could not save your changes.' });
    }
  };

  const handleBoostPost = async (postId: string) => {
    try {
        await updatePost(postId, { isBoosted: true });
        setUserPosts(prevPosts => 
          prevPosts.map(p => 
            p.id === postId ? { ...p, isBoosted: true } : p
          )
        );
        toast({
          title: "Post Boosted!",
          description: "Your post is now being shown to a wider audience.",
        });
    } catch (error) {
        toast({
            variant: 'destructive',
            title: 'Failed to boost post',
        })
    }
  };
  
  const isEligibleForSubscription = canUserReceiveSubscriptions(user);

  return (
    <>
      <ImageLightbox 
        isOpen={isLightboxOpen}
        images={lightboxImages}
        startIndex={lightboxStartIndex}
        onClose={closeLightbox}
      />
      <div className="bg-background">
        <div className="container mx-auto max-w-4xl py-4 sm:py-6">
          <Card className="overflow-hidden rounded-lg border shadow-sm">
            <CardContent className="p-0">
              <div className="relative group h-48 w-full sm:h-60 block">
                {!isFreeMode ? (
                  <Image 
                    src={user.coverPhoto.imageUrl}
                    alt={`${user.name}'s cover photo`}
                    fill
                    className="object-cover"
                    data-ai-hint={user.coverPhoto.imageHint}
                    priority
                  />
                ) : (
                  <div className="h-full w-full bg-muted" />
                )}
                 {isCurrentUserProfile && (
                  <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <EditProfileWrapper user={user} onProfileUpdate={handleProfileUpdate}>
                      <Button variant="outline" className="bg-black/50 border-white/50 text-white hover:bg-black/70 hover:text-white">
                        <Camera className="mr-2 h-4 w-4" />
                        Edit Cover Photo
                      </Button>
                    </EditProfileWrapper>
                  </div>
                )}
              </div>
              
              <div className="relative flex flex-col items-center p-4 pt-0">
                <div className="absolute -top-16 group">
                   <UserAvatar user={user} className="h-32 w-32 border-4 border-background" />
                   {isCurrentUserProfile && (
                     <EditProfileWrapper user={user} onProfileUpdate={handleProfileUpdate}>
                        <div className="absolute inset-0 rounded-full bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer">
                            <Camera className="h-8 w-8 text-white" />
                        </div>
                     </EditProfileWrapper>
                   )}
                </div>

                <div className="mt-16 w-full text-center">
                    <h1 className="font-headline text-2xl font-bold md:text-3xl inline-flex items-center">
                      {user.name}
                      <VerifiedBadge user={user} />
                    </h1>
                    {user.pronouns && (
                      <p className="text-sm text-muted-foreground">{user.pronouns}</p>
                    )}
                    <div className="mt-2 flex justify-center gap-4 text-sm">
                        <UserListDialog title="Followers" users={followers}>
                            <button className="hover:underline">
                                <strong>{formatNumber(followers.length)}</strong> followers
                            </button>
                        </UserListDialog>
                        <UserListDialog title="Following" users={following}>
                            <button className="hover:underline">
                                <strong>{formatNumber(following.length)}</strong> following
                            </button>
                        </UserListDialog>
                    </div>
                    <p className="mx-auto mt-2 max-w-prose text-sm text-muted-foreground">{user.bio}</p>
                </div>

                <div className="mt-4 flex w-full flex-wrap items-center justify-center gap-2">
                  {isCurrentUserProfile ? (
                    <>
                      <EditProfileWrapper user={user} onProfileUpdate={handleProfileUpdate}>
                        <Button size="lg" className="flex-1">
                          <Pencil className="mr-2 h-4 w-4" />
                          Edit Profile
                        </Button>
                      </EditProfileWrapper>
                       <Link href="/dashboard" passHref>
                        <Button size="lg" variant="secondary" className="flex-1">
                          <LayoutDashboard className="mr-2 h-4 w-4" />
                          Dashboard
                        </Button>
                      </Link>
                      {!(user.isSuperAdmin || !!user.adminRole || !!user.isVerified) && (
                        <GetVerifiedDialog>
                           <Button size="lg" variant="secondary" className="flex-1 bg-purple-100 text-purple-700 hover:bg-purple-200">
                              <Check className="mr-2 h-4 w-4" /> Get Verified
                            </Button>
                        </GetVerifiedDialog>
                      )}
                    </>
                  ) : (
                    <>
                      <Button size="lg" className="flex-1" variant={isFollowing ? 'secondary' : 'default'} onClick={handleFollowToggle}>
                          {isFollowing ? <UserCheck className="mr-2 h-5 w-5" /> : <UserPlus className="mr-2 h-5 w-5" />}
                          {isFollowing ? 'Following' : 'Follow'}
                      </Button>
                      {isEligibleForSubscription && (
                          <SubscriptionButton isSubscribed={isSubscribed} onSubscribe={handleSubscribe} creatorName={user.name} currentUserDiamonds={currentUser.diamonds} />
                      )}
                      <Button size="lg" variant="secondary" className="flex-1" onClick={handleMessage}>
                          <MessageCircle className="mr-2 h-5 w-5" /> Message
                      </Button>
                    </>
                  )}
                  <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button size="lg" variant="secondary" className="px-3">
                            <MoreHorizontal className="h-5 w-5" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                          {!isCurrentUserProfile && (
                          <>
                              <DropdownMenuItem onSelect={handleBlock}>
                                  <ShieldX className="mr-2 h-4 w-4" /> Block User
                              </DropdownMenuItem>
                              <DropdownMenuItem onSelect={handleReport}>
                                  <AlertTriangle className="mr-2 h-4 w-4" /> Report User
                              </DropdownMenuItem>
                          </>
                          )}
                           {isCurrentUserProfile && (
                              <DropdownMenuItem>
                                  Settings
                              </DropdownMenuItem>
                          )}
                      </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                
                {!isFreeMode && user.highlights && user.highlights.length > 0 && (
                  <div className="w-full">
                    <Separator className="mt-6 mb-4" />
                    <StoryHighlights highlights={user.highlights} onHighlightClick={handleHighlightClick}/>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="posts" className="w-full pt-4">
            <TabsList className="flex w-full justify-around rounded-none border-b bg-transparent p-0">
              <TabsTrigger value="posts" className="flex-1 rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none">Posts</TabsTrigger>
              <TabsTrigger value="about" className="flex-1 rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none">About</TabsTrigger>
              {!isFreeMode && <TabsTrigger value="reels" className="flex-1 rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none">Reels</TabsTrigger>}
              {isCurrentUserProfile && (
                <TabsTrigger value="saved" className="flex-1 rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none">Saved</TabsTrigger>
              )}
              {!isFreeMode && <TabsTrigger value="media" className="flex-1 rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none">Media</TabsTrigger>}
            </TabsList>
            <TabsContent value="posts" className="mt-6 space-y-6">
                {pinnedPost && (
                  <div>
                    <p className="text-sm font-semibold text-muted-foreground mb-2 flex items-center gap-2 px-1">
                      <Pin className="w-4 h-4" /> Pinned Post
                    </p>
                    <PostCard post={pinnedPost} onBoostPost={() => handleBoostPost(pinnedPost.id)} />
                  </div>
                )}
                {otherPosts.map((post) => (
                    <PostCard key={post.id} post={post} onBoostPost={() => handleBoostPost(post.id)} />
                ))}
                {userPosts.length === 0 && (
                    <Card className="flex h-48 items-center justify-center rounded-lg border">
                        <p className="text-muted-foreground">No posts yet.</p>
                    </Card>
                )}
            </TabsContent>
            <TabsContent value="about" className="mt-6">
                <Card className="p-6">
                    <h3 className="font-bold text-lg mb-4">Details</h3>
                    <div className="space-y-3 text-sm text-foreground">
                        {user.work && (
                            <div className="flex items-center gap-3">
                                <Rss className="h-5 w-5 text-muted-foreground" />
                                <span>{user.work}</span>
                            </div>
                        )}
                        {user.education && (
                            <div className="flex items-center gap-3">
                                <Rss className="h-5 w-5 text-muted-foreground" />
                                <span>{user.education}</span>
                            </div>
                        )}
                        {user.homeTown && (
                            <div className="flex items-center gap-3">
                                <Rss className="h-5 w-5 text-muted-foreground" />
                                <span>From {user.homeTown}</span>
                            </div>
                        )}
                        {user.website && (
                            <div className="flex items-center gap-3">
                                <LinkIcon className="h-5 w-5 text-muted-foreground" />
                                <a href={user.website} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                                    {user.website}
                                </a>
                            </div>
                        )}
                    </div>
                </Card>
            </TabsContent>
            <TabsContent value="reels" className="mt-6">
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-1">
                    {videoPosts.map(post => (
                        <div key={post.id} className="relative aspect-[9/16] bg-black rounded-md overflow-hidden">
                            <video src={post.video} className="w-full h-full object-cover" muted />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                        </div>
                    ))}
                </div>
                {videoPosts.length === 0 && (
                    <Card className="flex h-48 items-center justify-center rounded-lg border">
                        <p className="text-muted-foreground">No reels yet.</p>
                    </Card>
                )}
            </TabsContent>
             {isCurrentUserProfile && (
              <TabsContent value="saved" className="mt-6 space-y-6">
                  {savedPosts.map((post) => (
                      <PostCard key={post.id} post={post} onBoostPost={() => {}} />
                  ))}
                  {savedPosts.length === 0 && (
                      <Card className="flex h-48 items-center justify-center rounded-lg border">
                          <p className="text-muted-foreground">You haven't saved any posts yet.</p>
                      </Card>
                  )}
              </TabsContent>
            )}
            <TabsContent value="media" className="mt-6">
                 <div className="grid grid-cols-3 gap-1">
                  {imagePosts.flatMap((post, postIndex) => 
                    post.images?.map((image, imageIndex) => {
                      const allImageUrls = imagePosts.flatMap(p => p.images?.map(i => i.imageUrl) || []);
                      const currentImageGlobalIndex = imagePosts.slice(0, postIndex).reduce((acc, p) => acc + (p.images?.length || 0), 0) + imageIndex;
                      
                      return (
                        <button 
                          key={image.id} 
                          className="relative aspect-square bg-muted rounded-md overflow-hidden" 
                          onClick={() => openLightbox(allImageUrls, currentImageGlobalIndex)}
                        >
                          <Image src={image.imageUrl} alt={image.description} fill className="object-cover" />
                        </button>
                      );
                    })
                  )}
                </div>
                {imagePosts.length === 0 && (
                    <Card className="flex h-48 items-center justify-center rounded-lg border">
                        <p className="text-muted-foreground">No media yet.</p>
                    </Card>
                )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </>
  );
}


function StoryHighlights({ highlights, onHighlightClick }: { highlights: StoryHighlight[], onHighlightClick: (highlight: StoryHighlight) => void }) {
  return (
    <div>
        <h2 className="font-bold text-lg text-left">Story Highlights</h2>
        <p className="text-sm text-muted-foreground mb-4 text-left">Keep your favorite stories on your profile</p>
        <ScrollArea className="w-full whitespace-nowrap">
            <div className="flex gap-4 pb-4">
                {highlights.map(highlight => (
                    <div key={highlight.id} className="flex flex-col items-center gap-2 text-center w-20 shrink-0">
                        <button onClick={() => onHighlightClick(highlight)} className="h-20 w-20 rounded-full border-2 border-border overflow-hidden flex items-center justify-center">
                            <Image
                                src={highlight.cover.imageUrl}
                                alt={highlight.title}
                                width={80}
                                height={80}
                                className="object-cover w-full h-full"
                            />
                        </button>
                        <p className="text-sm font-medium truncate w-full">{highlight.title}</p>
                    </div>
                ))}
            </div>
            <ScrollBar orientation="horizontal" />
        </ScrollArea>
    </div>
  )
}

function SubscriptionButton({ isSubscribed, onSubscribe, creatorName, currentUserDiamonds }: { isSubscribed: boolean; onSubscribe: () => void; creatorName: string; currentUserDiamonds: number }) {
  const [open, setOpen] = React.useState(false);

  const handleConfirm = () => {
    onSubscribe();
    setOpen(false);
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="lg" variant={isSubscribed ? 'secondary' : 'default'} className="flex-1 bg-purple-500 hover:bg-purple-600 text-white">
          <Diamond className="mr-2 h-5 w-5" />
          {isSubscribed ? 'Subscribed' : 'Subscribe'}
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{isSubscribed ? 'Cancel Subscription' : 'Confirm Subscription'}</DialogTitle>
          <DialogDescription>
            {isSubscribed ? (
              `Are you sure you want to cancel your monthly subscription to ${creatorName}?`
            ) : (
              `You are about to subscribe to ${creatorName} for 10 💎 per month. This amount will be deducted from your balance monthly. You can cancel at any time.`
            )}
          </DialogDescription>
        </DialogHeader>
        {!isSubscribed && (
          <div className="text-sm text-muted-foreground">
            Your current balance: <span className="font-bold">{currentUserDiamonds} 💎</span>
          </div>
        )}
        <DialogFooter>
          <DialogClose asChild><Button variant="ghost">Cancel</Button></DialogClose>
          <Button onClick={handleConfirm} variant={isSubscribed ? 'destructive' : 'default'}>
            {isSubscribed ? 'Unsubscribe' : 'Confirm & Pay 10 💎'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}


export function EditProfileWrapper({ user, onProfileUpdate, children }: { user: User, onProfileUpdate: (data: Partial<User>, avatarFile?: File | null, coverFile?: File | null) => void, children: React.ReactNode }) {
    const isMobile = useIsMobile();
    const [isOpen, setIsOpen] = React.useState(false);
    
    const handleSaveAndClose = (data: Partial<User>, avatarFile?: File | null, coverFile?: File | null) => {
        onProfileUpdate(data, avatarFile, coverFile);
        setIsOpen(false);
    }
    
    if (isMobile) {
        return (
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
                <SheetTrigger asChild>{children}</SheetTrigger>
                <SheetContent side="bottom" className="h-[95vh] flex flex-col p-0">
                    <SheetHeader className="p-4 flex-row items-center justify-between">
                         <SheetTitle>Edit Profile</SheetTitle>
                         <SheetClose />
                    </SheetHeader>
                    <EditProfileForm user={user} onProfileUpdate={handleSaveAndClose} />
                </SheetContent>
            </Sheet>
        );
    }

    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent className="max-w-md">
                <DialogHeader>
                    <DialogTitle>Edit Profile</DialogTitle>
                </DialogHeader>
                <EditProfileForm user={user} onProfileUpdate={handleSaveAndClose} />
            </DialogContent>
        </Dialog>
    );
}

function EditProfileForm({ user, onProfileUpdate }: { user: User, onProfileUpdate: (data: Partial<User>, avatarFile?: File | null, coverFile?: File | null) => void }) {
  const [formData, setFormData] = React.useState({
    name: user.name,
    username: user.username,
    bio: user.bio,
    pronouns: user.pronouns || '',
    website: user.website || '',
  });

  const [avatarFile, setAvatarFile] = React.useState<File | null>(null);
  const [coverFile, setCoverFile] = React.useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = React.useState(user.avatar.imageUrl);
  const [coverPreview, setCoverPreview] = React.useState(user.coverPhoto.imageUrl);
  const avatarInputRef = React.useRef<HTMLInputElement>(null);
  const coverInputRef = React.useRef<HTMLInputElement>(null);
  const [isSaving, setIsSaving] = React.useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({...prev, [name]: value}));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'avatar' | 'cover') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        if (type === 'avatar') {
          setAvatarFile(file);
          setAvatarPreview(result);
        } else {
          setCoverFile(file);
          setCoverPreview(result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    await onProfileUpdate(formData, avatarFile, coverFile);
    setIsSaving(false);
  };
  
  return (
    <ScrollArea className="flex-1">
        <form onSubmit={handleSubmit} className="space-y-4 p-4">
          <div className="space-y-4">
            <div>
              <Label>Cover Photo</Label>
              <div className="relative mt-1 group aspect-video w-full rounded-lg border bg-muted">
                 <Image src={coverPreview} alt="Cover preview" fill className="object-cover rounded-lg" />
                 <div 
                    className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer rounded-lg"
                    onClick={() => coverInputRef.current?.click()}
                 >
                    <Pencil className="h-6 w-6 text-white"/>
                 </div>
              </div>
            </div>
            <div>
              <Label>Profile Photo</Label>
               <div className="relative mt-1 group w-24 h-24 rounded-full mx-auto">
                 <Image src={avatarPreview} alt="Avatar preview" fill className="object-cover rounded-full" />
                 <div 
                    className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer rounded-full"
                    onClick={() => avatarInputRef.current?.click()}
                 >
                    <Pencil className="h-6 w-6 text-white"/>
                 </div>
              </div>
            </div>
            <input type="file" accept="image/*" ref={avatarInputRef} onChange={(e) => handleFileChange(e, 'avatar')} className="hidden" />
            <input type="file" accept="image/*" ref={coverInputRef} onChange={(e) => handleFileChange(e, 'cover')} className="hidden" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="name">Name</Label>
            <Input id="name" name="name" value={formData.name} onChange={handleInputChange} />
          </div>
           <div className="space-y-2">
            <Label htmlFor="username">Username</Label>
            <Input id="username" name="username" value={formData.username} onChange={handleInputChange} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="bio">Bio</Label>
            <Textarea id="bio" name="bio" value={formData.bio} onChange={handleInputChange} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="pronouns">Pronouns</Label>
            <Input id="pronouns" name="pronouns" value={formData.pronouns} onChange={handleInputChange} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="website">Website</Label>
            <Input id="website" name="website" value={formData.website} onChange={handleInputChange} />
          </div>
          <Button type="submit" className="w-full" disabled={isSaving}>
            {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Check className="mr-2 h-4 w-4"/>}
            Save Changes
          </Button>
        </form>
    </ScrollArea>
  )
}
