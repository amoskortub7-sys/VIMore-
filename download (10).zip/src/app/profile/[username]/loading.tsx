import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent } from '@/components/ui/card';
import { PostCardSkeleton } from '@/components/post-card-skeleton';

export default function ProfileLoading() {
  return (
    <div className="bg-background">
        <div className="container mx-auto max-w-4xl py-4 sm:py-6">
            <Card className="overflow-hidden rounded-lg border shadow-sm">
                <CardContent className="p-0">
                    <Skeleton className="h-48 w-full sm:h-60" />
                    <div className="relative flex flex-col items-center p-4 pt-0">
                        <Skeleton className="absolute -top-16 h-32 w-32 rounded-full border-4 border-background" />

                        <div className="mt-16 w-full text-center space-y-2">
                            <Skeleton className="h-8 w-48 mx-auto" />
                            <Skeleton className="h-4 w-24 mx-auto" />
                            <div className="mt-2 flex justify-center gap-4 text-sm">
                                <Skeleton className="h-5 w-24" />
                                <Skeleton className="h-5 w-24" />
                            </div>
                            <Skeleton className="h-4 w-3/4 mx-auto" />
                        </div>

                        <div className="mt-4 flex w-full flex-wrap items-center justify-center gap-2">
                            <Skeleton className="h-11 flex-1" />
                            <Skeleton className="h-11 flex-1" />
                            <Skeleton className="h-11 w-11" />
                        </div>

                        <div className="w-full">
                             <Skeleton className="h-px w-full my-4" />
                             <div className="flex gap-4 pb-4">
                                {Array.from({ length: 4 }).map((_, i) => (
                                    <div key={i} className="flex flex-col items-center gap-2">
                                        <Skeleton className="h-20 w-20 rounded-full" />
                                        <Skeleton className="h-4 w-16" />
                                    </div>
                                ))}
                             </div>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <div className="mt-4">
                <div className="flex w-full justify-around rounded-none border-b bg-transparent p-0">
                    <Skeleton className="h-10 flex-1" />
                    <Skeleton className="h-10 flex-1" />
                    <Skeleton className="h-10 flex-1" />
                    <Skeleton className="h-10 flex-1" />
                </div>
                 <div className="mt-6 space-y-6">
                    <PostCardSkeleton />
                    <PostCardSkeleton />
                </div>
            </div>
        </div>
    </div>
  );
}
