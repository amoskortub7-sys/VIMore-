import { Skeleton } from '@/components/ui/skeleton';
import { MessageSquarePlus, Search } from 'lucide-react';

export default function MessagesLoading() {
  return (
    <div className="flex h-screen flex-col md:flex-row">
      <div className="w-full shrink-0 border-b md:w-96 md:border-b-0 md:border-r">
        <div className="flex h-full flex-col">
            <header className="border-b p-4">
                 <div className="flex items-center justify-between mb-4">
                    <Skeleton className="h-8 w-32" />
                    <Skeleton className="h-8 w-8 rounded-full" />
                </div>
                 <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Skeleton className="h-10 w-full pl-9" />
                </div>
            </header>
             <div className="flex-1 p-2 space-y-2">
                {Array.from({ length: 10 }).map((_, i) => (
                    <div key={i} className="flex items-center gap-3 rounded-lg p-3">
                        <Skeleton className="h-10 w-10 rounded-full" />
                        <div className="flex-1 space-y-2">
                            <Skeleton className="h-4 w-3/4" />
                            <Skeleton className="h-3 w-1/2" />
                        </div>
                    </div>
                ))}
             </div>
        </div>
      </div>

      <div className="hidden flex-1 flex-col md:flex">
         <div className="flex h-full items-center justify-center bg-secondary/30">
            <div className="text-center">
              <MessageSquarePlus className="mx-auto h-12 w-12 text-muted-foreground" />
              <h3 className="mt-4 text-lg font-semibold">Select a conversation</h3>
              <p className="text-muted-foreground">Start chatting with your friends.</p>
            </div>
          </div>
      </div>
    </div>
  );
}
