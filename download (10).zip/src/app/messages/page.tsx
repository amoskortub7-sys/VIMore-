

'use client';

import * as React from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { 
    Phone, 
    Send, 
    Video, 
    Search, 
    MessageSquarePlus, 
    Check, 
    CheckCheck, 
    X, 
    Heart,
    MoreVertical,
    Pin,
    BellOff,
    PinOff,
    AlertTriangle,
    ShieldX,
    ArrowDown,
    Paperclip,
    ImageIcon,
    ArrowLeft,
    Users,
    UserPlus,
    Mic,
    Trash2,
    Play,
    Pause,
    Palette,
    Loader2,
    Crown,
    UserMinus,
    Edit,
    BarChart3,
    Camera,
    Info,
    Smile,
    ThumbsUp,
    FileVideo,
    MapPin,
} from 'lucide-react';
import { getImage, allMockThemes, mockPosts } from '@/lib/data';
import type { Conversation, Message, User, VoiceMemo, ConversationTheme, ImagePlaceholder, Poll } from '@/lib/data';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { UserAvatar } from '@/components/user-avatar';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn, formatTime } from '@/lib/utils';
import { useIsMobile } from '@/hooks/use-mobile';
import { Badge } from '@/components/ui/badge';
import { format, isToday, isYesterday, formatDistanceToNow, isSameDay } from 'date-fns';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogClose, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { AnimatePresence, motion } from 'framer-motion';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import Image from 'next/image';
import { Popover, PopoverContent, PopoverTrigger, PopoverClose } from '@/components/ui/popover';
import { Checkbox } from '@/components/ui/checkbox';
// import { generateChatBackground } from '@/ai/flows/generate-chat-background'; // Disabled: Groq does not support image models.
import { PostPoll, CreatePollButton } from '@/components/create-post-form';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AppContext } from '@/components/app-shell';
import { getUsers } from '@/services/userService';
import { Skeleton } from '@/components/ui/skeleton';


export default function MessagesPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const isMobile = useIsMobile();
  const appContext = React.useContext(AppContext);
  const selectedConversationId = searchParams.get('conversationId');

  if (!appContext) return null;
  const { currentUser, isFreeMode, conversations, updateConversation, createConversation } = appContext;

  const selectedConvo = React.useMemo(() => {
    return conversations.find(c => c.id === selectedConversationId);
  }, [selectedConversationId, conversations]);

  // Effect to handle adding a message after a call ends
  React.useEffect(() => {
    const callEnded = searchParams.get('callEnded');
    const conversationId = searchParams.get('conversationId');
    const callDuration = searchParams.get('callDuration');
    const callType = searchParams.get('callType');
    
    if (callEnded === 'true' && conversationId && callDuration && currentUser) {
      const convoToUpdate = conversations.find(c => c.id === conversationId);
      if (convoToUpdate) {
        const durationFormatted = formatTime(parseInt(callDuration, 10));
        const callMessageContent = `${callType === 'video' ? 'Video' : 'Audio'} call ended • ${durationFormatted}`;
        
        // Prevent adding duplicate messages
        const alreadyExists = convoToUpdate.messages.some(m => m.content === callMessageContent);

        if (!alreadyExists) {
            const callMessage: Message = {
                id: `msg-call-${Date.now()}`,
                sender: currentUser,
                content: callMessageContent,
                timestamp: new Date(),
                status: 'read',
                reactions: [],
            };
            const updatedMessages = [...convoToUpdate.messages, callMessage];
            const updatedConvo = { ...convoToUpdate, messages: updatedMessages };
            
            updateConversation(updatedConvo);
        }

        // Clean up URL params to prevent re-triggering
        const newParams = new URLSearchParams(searchParams.toString());
        newParams.delete('callEnded');
        newParams.delete('callDuration');
        newParams.delete('callType');
        router.replace(`/messages?${newParams.toString()}`, { scroll: false });
      }
    }
  }, [searchParams, conversations, router, currentUser, updateConversation]);
  
  const getParticipant = (convo: Conversation): User | undefined => {
    if (convo.type === 'direct' && convo.participants) {
      return convo.participants.find(p => p.id !== currentUser.id);
    }
    return undefined;
  };


  const handleSelectConvo = (convoId: string) => {
    router.push(`/messages?conversationId=${convoId}`);
  };
  
  const handleBack = () => {
    router.push('/messages');
  };

  // On mobile, if a conversation is selected, we render ONLY the ChatView.
  // We wrap it in a div that ensures it takes full screen height.
  if (isMobile && selectedConvo) {
    return (
      <div className="h-screen">
        <ChatView conversation={selectedConvo} onBack={handleBack} onUpdateConversation={updateConversation} currentUser={currentUser} getParticipant={getParticipant} isFreeMode={isFreeMode}/>
      </div>
    );
  }

  return (
    <div className="flex h-screen flex-col md:flex-row">
      <div className={cn("w-full shrink-0 border-b md:w-96 md:border-b-0 md:border-r", selectedConvo?.id && isMobile && "hidden")}>
        <ConversationList 
          conversations={conversations}
          onSelectConvo={handleSelectConvo}
          selectedConvoId={selectedConvo?.id}
          onUpdateConversation={updateConversation}
          currentUser={currentUser}
          getParticipant={getParticipant}
          onCreateConversation={createConversation}
        />
      </div>

      <div className="hidden flex-1 flex-col md:flex">
        {selectedConvo ? (
          <ChatView conversation={selectedConvo} onUpdateConversation={updateConversation} currentUser={currentUser} getParticipant={getParticipant} isFreeMode={isFreeMode}/>
        ) : (
          <div className="flex h-full items-center justify-center bg-secondary/30">
            <div className="text-center">
              <MessageSquarePlus className="mx-auto h-12 w-12 text-muted-foreground" />
              <h3 className="mt-4 text-lg font-semibold">Select a conversation</h3>
              <p className="text-muted-foreground">Start chatting with your friends.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function ConversationList({ conversations, onSelectConvo, selectedConvoId, onUpdateConversation, currentUser, getParticipant, onCreateConversation }: { conversations: Conversation[], onSelectConvo: (convoId: string) => void; selectedConvoId?: string; onUpdateConversation: (convo: Conversation) => void; currentUser: User; getParticipant: (convo: Conversation) => User | undefined; onCreateConversation: (convo: Conversation) => void;}) {
  const [searchQuery, setSearchQuery] = React.useState('');

  const filteredConversations = conversations.filter(convo => {
    if (searchQuery.length === 0) return true;
    const lowerCaseQuery = searchQuery.toLowerCase();
    if (convo.type === 'group') {
      return convo.name?.toLowerCase().includes(lowerCaseQuery);
    }
    const participant = getParticipant(convo);
    return participant?.name.toLowerCase().includes(lowerCaseQuery) || participant?.username.toLowerCase().includes(lowerCaseQuery);
  });
  
  const pinned = filteredConversations.filter(c => c.isPinned);
  const unpinned = filteredConversations.filter(c => !c.isPinned);

  return (
    <div className="flex h-full flex-col">
        <header className="border-b p-4 shrink-0">
            <div className="flex items-center justify-between mb-4">
                <h2 className="font-headline text-2xl font-bold">Chats</h2>
                 <div className="flex items-center gap-2">
                    <NewMessageDialog onCreateConversation={onCreateConversation}>
                       <Button variant="ghost" size="icon">
                        <MessageSquarePlus className="h-5 w-5 text-muted-foreground"/>
                      </Button>
                    </NewMessageDialog>
                </div>
            </div>
             <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                    placeholder="Search conversations..." 
                    className="pl-9"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                />
            </div>
        </header>
        <ScrollArea className="flex-1">
          <div className="p-2">
            {pinned.length > 0 && (
                <div className="mb-2">
                    <p className="px-3 text-xs font-semibold text-muted-foreground">PINNED</p>
                    {pinned.map((convo) => (
                      <ConversationItem
                        key={convo.id}
                        convo={convo}
                        isSelected={selectedConvoId === convo.id}
                        onClick={() => onSelectConvo(convo.id)}
                        onUpdateConversation={onUpdateConversation}
                        getParticipant={getParticipant}
                        currentUser={currentUser}
                      />
                    ))}
                </div>
            )}
            {unpinned.map((convo) => (
              <ConversationItem
                key={convo.id}
                convo={convo}
                isSelected={selectedConvoId === convo.id}
                onClick={() => onSelectConvo(convo.id)}
                onUpdateConversation={onUpdateConversation}
                getParticipant={getParticipant}
                currentUser={currentUser}
              />
            ))}
             {filteredConversations.length === 0 && (
                <div className="text-center text-muted-foreground py-10">
                    <p>No conversations found.</p>
                </div>
            )}
          </div>
        </ScrollArea>
    </div>
  );
}

function ConversationItem({ convo, isSelected, onClick, onUpdateConversation, getParticipant, currentUser }: { convo: Conversation, isSelected: boolean, onClick: () => void; onUpdateConversation: (convo: Conversation) => void; getParticipant: (convo: Conversation) => User | undefined; currentUser: User;}) {
  const lastMessage = convo.messages[convo.messages.length - 1];
  const participant = getParticipant(convo);
  const isGroup = convo.type === 'group';
  
  const getDisplayName = (user: User) => {
    return convo.nicknames?.[user.id] || user.name;
  };

  const name = isGroup ? convo.name : (participant ? getDisplayName(participant) : '');
  const avatarUser = isGroup ? undefined : participant;
  const avatarImage = isGroup ? convo.avatar : participant?.avatar;

  const truncateMessage = (message: Message | undefined) => {
    if (!message) return 'No messages yet';
    
    let content = message.content;
    let prefix = '';
    
    if (isGroup && message.sender.id !== currentUser.id) {
      prefix = `${getDisplayName(message.sender).split(' ')[0]}: `;
    }

    if (message.image) {
        content = "Sent an image";
    }
    if (message.voiceMemo) {
        content = "Sent a voice message";
    }
    if (message.poll) {
        content = "Sent a poll";
    }

    const fullPreview = `${prefix}${content}`;
    const words = fullPreview.split(' ');
    if (words.length > 5) {
      return words.slice(0, 5).join(' ') + '...';
    }
    return fullPreview;
  };

  const formatTimestamp = (date: Date) => {
    if (isToday(date)) return format(date, 'p');
    if (isYesterday(date)) return 'Yesterday';
    return format(date, 'P');
  }

  const { toast } = useToast();

  const handleTogglePin = (e: React.MouseEvent) => {
    e.stopPropagation();
    onUpdateConversation({ ...convo, isPinned: !convo.isPinned });
    toast({ title: convo.isPinned ? 'Unpinned conversation' : 'Pinned conversation' });
  };
  
  const handleToggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    onUpdateConversation({ ...convo, isMuted: !convo.isMuted });
    toast({ title: convo.isMuted ? 'Unmuted conversation' : 'Muted conversation' });
  };


  return (
     <div className="relative group">
        <button
          onClick={onClick}
          className={cn(
            'flex w-full items-center gap-3 rounded-lg p-3 text-left transition-colors',
            isSelected ? 'bg-secondary' : 'hover:bg-accent'
          )}
        >
          {isGroup ? (
              <Avatar className="h-10 w-10">
                {avatarImage && <AvatarImage src={avatarImage.imageUrl} alt={name} data-ai-hint={avatarImage.imageHint} />}
                <AvatarFallback>{name?.charAt(0)}</AvatarFallback>
              </Avatar>
            ) : (
             avatarUser && <UserAvatar user={avatarUser} isOnline={avatarUser.isOnline} />
          )}

          <div className="flex-1 overflow-hidden">
            <p className="font-semibold truncate flex items-center gap-2">
                {name}
                {convo.isMuted && <BellOff className="h-4 w-4 text-muted-foreground"/>}
            </p>
            <p className={cn("text-sm truncate", convo.unreadCount > 0 ? "font-bold text-foreground" : "text-muted-foreground")}>
                 {truncateMessage(lastMessage)}
            </p>
          </div>
          <div className="flex flex-col items-end gap-1 text-xs text-muted-foreground">
            <span>{lastMessage ? formatTimestamp(lastMessage.timestamp) : ''}</span>
            {convo.unreadCount > 0 && <Badge variant="secondary" className="bg-primary text-primary-foreground">{convo.unreadCount}</Badge>}
          </div>
        </button>
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="absolute top-1/2 -translate-y-1/2 right-2 h-8 w-8 rounded-full opacity-0 group-hover:opacity-100">
                    <MoreVertical className="h-4 w-4" />
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={handleTogglePin}>
                    {convo.isPinned ? <PinOff className="mr-2 h-4 w-4" /> : <Pin className="mr-2 h-4 w-4" />}
                    <span>{convo.isPinned ? 'Unpin' : 'Pin'}</span>
                </DropdownMenuItem>
                 <DropdownMenuItem onClick={handleToggleMute}>
                    <BellOff className="mr-2 h-4 w-4" />
                    <span>{convo.isMuted ? 'Unmute' : 'Mute'}</span>
                </DropdownMenuItem>
            </DropdownMenuContent>
        </DropdownMenu>
     </div>
  );
}

function ChatView({ conversation, onBack, onUpdateConversation, currentUser, getParticipant, isFreeMode }: { conversation: Conversation; onBack?: () => void; onUpdateConversation: (convo: Conversation) => void; currentUser: User; getParticipant: (convo: Conversation) => User | undefined; isFreeMode: boolean;}) {
    const [messages, setMessages] = React.useState(conversation.messages);
    const [newMessage, setNewMessage] = React.useState('');
    const [isTyping, setIsTyping] = React.useState(false);
    const scrollAreaRef = React.useRef<HTMLDivElement>(null);
    const [isRecording, setIsRecording] = React.useState(false);
    const recordingTimerRef = React.useRef<NodeJS.Timeout | null>(null);
    const [recordingDuration, setRecordingDuration] = React.useState(0);
    const { toast } = useToast();
    
    const [showMentionPopover, setShowMentionPopover] = React.useState(false);
    const [mentionQuery, setMentionQuery] = React.useState('');
    const mentionTriggerIndex = React.useRef<number | null>(null);

    const [chatSearchQuery, setChatSearchQuery] = React.useState('');
    const [isSearching, setIsSearching] = React.useState(false);
    const [searchIndex, setSearchIndex] = React.useState(0);
    const searchResultsRef = React.useRef<HTMLElement[]>([]);

    const [isPopoverOpen, setIsPopoverOpen] = React.useState(false);
    const longPressTimer = React.useRef<NodeJS.Timeout | null>(null);
    
    const participant = getParticipant(conversation);
    const isGroup = conversation.type === 'group';
    const isAdmin = conversation.adminIds?.includes(currentUser.id) ?? false;
    const pinnedMessage = conversation.pinnedMessageId ? messages.find(m => m.id === conversation.pinnedMessageId) : null;
    
    const getDisplayName = (user: User) => {
      return conversation.nicknames?.[user.id] || user.name;
    };


    React.useEffect(() => {
        setMessages(conversation.messages);
    }, [conversation])

    const sendMessage = (messageData: Partial<Message>) => {
        const message: Message = {
            id: `msg-${Date.now()}`,
            sender: currentUser,
            content: '',
            timestamp: new Date(),
            status: 'sent',
            reactions: [],
            ...messageData,
        };
        const newMessages = [...messages, message];
        onUpdateConversation({ ...conversation, messages: newMessages });

        if (!isGroup) {
            setIsTyping(true);
        }

        setTimeout(() => {
          onUpdateConversation({ ...conversation, messages: newMessages.map(m => m.id === message.id ? {...m, status: 'delivered'} : m) });
        }, 500);
        
        setTimeout(() => {
           onUpdateConversation({ ...conversation, messages: newMessages.map(m => m.id === message.id ? {...m, status: 'read'} : m) });
           if (!isGroup) setIsTyping(false);
        }, 2000);
    };


    const handleSendTextOrLike = (e: React.FormEvent) => {
        e.preventDefault();
        if (newMessage.trim()) {
            sendMessage({ content: newMessage });
            setNewMessage('');
        } else {
            sendMessage({ content: '👍' });
        }
    }
    
    const handleReaction = (messageId: string, emoji: string) => {
      const newMessages = messages.map(msg => {
        if (msg.id === messageId) {
          const existingReactionIndex = msg.reactions.findIndex(r => r.userId === currentUser.id);
          if (existingReactionIndex > -1) {
            const newReactions = [...msg.reactions];
            if (newReactions[existingReactionIndex].emoji === emoji) {
              return { ...msg, reactions: newReactions.filter((_, i) => i !== existingReactionIndex) };
            }
            newReactions[existingReactionIndex].emoji = emoji;
            return { ...msg, reactions: newReactions };
          } else {
            return { ...msg, reactions: [...msg.reactions, { userId: currentUser.id, emoji }] };
          }
        }
        return msg;
      });
      onUpdateConversation({ ...conversation, messages: newMessages });
    };

    const handleSendImage = () => {
        sendMessage({ image: getImage('post1') });
    }
    
    const handleSendPoll = (poll: Omit<Poll, 'totalVotes' | 'options'> & { options: string[] }) => {
       const newPoll: Poll = {
            question: poll.question,
            options: poll.options.map(opt => ({ text: opt, votes: 0 })),
            totalVotes: 0,
       };
       sendMessage({ poll: newPoll });
    }

    const handleStartRecording = () => {
      setIsRecording(true);
      setRecordingDuration(0);
      recordingTimerRef.current = setInterval(() => {
        setRecordingDuration(prev => prev + 1);
      }, 1000);
    };

    const handleStopRecording = (send: boolean) => {
      setIsRecording(false);
      if (recordingTimerRef.current) {
        clearInterval(recordingTimerRef.current);
      }
      if (send && recordingDuration > 0) {
        sendMessage({
          voiceMemo: {
            src: 'https://storage.googleapis.com/static.a-studio.dev/alpha/music/empty-mind-182470.mp3',
            duration: recordingDuration,
          },
        });
      }
      setRecordingDuration(0);
    };

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const text = e.target.value;
        setNewMessage(text);

        const cursorPosition = e.target.selectionStart;
        if (cursorPosition === null) return;
        
        const textBeforeCursor = text.substring(0, cursorPosition);
        const atIndex = textBeforeCursor.lastIndexOf('@');
        const spaceAfterAt = textBeforeCursor.indexOf(' ', atIndex);

        if (atIndex > -1 && (spaceAfterAt === -1 || spaceAfterAt < atIndex)) {
            const query = textBeforeCursor.substring(atIndex + 1);
            setMentionQuery(query);
            mentionTriggerIndex.current = atIndex;
            setShowMentionPopover(true);
        } else {
            setShowMentionPopover(false);
        }
    };
    
    const handleMentionSelect = (user: User) => {
        const text = newMessage;
        const atIndex = mentionTriggerIndex.current;
        if (atIndex === null) return;

        const textBefore = text.substring(0, atIndex);
        const textAfter = text.substring(atIndex + mentionQuery.length + 1);
        
        const newText = `${textBefore}@${user.username} ${textAfter}`;
        setNewMessage(newText);
        setShowMentionPopover(false);
    };


    React.useEffect(() => {
        if (scrollAreaRef.current) {
            scrollAreaRef.current.scrollTo({ top: scrollAreaRef.current.scrollHeight, behavior: 'smooth' });
        }
    }, [messages]);
    
    const handlePinMessage = (messageId: string | null) => {
        onUpdateConversation({ ...conversation, pinnedMessageId: messageId });
        toast({ title: messageId ? 'Message pinned!' : 'Message unpinned.' });
    };

    const renderMessageGroup = (group: Message[], groupIndex: number) => {
        const messageDate = group[0].timestamp;
        let dateLabel;
        
        const unreadMessageIndex = messages.findIndex(m => m.status !== 'read');
        
        if (isToday(messageDate)) {
            dateLabel = "Today";
        } else if (isYesterday(messageDate)) {
            dateLabel = "Yesterday";
        } else {
            dateLabel = format(messageDate, 'MMMM d, yyyy');
        }
        
        let showDate = true;
        if (groupIndex > 0) {
           const prevGroup = messageGroups[groupIndex - 1];
           const lastMessageOfPrevGroup = prevGroup[prevGroup.length - 1];
           if (isSameDay(messageDate, lastMessageOfPrevGroup.timestamp)) {
               showDate = false;
           }
        }


        return (
            <div key={groupIndex} className="flex flex-col gap-1">
                {showDate && (
                    <div className="relative my-4 flex justify-center">
                        <Separator className="absolute top-1/2 -z-10" />
                        <span className="bg-background px-2 text-xs text-muted-foreground rounded-full">{dateLabel}</span>
                    </div>
                )}
                 {group.map((msg, index) => (
                    <React.Fragment key={msg.id}>
                        {(groupIndex === unreadMessageIndex || (groupIndex > 0 && messageGroups[groupIndex-1].some(m=>m.status!=='read') && msg.status === 'read')) && (
                           <div className="relative my-4 flex items-center justify-center">
                                <Separator className="absolute top-1/2 -z-10 w-full text-primary" />
                                <span className="bg-background px-2 text-xs text-primary font-semibold rounded-full">Unread messages</span>
                            </div>
                        )}
                        {renderMessageBubble(msg, group, index)}
                    </React.Fragment>
                 ))}
            </div>
        )
    }

    const messageGroups = messages.reduce((groups, message) => {
        const lastGroup = groups[groups.length - 1];
        if (lastGroup && isSameDay(lastGroup[0].timestamp, message.timestamp)) {
            lastGroup.push(message);
        } else {
            groups.push([message]);
        }
        return groups;
    }, [] as Message[][]);

    const renderMessageBubble = (msg: Message, group: Message[], index: number) => {
        const prevMessage = group[index - 1];
        const nextMessage = group[index + 1];
        const isOwn = msg.sender.id === currentUser.id;
        
        const isFirstInGroup = !prevMessage || prevMessage.sender.id !== msg.sender.id || (msg.timestamp.getTime() - prevMessage.timestamp.getTime() > 60000);
        const isLastInGroup = !nextMessage || nextMessage.sender.id !== msg.sender.id || (nextMessage.timestamp.getTime() - msg.timestamp.getTime() > 60000);

        if (!msg.sender || (msg.content.includes('call ended') && msg.sender.id === currentUser.id)) {
            return (
                <div key={msg.id} className="flex justify-center my-2">
                    <div className="text-xs text-muted-foreground bg-secondary rounded-full px-3 py-1">
                        {msg.content}
                    </div>
                </div>
            )
        }
        
        const handlePointerDown = (e: React.PointerEvent) => {
            if (e.pointerType === 'mouse' && e.button !== 0) return;
            isPopoverOpen && setIsPopoverOpen(false); // Close existing popover
            longPressTimer.current = setTimeout(() => {
                setIsPopoverOpen(true);
            }, 500);
        };

        const handlePointerUp = () => {
            if (longPressTimer.current) {
                clearTimeout(longPressTimer.current);
            }
        };

        const bubbleClasses = cn(
            'max-w-xs rounded-2xl text-sm sm:max-w-md relative group',
             !msg.image && !msg.voiceMemo && !msg.poll && 'px-4 py-2',
            isOwn ? 'bg-chat-outgoing text-chat-outgoing-foreground' : 'bg-secondary',
            isOwn ? 'ml-auto' : ''
        );
        
        const showAvatar = isLastInGroup && !isOwn;
        
        const renderContent = (content: string) => {
            const regex = /(@[\w_]+)/g;
            const parts = content.split(regex);
            
            return parts.map((part, i) => {
                if (part.match(regex)) {
                    const username = part.substring(1);
                    return (
                        <Link key={i} href={`/profile/${username}`} className="font-semibold text-primary hover:underline">
                            {part}
                        </Link>
                    )
                }
                if (chatSearchQuery && isSearching) {
                    const searchRegex = new RegExp(`(${chatSearchQuery})`, 'gi');
                    return part.split(searchRegex).map((subPart, j) => 
                        subPart.toLowerCase() === chatSearchQuery.toLowerCase() ? 
                        <mark key={j} className="bg-yellow-300/50 rounded-sm" ref={el => el && searchResultsRef.current.push(el)}>{subPart}</mark> : subPart
                    );
                }
                return part;
            });
        };
        
        return (
            <div key={msg.id} className={cn('flex items-end gap-2', isOwn ? 'justify-end' : 'justify-start')}>
                {showAvatar ? <UserAvatar user={msg.sender} className="h-7 w-7"/> : <div className={cn("w-7", !isOwn && 'group-hover:w-7')} /> }
                <div className="flex flex-col gap-1" style={{alignItems: isOwn ? 'flex-end' : 'flex-start'}}>
                    <Popover open={isPopoverOpen} onOpenChange={setIsPopoverOpen}>
                      <PopoverTrigger asChild>
                         <div onPointerDown={handlePointerDown} onPointerUp={handlePointerUp} onContextMenu={(e) => e.preventDefault()} className={bubbleClasses}>
                            {msg.poll ? (
                                <div className="p-3">
                                   <PostPoll poll={msg.poll} postId={msg.id} />
                                </div>
                            ) : msg.voiceMemo ? (
                                <VoiceMessageBubble voiceMemo={msg.voiceMemo} />
                            ) : msg.image && !isFreeMode ? (
                                <Image 
                                    src={msg.image.imageUrl} 
                                    alt="Sent image" 
                                    width={300} 
                                    height={300}
                                    className="rounded-lg object-cover w-full max-w-[300px]"
                                />
                            ) : msg.image && isFreeMode ? (
                                <div className="p-4 flex items-center gap-2 text-muted-foreground"><ImageIcon className="h-4 w-4"/> Image hidden</div>
                            ) : (
                                <p className="break-words">{renderContent(msg.content)}</p>
                            )}
                         </div>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-1 rounded-full">
                        <div className="flex gap-1">
                            <button onClick={() => { handleReaction(msg.id, '❤️'); setIsPopoverOpen(false); }} className="p-2 rounded-full hover:bg-accent">❤️</button>
                            <button onClick={() => { handleReaction(msg.id, '👍'); setIsPopoverOpen(false); }} className="p-2 rounded-full hover:bg-accent">👍</button>
                        </div>
                      </PopoverContent>
                    </Popover>
                    {isLastInGroup && !isOwn && (
                        <p className="text-right text-xs text-muted-foreground/70">{format(msg.timestamp, 'p')}</p>
                    )}
                    {isOwn && (
                        <div className="flex items-center gap-1 justify-end">
                            <p className="text-right text-xs text-muted-foreground/70">{format(msg.timestamp, 'p')}</p>
                            <ReadReceipt status={msg.status} />
                        </div>
                    )}
                </div>
            </div>
        )
    }

  const handleBlock = () => {
    if (!participant) return;
    toast({ variant: 'destructive', title: `Blocked ${participant.name}`, description: "You will no longer receive messages from them." });
  }

  const handleReport = () => {
    if (!participant) return;
    toast({ title: `Reported ${participant.name}`, description: "Thank you for your report." });
  }
  
  const handleChatSearch = (e: React.FormEvent) => {
    e.preventDefault();
    searchResultsRef.current = [];
    setIsSearching(true);
  }

  const handleThemeChange = (theme: ConversationTheme) => {
    const updatedConvo = { ...conversation, theme };
    onUpdateConversation(updatedConvo);
  }

  React.useEffect(() => {
    if(isSearching && searchResultsRef.current.length > 0) {
        setSearchIndex(searchResultsRef.current.length - 1);
        searchResultsRef.current[searchResultsRef.current.length - 1].scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, [isSearching]);

  return (
    <div className={cn("flex h-full flex-col bg-background", conversation.theme?.name || 'theme-default')}>
        <header className="relative flex shrink-0 items-center gap-3 border-b p-4">
            {onBack && (
                <Button variant="ghost" size="icon" onClick={onBack}>
                    <ArrowLeft />
                </Button>
            )}
            <ChatHeader conversation={conversation} participant={participant} currentUser={currentUser} onUpdateConversation={onUpdateConversation} getDisplayName={getDisplayName} />
            <div className="ml-auto flex items-center gap-2">
                {!isGroup && participant && (
                    <>
                        <Link href={`/call?type=audio&userId=${participant.id}&conversationId=${conversation.id}`} passHref>
                            <Button variant="ghost" size="icon">
                                <Phone className="h-6 w-6 text-muted-foreground" />
                            </Button>
                        </Link>
                        {!isFreeMode && <Link href={`/call?type=video&userId=${participant.id}&conversationId=${conversation.id}`} passHref>
                            <Button variant="ghost" size="icon">
                                <Video className="h-6 w-6 text-muted-foreground" />
                            </Button>
                        </Link>}
                    </>
                )}
                 <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                            <Info className="h-6 w-6 text-muted-foreground" />
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                        {isGroup && (
                            <GroupMembersDialog conversation={conversation} onUpdateConversation={onUpdateConversation} currentUser={currentUser} getDisplayName={getDisplayName}>
                                <DropdownMenuItem onSelect={(e) => e.preventDefault()}><Users className="mr-2 h-4 w-4"/> Group Info</DropdownMenuItem>
                            </GroupMembersDialog>
                        )}
                        {!isGroup && participant && (
                            <>
                                <DropdownMenuItem onClick={handleBlock}><ShieldX className="mr-2 h-4 w-4"/> Block</DropdownMenuItem>
                                <DropdownMenuItem onClick={handleReport}><AlertTriangle className="mr-2 h-4 w-4"/> Report</DropdownMenuItem>
                            </>
                        )}
                    </DropdownMenuContent>
                </DropdownMenu>
            </div>
        </header>

        {pinnedMessage && (
            <div className="relative p-2 px-4 border-b bg-secondary flex items-center gap-2 text-sm shrink-0">
                <Pin className="h-4 w-4 shrink-0 text-muted-foreground"/>
                <p className="flex-1 text-muted-foreground truncate">
                    <span className="font-semibold text-foreground">{getDisplayName(pinnedMessage.sender)}:</span> {pinnedMessage.content}
                </p>
                <button onClick={() => handlePinMessage(null)} className="shrink-0"><X className="h-4 w-4 text-muted-foreground"/></button>
            </div>
        )}
       
        <div className="flex-1 overflow-y-auto" ref={scrollAreaRef}>
          <div className="p-4 sm:p-6 flex flex-col gap-1">
            {messageGroups.map((group, index) => renderMessageGroup(group, index))}
            {messages.length === 0 && (
                <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground pt-20 flex-grow">
                    <UserAvatar user={participant!} className="w-24 h-24 mb-4" />
                    <h3 className="font-bold text-xl text-foreground">Start a conversation</h3>
                    <p>with {participant?.name}</p>
                </div>
            )}
          </div>
        </div>

       {isSearching && searchResultsRef.current.length > 0 && (
        <div className="relative border-t p-2 text-sm flex items-center justify-center gap-2 shrink-0">
            <p>{searchIndex + 1} of {searchResultsRef.current.length} results</p>
            <Button size="icon" variant="ghost" className="h-7 w-7"><ArrowDown className="h-4 w-4"/></Button>
        </div>
      )}

        <footer className="relative border-t p-2 sm:p-4 bg-background shrink-0">
            {isRecording && (
                <div className="absolute bottom-full left-0 right-0 p-4 bg-background border-t flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                        <p className="font-mono text-lg">{formatTime(recordingDuration)}</p>
                    </div>
                    <div className="flex items-center gap-2">
                        <Button variant="destructive" onClick={() => handleStopRecording(false)}>
                            <Trash2 className="mr-2 h-4 w-4" /> Delete
                        </Button>
                        <Button onClick={() => handleStopRecording(true)}>
                            <Send className="mr-2 h-4 w-4" /> Send
                        </Button>
                    </div>
                </div>
            )}

            <Popover open={showMentionPopover} onOpenChange={setShowMentionPopover}>
                <PopoverTrigger asChild>
                    <div />
                </PopoverTrigger>
                <PopoverContent className="w-80 p-0" side="top" align="start">
                    <MentionPopover 
                        query={mentionQuery}
                        onSelect={handleMentionSelect}
                        participants={conversation.participants}
                    />
                </PopoverContent>
            </Popover>
            <form onSubmit={handleSendTextOrLike} className="flex items-center gap-2">
                <AttachmentMenu onSendImage={handleSendImage} isFreeMode={isFreeMode}>
                    <Button type="button" variant="ghost" size="icon" className="rounded-full shrink-0"><Paperclip /></Button>
                </AttachmentMenu>
                
                <Button type="button" variant="ghost" size="icon" className="rounded-full shrink-0" onPointerDown={handleStartRecording} onPointerUp={() => handleStopRecording(true)}>
                    <Mic/>
                </Button>

                <div className="relative flex-1">
                    <Input 
                    placeholder="Message..." 
                    className="flex-1 rounded-full bg-secondary border-0 focus-visible:ring-1 pr-10"
                    value={newMessage}
                    onChange={handleInputChange}
                    />
                     <Button type="button" variant="ghost" size="icon" className="rounded-full absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8"><Smile /></Button>
                </div>

                <Button type="submit" variant="ghost" size="icon" className="rounded-full shrink-0">
                    {newMessage ? <Send className="h-6 w-6 text-primary" /> : <ThumbsUp className="h-6 w-6 text-primary" />}
                </Button>
            </form>
        </footer>
    </div>
  );
}

function AttachmentMenu({ children, onSendImage, isFreeMode }: { children: React.ReactNode; onSendImage: () => void; isFreeMode: boolean; }) {
  return (
    <Popover>
        <PopoverTrigger asChild>{children}</PopoverTrigger>
        <PopoverContent side="top" className="w-auto p-2">
            <div className="flex gap-2">
                <Button variant="outline" size="icon" onClick={onSendImage}><ImageIcon/></Button>
                <Button variant="outline" size="icon" disabled={isFreeMode}><FileVideo /></Button>
                <Button variant="outline" size="icon"><BarChart3 /></Button>
            </div>
        </PopoverContent>
    </Popover>
  );
}

function ChatHeader({ conversation, participant, currentUser, onUpdateConversation, getDisplayName }: { conversation: Conversation; participant: User | undefined; currentUser: User; onUpdateConversation: (c: Conversation) => void; getDisplayName: (user: User) => string;}) {
    const isGroup = conversation.type === 'group';
    
    if (isGroup) {
        return (
            <GroupMembersDialog conversation={conversation} onUpdateConversation={onUpdateConversation} currentUser={currentUser} getDisplayName={getDisplayName}>
                <button className="flex items-center gap-3 text-left">
                     {conversation.avatar ? (
                         <Image src={conversation.avatar.imageUrl} alt={conversation.name || 'Group'} width={40} height={40} className="rounded-full h-10 w-10 object-cover" />
                     ) : (
                        <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center"><Users className="h-5 w-5"/></div>
                     )}
                    <div>
                        <p className="font-semibold">{conversation.name}</p>
                        <p className="text-xs text-muted-foreground">{conversation.participants.length} members</p>
                    </div>
                </button>
            </GroupMembersDialog>
        );
    }
    
    if (participant) {
        return (
            <Link href={`/profile/${participant.username}`} className="flex items-center gap-3">
                <UserAvatar user={participant} isOnline={participant.isOnline} />
                <div className="flex-1">
                    <p className="font-semibold">{getDisplayName(participant)}</p>
                    <p className="text-xs text-muted-foreground">{participant.isOnline ? 'Online' : `Active ${formatDistanceToNow(new Date().setHours(new Date().getHours() - 5), { addSuffix: true })}`}</p>
                </div>
            </Link>
        )
    }
    
    return null;
}

function GroupMembersDialog({ conversation, children, onUpdateConversation, currentUser, getDisplayName }: { conversation: Conversation, children: React.ReactNode, onUpdateConversation: (c: Conversation) => void; currentUser: User; getDisplayName: (user: User) => string; }) {
    const [name, setName] = React.useState(conversation.name || '');
    const [isEditingName, setIsEditingName] = React.useState(false);
    const [avatar, setAvatar] = React.useState<File | null>(null);
    const [avatarPreview, setAvatarPreview] = React.useState(conversation.avatar?.imageUrl);
    const avatarInputRef = React.useRef<HTMLInputElement>(null);
    const [isAddMemberOpen, setIsAddMemberOpen] = React.useState(false);
    const [editingNicknameFor, setEditingNicknameFor] = React.useState<User | null>(null);
    const [nickname, setNickname] = React.useState('');

    const { toast } = useToast();
    const isAdmin = conversation.adminIds?.includes(currentUser.id) ?? false;
    
    const handleNameSave = () => {
        onUpdateConversation({ ...conversation, name });
        setIsEditingName(false);
        toast({ title: 'Group name updated!' });
    };
    
    const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setAvatar(file);
            const reader = new FileReader();
            reader.onloadend = () => {
                const result = reader.result as string;
                setAvatarPreview(result);
                onUpdateConversation({ ...conversation, avatar: { ...(conversation.avatar || getImage('album-art-1')), imageUrl: result } });
                toast({ title: 'Group avatar updated!' });
            };
            reader.readAsDataURL(file);
        }
    };
    
    const handleRemoveMember = (memberId: string) => {
        const newParticipants = conversation.participants.filter(p => p.id !== memberId);
        onUpdateConversation({ ...conversation, participants: newParticipants });
        toast({ title: 'Member removed.' });
    };

    const handleAddMembers = (newMembers: User[]) => {
        const updatedParticipants = [...conversation.participants];
        newMembers.forEach(newMember => {
            if (!updatedParticipants.some(p => p.id === newMember.id)) {
                updatedParticipants.push(newMember);
            }
        });
        onUpdateConversation({ ...conversation, participants: updatedParticipants });
        toast({ title: `${newMembers.length} member(s) added.`});
    };

    const openNicknameEditor = (user: User) => {
        setEditingNicknameFor(user);
        setNickname(conversation.nicknames?.[user.id] || '');
    };
    
    const handleSaveNickname = () => {
        if (!editingNicknameFor) return;

        const newNicknames = { ...(conversation.nicknames || {}) };
        if (nickname.trim()) {
            newNicknames[editingNicknameFor.id] = nickname.trim();
        } else {
            delete newNicknames[editingNicknameFor.id];
        }

        onUpdateConversation({ ...conversation, nicknames: newNicknames });
        toast({ title: "Nickname updated!" });
        setEditingNicknameFor(null);
    };

    const mediaMessages = React.useMemo(() => {
        return conversation.messages.filter(m => m.image);
    }, [conversation.messages]);


    return (
        <>
        <Dialog>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent className="max-w-md p-0">
                <Tabs defaultValue="members" className="w-full">
                    <TabsList className="grid w-full grid-cols-2 rounded-b-none">
                        <TabsTrigger value="members">Members</TabsTrigger>
                        <TabsTrigger value="media">Media</TabsTrigger>
                    </TabsList>
                    <TabsContent value="members" className="mt-0">
                        <div className="flex flex-col items-center gap-4 p-6 pt-4">
                            <div className="relative group">
                                <Avatar className="w-24 h-24">
                                    {avatarPreview ? <AvatarImage src={avatarPreview} /> : <AvatarFallback><Users className="w-10 h-10" /></AvatarFallback>}
                                </Avatar>
                                {isAdmin && (
                                    <button onClick={() => avatarInputRef.current?.click()} className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                        <Camera className="w-8 w-8 text-white" />
                                    </button>
                                )}
                                <input type="file" accept="image/*" ref={avatarInputRef} onChange={handleAvatarChange} className="hidden" />
                            </div>
                            {isEditingName ? (
                                <div className="flex items-center gap-2">
                                    <Input value={name} onChange={(e) => setName(e.target.value)} autoFocus onBlur={handleNameSave} onKeyDown={(e) => e.key === 'Enter' && handleNameSave()} />
                                    <Button size="sm" onClick={handleNameSave}>Save</Button>
                                </div>
                            ) : (
                                <DialogTitle className="flex items-center gap-2 text-2xl">
                                    {conversation.name}
                                    {isAdmin && <button onClick={() => setIsEditingName(true)}><Edit className="w-4 h-4 text-muted-foreground" /></button>}
                                </DialogTitle>
                            )}
                            <p className="text-sm text-muted-foreground -mt-3">{conversation.participants.length} Members</p>
                        </div>
                        <ScrollArea className="h-64 px-2">
                            <div className="flex flex-col gap-2 p-2">
                                {isAdmin && (
                                    <Dialog open={isAddMemberOpen} onOpenChange={setIsAddMemberOpen}>
                                        <DialogTrigger asChild>
                                            <Button variant="outline" className="w-full"><UserPlus className="mr-2 h-4 w-4"/> Add Member</Button>
                                        </DialogTrigger>
                                        <DialogContent>
                                            <DialogHeader><DialogTitle>Add Members</DialogTitle></DialogHeader>
                                            <AddMembersDialog currentMembers={conversation.participants} onAddMembers={(newMembers) => {
                                                handleAddMembers(newMembers);
                                                setIsAddMemberOpen(false);
                                            }}/>
                                        </DialogContent>
                                    </Dialog>
                                )}
                                {conversation.participants.map(user => {
                                    const userIsAdmin = conversation.adminIds?.includes(user.id);
                                    const userNickname = getDisplayName(user);
                                    return (
                                        <div key={user.id} className="flex items-center gap-3 p-2 rounded-md hover:bg-accent group">
                                            <Link href={`/profile/${user.username}`}><UserAvatar user={user} isOnline={user.isOnline}/></Link>
                                            <div className="text-left flex-1">
                                                <Link href={`/profile/${user.username}`} className="font-semibold hover:underline flex items-center gap-2">
                                                    {userNickname}
                                                    {userIsAdmin && <Crown className="w-4 h-4 text-amber-500"/>}
                                                </Link>
                                                {userNickname !== user.name && (
                                                    <p className="text-xs text-muted-foreground">{user.name}</p>
                                                )}
                                            </div>
                                            <DropdownMenu>
                                                <DropdownMenuTrigger asChild>
                                                    <Button variant="ghost" size="icon" className="h-8 w-8 opacity-0 group-hover:opacity-100"><MoreVertical className="w-4 h-4" /></Button>
                                                </DropdownMenuTrigger>
                                                <DropdownMenuContent>
                                                    <DropdownMenuItem onSelect={() => openNicknameEditor(user)}>Set Nickname</DropdownMenuItem>
                                                    {isAdmin && user.id !== currentUser.id && (
                                                        <DropdownMenuItem onClick={() => handleRemoveMember(user.id)} className="text-destructive">
                                                            <UserMinus className="mr-2 h-4 w-4"/>Remove from Group
                                                        </DropdownMenuItem>
                                                    )}
                                                </DropdownMenuContent>
                                            </DropdownMenu>
                                        </div>
                                    );
                                })}
                            </div>
                        </ScrollArea>
                    </TabsContent>
                    <TabsContent value="media" className="mt-0">
                         <ScrollArea className="h-[500px]">
                            {mediaMessages.length > 0 ? (
                                <div className="grid grid-cols-3 gap-1 p-2">
                                {mediaMessages.map(msg => (
                                    <div key={msg.id} className="relative aspect-square">
                                        <Image src={msg.image!.imageUrl} alt="Shared media" fill className="object-cover rounded-md"/>
                                    </div>
                                ))}
                                </div>
                            ) : (
                                <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
                                    No media shared yet.
                                </div>
                            )}
                         </ScrollArea>
                    </TabsContent>
                </Tabs>
            </DialogContent>
        </Dialog>
        <Dialog open={!!editingNicknameFor} onOpenChange={(open) => !open && setEditingNicknameFor(null)}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Set Nickname for {editingNicknameFor?.name}</DialogTitle>
                </DialogHeader>
                <Input 
                    value={nickname}
                    onChange={(e) => setNickname(e.target.value)}
                    placeholder={editingNicknameFor?.name}
                    autoFocus
                />
                <DialogFooter>
                    <Button variant="ghost" onClick={() => setEditingNicknameFor(null)}>Cancel</Button>
                    <Button onClick={handleSaveNickname}>Save</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
        </>
    )
}

function AddMembersDialog({ currentMembers, onAddMembers }: { currentMembers: User[], onAddMembers: (newMembers: User[]) => void }) {
    const [selectedUsers, setSelectedUsers] = React.useState<User[]>([]);
    const [allUsers, setAllUsers] = React.useState<User[]>([]);
    const [isLoading, setIsLoading] = React.useState(true);
    const appContext = React.useContext(AppContext);

    React.useEffect(() => {
        getUsers().then(users => {
            setAllUsers(users);
            setIsLoading(false);
        });
    }, []);

    const nonMemberFriends = allUsers.filter(u => u.id !== appContext?.currentUser?.id && !currentMembers.some(cm => cm.id === u.id));

    const handleToggleUser = (user: User) => {
        setSelectedUsers(prev => 
            prev.some(su => su.id === user.id)
                ? prev.filter(su => su.id !== user.id)
                : [...prev, user]
        );
    };

    return (
        <div className="flex flex-col gap-4">
             <ScrollArea className="h-96 mt-4 -mx-4">
                    <div className="flex flex-col gap-2 px-4">
                        {isLoading ? (
                            Array.from({ length: 5 }).map((_, i) => (
                                <div key={i} className="flex items-center gap-3 p-2">
                                    <Skeleton className="h-4 w-4" />
                                    <Skeleton className="h-10 w-10 rounded-full" />
                                    <div className="flex-1 space-y-2">
                                        <Skeleton className="h-4 w-3/4" />
                                        <Skeleton className="h-3 w-1/2" />
                                    </div>
                                </div>
                            ))
                        ) : nonMemberFriends.length > 0 ? (
                            nonMemberFriends.map(user => (
                                <div key={user.id} className="flex items-center gap-3 p-2 rounded-md hover:bg-accent cursor-pointer" onClick={() => handleToggleUser(user)}>
                                    <Checkbox checked={selectedUsers.some(su => su.id === user.id)} />
                                    <label htmlFor={`user-select-${user.id}`} className="flex items-center gap-3 cursor-pointer flex-1">
                                        <UserAvatar user={user} />
                                        <div>
                                            <p className="font-semibold">{user.name}</p>
                                            <p className="text-sm text-muted-foreground">@{user.username}</p>
                                        </div>
                                    </label>
                                </div>
                            ))
                        ) : (
                             <p className="text-center text-muted-foreground py-8">No other users to add.</p>
                        )}
                    </div>
            </ScrollArea>
            <Button onClick={() => onAddMembers(selectedUsers)} disabled={selectedUsers.length === 0}>Add {selectedUsers.length > 0 ? selectedUsers.length : ''} Members</Button>
        </div>
    );
}

function MentionPopover({ query, onSelect, participants }: { query: string, onSelect: (user: User) => void, participants: User[] }) {
  const filteredUsers = participants.filter(
    (user) =>
      user.name.toLowerCase().includes(query.toLowerCase()) ||
      (user.username && user.username.toLowerCase().includes(query.toLowerCase()))
  );
  
  if (filteredUsers.length === 0) {
    return (
      <div className="p-4 text-sm text-center text-muted-foreground">
        No matching members
      </div>
    );
  }

  return (
     <ScrollArea className="h-auto max-h-60">
        <div className="flex flex-col gap-1 p-1">
            {filteredUsers.map(user => (
                <button
                    key={user.id}
                    className="flex items-center gap-3 p-2 rounded-md hover:bg-accent text-left w-full"
                    onClick={() => onSelect(user)}
                >
                    <UserAvatar user={user} className="h-8 w-8" />
                    <div className="flex-1">
                        <p className="font-semibold text-sm">{user.name}</p>
                        <p className="text-xs text-muted-foreground">@{user.username}</p>
                    </div>
                </button>
            ))}
        </div>
    </ScrollArea>
  );
}


function ReadReceipt({ status }: { status: Message['status'] }) {
    if (status === 'sent') {
        return <Check className="h-4 w-4 text-muted-foreground/70" />;
    }
    if (status === 'delivered') {
        return <CheckCheck className="h-4 w-4 text-muted-foreground/70" />;
    }
    if (status === 'read') {
        return <CheckCheck className="h-4 w-4" style={{color: 'hsl(var(--primary))' }} />;
    }
    return null;
}

function NewMessageDialog({ onCreateConversation, children }: { onCreateConversation: (conversation: Conversation) => void, children: React.ReactNode }) {
    const [search, setSearch] = React.useState('');
    const [selectedUsers, setSelectedUsers] = React.useState<User[]>([]);
    const [allUsers, setAllUsers] = React.useState<User[]>([]);
    const [isLoading, setIsLoading] = React.useState(true);
    const appContext = React.useContext(AppContext);
    
    React.useEffect(() => {
        getUsers().then(users => {
            setAllUsers(users);
            setIsLoading(false);
        });
    }, []);

    const currentUser = appContext?.currentUser;

    if (!currentUser) return null;

    const friends = allUsers.filter(u => u.id !== currentUser.id);

    const filteredFriends = friends.filter(friend => 
        friend.name.toLowerCase().includes(search.toLowerCase()) ||
        (friend.username && friend.username.toLowerCase().includes(search.toLowerCase()))
    );

    const handleToggleUser = (user: User) => {
      setSelectedUsers(prev =>
        prev.some(u => u.id === user.id)
          ? prev.filter(u => u.id !== user.id)
          : [...prev, user]
      );
    };

    const handleStartChat = () => {
        if (selectedUsers.length === 0) return;
        
        let newConvo: Conversation;
        if (selectedUsers.length > 1) {
            // Create Group
            newConvo = {
                id: `group-${Date.now()}`,
                type: 'group',
                name: `Group with ${selectedUsers.map(u => u.name.split(' ')[0]).join(', ')}`,
                participants: [currentUser, ...selectedUsers],
                adminIds: [currentUser.id],
                messages: [],
                unreadCount: 0,
            };
        } else {
            // Create Direct Message
            newConvo = {
                id: `dm-${Date.now()}`,
                type: 'direct',
                participants: [currentUser, selectedUsers[0]],
                messages: [],
                unreadCount: 0,
            };
        }
        onCreateConversation(newConvo);
        setSelectedUsers([]);
        setSearch('');
    };

    return (
        <Dialog>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent className="max-w-md">
                <DialogHeader>
                    <DialogTitle>New Message</DialogTitle>
                </DialogHeader>
                 <div className="relative mt-4">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input 
                        placeholder="Search users..." 
                        className="pl-9"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                </div>
                 <ScrollArea className="h-96 mt-4">
                    <div className="flex flex-col gap-2 p-1">
                        {isLoading ? (
                            Array.from({ length: 5 }).map((_, i) => (
                                <div key={i} className="flex items-center gap-3 p-2">
                                    <Skeleton className="h-4 w-4" />
                                    <Skeleton className="h-10 w-10 rounded-full" />
                                    <div className="flex-1 space-y-2">
                                        <Skeleton className="h-4 w-3/4" />
                                        <Skeleton className="h-3 w-1/2" />
                                    </div>
                                </div>
                            ))
                        ) : filteredFriends.length > 0 ? (
                           filteredFriends.map(user => (
                               <div key={user.id} className="flex items-center gap-3 p-2 rounded-md hover:bg-accent" onClick={() => handleToggleUser(user)}>
                                  <Checkbox 
                                    id={`user-select-${user.id}`}
                                    checked={selectedUsers.some(u => u.id === user.id)}
                                  />
                                  <label htmlFor={`user-select-${user.id}`} className="flex items-center gap-3 cursor-pointer flex-1">
                                      <UserAvatar user={user} isOnline={user.isOnline}/>
                                      <div className="text-left">
                                          <p className="font-semibold">{user.name}</p>
                                          <p className="text-sm text-gray-400">@{user.username}</p>
                                      </div>
                                  </label>
                               </div>
                            ))
                        ) : (
                            <div className="text-center text-muted-foreground py-10">
                                <p>No users found.</p>
                            </div>
                        )}
                    </div>
                </ScrollArea>
                <DialogClose asChild>
                    <Button onClick={handleStartChat} disabled={selectedUsers.length === 0}>
                        Start Chat
                    </Button>
                </DialogClose>
            </DialogContent>
        </Dialog>
    )
}

function VoiceMessageBubble({ voiceMemo }: { voiceMemo: VoiceMemo }) {
  const audioRef = React.useRef<HTMLAudioElement>(null);
  const [isPlaying, setIsPlaying] = React.useState(false);
  const [progress, setProgress] = React.useState(0);

  React.useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTimeUpdate = () => {
      setProgress((audio.currentTime / audio.duration) * 100);
    };
    const handleEnded = () => {
      setIsPlaying(false);
      setProgress(0);
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleEnded);
    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('ended', handleEnded);
    };
  }, []);

  const togglePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
    } else {
      audio.play();
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <div className="flex items-center gap-3 w-64 p-2">
      <audio ref={audioRef} src={voiceMemo.src} preload="metadata" />
      <Button variant="ghost" size="icon" className="h-10 w-10 rounded-full shrink-0" onClick={togglePlay}>
        {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
      </Button>
      <div className="flex-1 flex flex-col gap-1.5">
        <div className="w-full bg-muted-foreground/30 h-1 rounded-full">
            <div className="h-full bg-foreground rounded-full" style={{ width: `${progress}%` }} />
        </div>
        <span className="text-xs font-mono text-muted-foreground">{formatTime(voiceMemo.duration)}</span>
      </div>
    </div>
  );
}

function ThemeSelector({ children, onThemeChange, conversation }: { children: React.ReactNode, onThemeChange: (theme: ConversationTheme) => void, conversation: Conversation }) {
    const [isGenerating, setIsGenerating] = React.useState<string | null>(null);

    const handleSelect = async (theme: ConversationTheme) => {
        onThemeChange(theme);
    }


  return (
    <Dialog>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Change Theme</DialogTitle></DialogHeader>
        <ScrollArea className="h-96">
            <div className="grid grid-cols-2 gap-4 p-4">
            {allMockThemes.map(theme => (
                <DialogClose key={theme.name} asChild>
                    <button className="relative aspect-video rounded-lg overflow-hidden group border-2 border-transparent focus:border-primary" onClick={() => handleSelect(theme)}>
                        <Image src={theme.previewImage} alt={theme.name} fill className="object-cover"/>
                        <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                            {isGenerating === theme.name ? (
                                <Loader2 className="h-8 w-8 text-white animate-spin"/>
                            ) : (
                                <p className="text-white font-bold text-lg drop-shadow-md">{theme.displayName}</p>
                            )}
                        </div>
                    </button>
                </DialogClose>
            ))}
            </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
