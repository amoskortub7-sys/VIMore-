
'use client';

import * as React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { notFound, useRouter } from 'next/navigation';
import { ArrowLeft, Music, Play, Video, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { allMockSongs, Post } from '@/lib/data';
import { UserAvatar } from '@/components/user-avatar';
import { getPosts } from '@/services/postService';
import { useToast } from '@/hooks/use-toast';

export default function SoundPage({ params }: { params: { songId: string } }) {
  const router = useRouter();
  const { songId } = params;
  const { toast } = useToast();

  const [postsWithSong, setPostsWithSong] = React.useState<Post[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);

  const song = React.useMemo(() => allMockSongs.find((s) => s.id === songId), [songId]);

  React.useEffect(() => {
    const fetchPosts = async () => {
      setIsLoading(true);
      try {
        const allPosts = await getPosts();
        // This is a client-side filter. In a real app, you'd want to query this.
        // Appwrite query on nested object property is tricky, so client-side is fine for now.
        const filtered = allPosts.filter((post) => post.song?.id === songId && post.video);
        setPostsWithSong(filtered);
      } catch (error) {
        console.error("Failed to fetch posts for sound:", error);
        toast({
          variant: "destructive",
          title: "Could not load videos",
        });
      } finally {
        setIsLoading(false);
      }
    };
    fetchPosts();
  }, [songId, toast]);

  if (!song) {
    return notFound();
  }

  const handleUseSound = () => {
    // In a real app, this would navigate to the video creation page
    // with the selected sound pre-loaded.
    router.push('/create/video');
  };

  return (
    <div className="container mx-auto max-w-4xl py-4 sm:py-6">
      <header className="mb-6 flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft />
        </Button>
        <div className="flex items-center gap-4">
          <div className="relative h-20 w-20 shrink-0">
            <Image
              src={song.album.cover.imageUrl}
              alt={song.album.title}
              fill
              className="rounded-lg object-cover"
            />
          </div>
          <div>
            <h1 className="text-2xl font-bold">{song.title}</h1>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <UserAvatar user={{...song.artist, username: song.artist.name.toLowerCase().replace(' ','')}} className="h-6 w-6" />
              <span>{song.artist.name}</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {postsWithSong.length} videos
            </p>
          </div>
        </div>
      </header>
      
      <Button onClick={handleUseSound} size="lg" className="w-full sm:w-auto">
        <Video className="mr-2 h-5 w-5" /> Use this sound
      </Button>

      <div className="mt-8 grid grid-cols-2 gap-1 sm:grid-cols-3 md:grid-cols-4">
        {isLoading ? (
          <div className="col-span-full flex h-48 items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin" />
          </div>
        ) : postsWithSong.length > 0 ? (
          postsWithSong.map((post) => (
            <Link href="/reels" key={post.id}>
              <div className="relative aspect-[9/16] bg-muted overflow-hidden group">
                {post.video && (
                  <video
                    src={post.video}
                    className="h-full w-full object-cover"
                    muted
                  />
                )}
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <Play className="h-10 w-10 text-white" />
                </div>
                <div className="absolute bottom-2 left-2 flex items-center gap-1 text-white text-xs font-semibold bg-black/30 px-1.5 py-0.5 rounded-full">
                  <Play className="h-3 w-3" />
                  <span>{Math.floor(Math.random() * 1000)}K</span>
                </div>
              </div>
            </Link>
          ))
        ) : (
          <div className="col-span-full flex h-48 items-center justify-center rounded-lg border-2 border-dashed">
            <p className="text-muted-foreground">No videos use this sound yet.</p>
          </div>
        )}
      </div>
    </div>
  );
}
