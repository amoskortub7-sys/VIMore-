
'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function PrivacyPolicyPage() {
  const router = useRouter();

  return (
    <div className="bg-background min-h-screen">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft />
        </Button>
        <h1 className="text-xl font-bold">Privacy Policy</h1>
      </header>
      <main className="container mx-auto max-w-2xl py-6">
        <div className="prose dark:prose-invert">
            <h2>Privacy Policy</h2>
            <p><em>Last updated: January 1, 2026</em></p>
            <p>Welcome to VIMore. Your privacy is critically important to us. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our mobile application and website (collectively, the "Service"). Please read this privacy policy carefully. If you do not agree with the terms of this privacy policy, please do not access the Service.</p>
            
            <h3>1. Information We Collect</h3>
            <p>We may collect information about you in a variety of ways. The information we may collect on the Service includes:</p>
            <h4>Personal Data You Provide</h4>
            <p>Personally identifiable information, such as your name, username, email address, password, and profile information (like your profile picture and bio) that you voluntarily give to us when you register with the Service or when you choose to participate in various activities related to the Service, such as creating posts, sending messages, or entering promotions.</p>
            <h4>Content You Create</h4>
            <p>We collect the content you create and share on VIMore. This includes photos, videos, comments, messages, and the metadata that is provided with the content, such as when and where it was created. This also includes information about the content, such as if the recipient has viewed it.</p>
            <h4>Usage Data</h4>
            <p>Information our servers automatically collect when you access the Service, such as your IP address, your browser type, your operating system, your access times, the pages you have viewed directly before and after accessing the Service, and other diagnostic data. This helps us understand how our Service is being used and how we can improve it.</p>
            <h4>Device and Location Data</h4>
            <p>We may collect information about your computer or mobile device, such as your device ID, model, and manufacturer. If you grant us permission, we may also collect information about your device's location to provide location-based services or content.</p>
            <h4>Information From Third Parties</h4>
            <p>We may receive information about you from third-party services if you choose to link or connect to our Service using them (for example, if you register using a Google or Facebook account). This information will be subject to the privacy settings you have on that third-party service.</p>

            <h3>2. How We Use Your Information</h3>
            <p>Having accurate information about you permits us to offer you a smooth, efficient, and customized experience. Specifically, we may use information collected about you via the Service to:</p>
            <ul>
                <li>Create and manage your account, and personalize your profile.</li>
                <li>Deliver personalized content, recommendations, and advertisements.</li>
                <li>Enable user-to-user communications and interactions.</li>
                <li>Monitor and analyze usage and trends to improve your experience with the Service.</li>
                <li>Notify you of updates to the Service and changes to our policies.</li>
                <li>Prevent fraudulent transactions, monitor against theft, and protect against criminal activity.</li>
                <li>Respond to product and customer service requests and resolve disputes.</li>
                <li>Administer promotions, contests, and surveys.</li>
                <li>Fulfill and manage purchases, orders, payments, and other transactions related to the Service.</li>
                <li>Comply with legal and regulatory requirements.</li>
            </ul>
            
            <h3>3. Sharing of Your Information</h3>
            <p>We may share information we have collected about you in certain situations. Your information may be disclosed as follows:</p>
            <h4>By Law or to Protect Rights</h4>
            <p>If we believe the release of information about you is necessary to respond to legal process, to investigate or remedy potential violations of our policies, or to protect the rights, property, and safety of others, we may share your information as permitted or required by any applicable law, rule, or regulation.</p>
            <h4>Third-Party Service Providers</h4>
            <p>We may share your information with third parties that perform services for us or on our behalf, including payment processing, data analysis, email delivery, hosting services, customer service, and marketing assistance.</p>
            <h4>Other Users and the Public</h4>
            <p>Your public profile, posts, and other content you post will be visible to other users of the Service. This information can be searched by search engines and may be publicly available. Your followers will be able to see your activity, such as which posts you like or comment on.</p>
            <h4>Business Transfers</h4>
            <p>In connection with any merger, sale of company assets, financing, or acquisition of all or a portion of our business to another company, your information may be transferred as part of that transaction.</p>

            <h3>4. Data Security and Retention</h3>
            <p>We use administrative, technical, and physical security measures to help protect your personal information. While we have taken reasonable steps to secure the personal information you provide to us, please be aware that despite our efforts, no security measures are perfect or impenetrable, and no method of data transmission can be guaranteed against any interception or other type of misuse.</p>
            <p>We will only retain your personal data for as long as necessary to fulfill the purposes we collected it for, including for the purposes of satisfying any legal, accounting, or reporting requirements.</p>

            <h3>5. Your Choices About Your Information</h3>
            <p>You have choices regarding the information we collect and how it's used.</p>
             <ul>
                <li><strong>Account Information:</strong> You may at any time review or change the information in your account or terminate your account by logging into your account settings and updating your account, or by contacting us using the contact information provided.</li>
                <li><strong>Communications:</strong> You can opt out of receiving promotional email communications from us by following the unsubscribe instructions in those emails.</li>
                <li><strong>Location Data:</strong> You can prevent us from collecting location data by changing the permissions on your mobile device.</li>
            </ul>

            <h3>6. Policy for Children</h3>
            <p>We do not knowingly solicit information from or market to children under the age of 13. If you become aware of any data we have collected from children under age 13, please contact us using the contact information provided below.</p>

            <h3>7. Contact Us</h3>
            <p>If you have questions or comments about this Privacy Policy, please contact us through our in-app support channels.</p>
        </div>
      </main>
    </div>
  );
}
