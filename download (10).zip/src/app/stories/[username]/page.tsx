
"use client";

import { useRouter } from 'next/navigation';
import * as React from 'react';
import { useToast } from '@/hooks/use-toast';

export default function StoryViewerPage() {
  const router = useRouter();
  const { toast } = useToast();

  React.useEffect(() => {
    // Since mockStories is gone and a live story service isn't implemented,
    // we redirect the user away from this page.
    toast({
        title: "Stories are coming soon!",
        description: "This feature is not yet fully implemented.",
    });
    router.replace('/');
  }, [router, toast]);

  // Render a blank screen during the redirect to prevent any flash of old content.
  return <div className="h-screen w-screen bg-black" />;
}
