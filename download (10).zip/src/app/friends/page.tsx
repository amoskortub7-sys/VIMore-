
'use client';

import * as React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { UserAvatar } from '@/components/user-avatar';
import { Button } from '@/components/ui/button';
import { User, type Conversation } from '@/lib/data';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Search, MessageCircle, ChevronDown, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { VerifiedBadge } from '@/components/verified-badge';
import { getFriendSuggestions, getFollowers, getFollowing, toggleFollow } from '@/services/userService';
import { AppContext } from '@/components/app-shell';

export default function FriendsPage() {
  const { toast } = useToast();
  const appContext = React.useContext(AppContext);
  const [isLoading, setIsLoading] = React.useState(true);

  const [followers, setFollowers] = React.useState<User[]>([]);
  const [friends, setFriends] = React.useState<User[]>([]); // "Friends" means "Following"
  const [suggestions, setSuggestions] = React.useState<User[]>([]);

  const currentUser = appContext?.currentUser;

  React.useEffect(() => {
    const fetchFriendsData = async () => {
      if (!currentUser) return;
      setIsLoading(true);
      try {
        const [userSuggestions, userFollowers, userFollowing] = await Promise.all([
          getFriendSuggestions(currentUser.id),
          getFollowers(currentUser.id),
          getFollowing(currentUser.id)
        ]);

        setSuggestions(userSuggestions);
        setFollowers(userFollowers);
        setFriends(userFollowing);
      } catch (error) {
        console.error("Failed to fetch friends data:", error);
        toast({ variant: 'destructive', title: 'Could not load data' });
      } finally {
        setIsLoading(false);
      }
    }
    fetchFriendsData();
  }, [currentUser, toast]);


  const handleFollowToggle = async (targetUser: User, isFollowing: boolean) => {
    if (!currentUser) return;

    // Store old state for potential revert
    const oldState = { friends: [...friends], followers: [...followers], suggestions: [...suggestions] };

    // Optimistic UI updates
    if (isFollowing) {
      // Unfollow
      setFriends(prev => prev.filter(f => f.id !== targetUser.id));
      if (!followers.some(f => f.id === targetUser.id)) {
        setSuggestions(prev => [targetUser, ...prev]);
      }
      toast({ title: `Unfollowed ${targetUser.name}` });
    } else {
      // Follow
      setSuggestions(prev => prev.filter(s => s.id !== targetUser.id));
      setFollowers(prev => prev.filter(f => f.id !== targetUser.id));
      setFriends(prev => [targetUser, ...prev]);
      toast({ title: `You are now following ${targetUser.name}` });
    }

    try {
      await toggleFollow(currentUser.id, targetUser.id, isFollowing);
    } catch (error) {
      // Revert optimistic updates on failure
      toast({ variant: 'destructive', title: 'Something went wrong', description: 'Please try again.' });
      setFriends(oldState.friends);
      setFollowers(oldState.followers);
      setSuggestions(oldState.suggestions);
    }
  };
  
  if (isLoading || !currentUser) {
      return (
          <div className="flex h-screen items-center justify-center">
              <Loader2 className="h-12 w-12 animate-spin" />
          </div>
      );
  }

  return (
    <div className="container mx-auto max-w-4xl py-4 sm:py-6">
      <header className="mb-6">
        <h1 className="font-headline text-3xl font-bold">Friends</h1>
      </header>
      <Tabs defaultValue="suggestions" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
          <TabsTrigger value="followers">Followers ({followers.length})</TabsTrigger>
          <TabsTrigger value="friends">Following ({friends.length})</TabsTrigger>
        </TabsList>
        <TabsContent value="suggestions" className="mt-6">
          <UserListCard
            users={suggestions}
            onAction={handleFollowToggle}
            title="Suggestions"
            description="People you might know."
            friendsList={friends}
            followersList={followers}
            currentUser={currentUser}
          />
        </TabsContent>
        <TabsContent value="followers" className="mt-6">
          <UserListCard
            users={followers}
            onAction={handleFollowToggle}
            title="Followers"
            description="Users who are following you."
            friendsList={friends}
            followersList={followers}
            currentUser={currentUser}
          />
        </TabsContent>
        <TabsContent value="friends" className="mt-6">
          <UserListCard
            users={friends}
            onAction={handleFollowToggle}
            title="Following"
            description="People you follow."
            friendsList={friends}
            followersList={followers}
            currentUser={currentUser}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}

interface UserListCardProps {
  users: User[];
  onAction: (user: User, isCurrentlyFollowing: boolean) => void;
  title: string;
  description: string;
  friendsList: User[];
  followersList: User[];
  currentUser: User;
}

function UserListCard({ users, onAction, title, description, friendsList, followersList, currentUser }: UserListCardProps) {
  const [searchQuery, setSearchQuery] = React.useState('');
  const router = useRouter();
  const appContext = React.useContext(AppContext);

  const filteredUsers = users.filter(
    (user) =>
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.username.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const handleMessage = (user: User) => {
    if (!currentUser || !appContext) return;
    const { conversations, createConversation } = appContext;

    const existingConvo = conversations.find(c => 
      c.type === 'direct' &&
      c.participants.length === 2 &&
      c.participants.some(p => p.id === user.id) &&
      c.participants.some(p => p.id === currentUser.id)
    );

    if (existingConvo) {
      router.push(`/messages?conversationId=${existingConvo.id}`);
    } else {
      const newConvo: Conversation = {
        id: `dm-${Date.now()}`,
        type: 'direct',
        participants: [currentUser, user],
        messages: [],
        unreadCount: 0,
      };
      createConversation(newConvo);
    }
  };

  const getButton = (user: User) => {
    if (user.id === currentUser.id) return null;
    
    const isFollowing = friendsList.some(friend => friend.id === user.id);
    const isFollower = followersList.some(follower => follower.id === user.id);

    if (isFollowing) {
      return (
        <div className="flex items-center gap-2">
            <DropdownMenu>
                <DropdownMenuTrigger asChild>
                    <Button size="sm" variant="outline">Following <ChevronDown className="h-4 w-4 ml-1"/></Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                    <DropdownMenuItem onSelect={() => onAction(user, true)}>Unfollow</DropdownMenuItem>
                </DropdownMenuContent>
            </DropdownMenu>
            <Button size="sm" variant="ghost" className="px-2" onClick={() => handleMessage(user)}>
                <MessageCircle className="h-5 w-5 text-muted-foreground" />
            </Button>
        </div>
      );
    }
    
    if (isFollower) {
        return <Button size="sm" onClick={() => onAction(user, false)}>Follow Back</Button>;
    }
    
    return <Button size="sm" onClick={() => onAction(user, false)}>Follow</Button>;
  }

  return (
    <Card>
      <CardContent className="p-4 sm:p-6">
        <div className="mb-4">
            <h2 className="text-xl font-bold">{title}</h2>
            <p className="text-sm text-muted-foreground">{description}</p>
        </div>
        <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
                placeholder="Search..." 
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
            />
        </div>
        <ScrollArea className="h-[60vh]">
          <div className="flex flex-col gap-4 pr-4">
            {filteredUsers.length > 0 ? (
                filteredUsers.map((user) => (
                    <div key={user.id} className="flex items-center gap-4">
                        <Link href={`/profile/${user.username}`}>
                            <UserAvatar user={user} className="h-12 w-12" />
                        </Link>
                        <div className="flex-1">
                            <Link href={`/profile/${user.username}`} className="hover:underline inline-flex items-center">
                                <p className="font-semibold">{user.name}</p>
                                <VerifiedBadge user={user} />
                            </Link>
                            <p className="text-sm text-muted-foreground">@{user.username}</p>
                        </div>
                        {getButton(user)}
                    </div>
                ))
            ) : (
                <div className="text-center text-muted-foreground py-10">
                    <p>No users found.</p>
                </div>
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
