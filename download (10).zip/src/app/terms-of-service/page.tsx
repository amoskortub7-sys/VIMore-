
'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function TermsOfServicePage() {
  const router = useRouter();

  return (
    <div className="bg-background min-h-screen">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft />
        </Button>
        <h1 className="text-xl font-bold">Terms of Service</h1>
      </header>
      <main className="container mx-auto max-w-2xl py-6">
        <div className="prose dark:prose-invert">
            <h2>Terms of Service</h2>
            <p><em>Last updated: January 1, 2026</em></p>
            <p>Welcome to VIMore! These Terms of Service ("Terms") govern your access to and use of our services, including our application, websites, APIs, and any other products or services we offer (collectively, the "Service"). By creating an account or using VIMore, you agree to be bound by these Terms.</p>
            
            <h3>1. The VIMore Service</h3>
            <p>We agree to provide you with the VIMore Service. The Service includes all of the VIMore products, features, applications, services, technologies, and software that we provide to advance VIMore's mission: To bring you closer to the people and things you love. The Service is made up of the following aspects:</p>
            <ul>
                <li><strong>A Platform for Connection:</strong> We provide a platform for you to connect with friends, family, and other users, sharing content and experiences that matter to you.</li>
                <li><strong>Personalized Experience:</strong> Your experience on VIMore is unique to you. We use the data we have to personalize the content, features, and ads you see.</li>
                <li><strong>Tools for Creation:</strong> We provide a range of tools and features to help you create and share engaging content, from photos and videos to interactive polls.</li>
                <li><strong>A Safe Environment:</strong> We work diligently to maintain a safe and positive community by enforcing our Community Guidelines and developing tools to combat abuse and misuse of our Service.</li>
            </ul>

            <h3>2. Your Commitments</h3>
            <p>In return for our commitment to provide the Service, we require you to make the below commitments to us.</p>
            <h4>Who can use VIMore</h4>
            <ul>
              <li>You must be at least 13 years old (or the minimum legal age in your country to use our products).</li>
              <li>You must not be prohibited from receiving any aspect of our Service under applicable laws or engaging in payments related Services if you are on an applicable denied party listing.</li>
              <li>Your account must not have been previously disabled by us for violation of law or any of our policies.</li>
              <li>You must not be a convicted sex offender.</li>
            </ul>
            <h4>How you can't use VIMore</h4>
            <p>Providing a safe and open Service for a broad community requires that we all do our part. You agree that you will not:</p>
            <ul>
              <li>Do anything unlawful, misleading, or fraudulent or for an illegal or unauthorized purpose.</li>
              <li>Violate (or help or encourage others to violate) these Terms or our policies, including our Community Guidelines.</li>
              <li>Do anything to interfere with or impair the intended operation of the Service. This includes misusing any reporting, dispute, or appeals channel, such as by making fraudulent or groundless reports or appeals.</li>
              <li>Attempt to create accounts or access or collect information in unauthorized ways. This includes creating accounts or collecting information in an automated way without our express permission.</li>
              <li>Sell, license, or purchase any account or data obtained from us or our Service.</li>
              <li>Post someone else's private or confidential information without permission or do anything that violates someone else's rights, including intellectual property rights (e.g., copyright infringement, trademark infringement, counterfeit, or pirated goods).</li>
              <li>Modify, translate, create derivative works of, or reverse engineer our products or their components.</li>
            </ul>
            <h4>Permissions You Give to Us</h4>
            <p>We do not claim ownership of your content, but you grant us a license to use it. Your rights to your content are not changing. When you share, post, or upload content that is covered by intellectual property rights (like photos or videos) on or in connection with our Service, you hereby grant to us a non-exclusive, royalty-free, transferable, sub-licensable, worldwide license to host, use, distribute, modify, run, copy, publicly perform or display, translate, and create derivative works of your content (consistent with your privacy and application settings). This license will end when your content is deleted from our systems.</p>
            
            <h3>3. Content Removal and Disabling or Terminating Your Account</h3>
            <p>We can remove any content or information you share on the Service if we believe that it violates these Terms, our policies (including our Community Guidelines), or we are permitted or required to do so by law. We can refuse to provide or stop providing all or part of the Service to you (including terminating or disabling your account) immediately to protect our community or services, or if you create risk or legal exposure for us, violate these Terms of Use or our policies, if you repeatedly infringe other people's intellectual property rights, or where we are permitted or required to do so by law.</p>

            <h3>4. Limitation of Liability</h3>
            <p>Our Service is provided "as is," and we can't guarantee it will be safe and secure or will work perfectly all the time. TO THE EXTENT PERMITTED BY LAW, WE ALSO DISCLAIM ALL WARRANTIES, WHETHER EXPRESS OR IMPLIED, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND NON-INFRINGEMENT.</p>
            <p>We do not control what people and others do or say, and we aren’t responsible for their (or your) actions or conduct (whether online or offline) or content (including unlawful or objectionable content). Our liability shall be limited to the fullest extent permitted by applicable law, and under no circumstance will we be liable to you for any lost profits, revenues, information, or data, or consequential, special, indirect, exemplary, punitive, or incidental damages arising out of or related to these Terms, even if we have been advised of the possibility of such damages.</p>

             <h3>5. General Provisions</h3>
            <p>These Terms constitute the entire agreement between you and VIMore regarding your use of our Service. If any portion of these Terms is found to be unenforceable, the remaining portion will remain in full force and effect. Our failure to enforce any of these Terms will not be considered a waiver. Any amendment to or waiver of these Terms must be made in writing and signed by us. You will not transfer any of your rights or obligations under these Terms to anyone else without our consent.</p>
        </div>
      </main>
    </div>
  );
}
