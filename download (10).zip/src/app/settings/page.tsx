
'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import {
  ArrowLeft, User, Wallet, Shield, Bell, Lock, Eye, Download, Info, HelpCircle, ChevronRight,
  Camera, Pencil, Check, Loader2, QrCode, Smartphone, Users2, UserX, Globe, CreditCard, Trash2,
  PlusCircle, Monitor, Sun, Moon, LogOut, Send, FileText, Languages
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import type { User as UserType, Transaction as TransactionType, SupportTicket as SupportTicketType } from '@/lib/data';
import { formatNumber } from '@/lib/utils';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { useToast } from '@/hooks/use-toast';
import { EditProfileWrapper } from '@/app/profile/[username]/page';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger, DialogClose } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp"
import { UserAvatar } from '@/components/user-avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { format } from 'date-fns';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useTheme } from 'next-themes';
import Link from 'next/link';
import { Textarea } from '@/components/ui/textarea';
import { createSupportTicket } from '@/services/supportService';
import { getTransactions } from '@/services/monetizationService';
import { AppContext } from '@/components/app-shell';
import { subscribeToCreator } from '@/services/monetizationService';
import { getUser, updateUser, toggleBlock, getBlockedUsers } from '@/services/userService';
import { useLocale, useTranslations } from 'next-intl';
import { usePathname } from 'next/navigation';
import { languages, countries } from '@/lib/countries-languages';
import { account } from '@/lib/appwrite';


export default function SettingsPage() {
  const router = useRouter();
  const appContext = React.useContext(AppContext);
  const { toast } = useToast();
  const t = useTranslations('SettingsPage');

  
  if (!appContext || !appContext.currentUser) return <div className="flex h-screen items-center justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>;

  const { currentUser, setCurrentUser } = appContext;

  
  const [notificationSwitches, setNotificationSwitches] = React.useState({
    push: true,
    likes: true,
    comments: true,
    newFollowers: true,
    email: false,
    weeklySummary: false,
    securityAlerts: true,
  });

  const [privacySettings, setPrivacySettings] = React.useState({
    privateAccount: false,
    commentPrivacy: 'everyone',
    tagPrivacy: 'everyone',
  });

  const [securitySettings, setSecuritySettings] = React.useState({
    twoFactorEnabled: false,
  });

  const handleSwitchChange = (category: 'notifications' | 'privacy', key: string, checked: boolean) => {
    const setter = category === 'notifications' ? setNotificationSwitches : setPrivacySettings;
    const label = key.replace(/([A-Z])/g, ' $1').replace(/^./, (str) => str.toUpperCase());
    
    setter((prev: any) => ({ ...prev, [key]: checked }));
    toast({
        title: `${label}`,
        description: `Successfully turned ${checked ? 'on' : 'off'}.`
    });
  }

  const handleAction = (title: string, description: string) => {
    toast({ title, description });
  }

  const handleProfileUpdate = async (updatedData: Partial<UserType>, avatarFile?: File | null, coverFile?: File | null) => {
    try {
      await updateUser(currentUser.id, updatedData, avatarFile, coverFile);
      
      const updatedUser = await getUser(currentUser.id);
      if(updatedUser) {
        setCurrentUser(updatedUser);
      }
      
      toast({ title: 'Profile Updated', description: 'Your changes have been saved.' });
    } catch (error) {
        toast({ variant: 'destructive', title: 'Update Failed', description: 'Could not save your changes.' });
    }
  };
  
  const handleUsernameUpdate = async (newUsername: string) => {
    const updatedUser = { ...currentUser, username: newUsername };
    await updateUser(currentUser.id, { username: newUsername });
    setCurrentUser(updatedUser);
  }

  const handleLogout = () => {
    toast({ title: 'Logged Out', description: 'You have been successfully logged out.' });
    router.push('/');
  }

  return (
    <div className="bg-background min-h-screen">
       <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft />
        </Button>
        <h1 className="text-xl font-bold">{t('title')}</h1>
      </header>
      <main className="container mx-auto max-w-2xl py-6">
        <Accordion type="multiple" defaultValue={['account', 'security']} className="w-full">
            <SettingsAccordionItem value="account" title={t('account')} icon={User}>
                <EditProfileWrapper user={currentUser} onProfileUpdate={handleProfileUpdate}>
                  <SettingsLink>{t('editProfile')}</SettingsLink>
                </EditProfileWrapper>
                <ChangeUsernameDialog username={currentUser.username} onUsernameUpdate={handleUsernameUpdate}>
                    <SettingsLink>{t('changeUsername')}</SettingsLink>
                </ChangeUsernameDialog>
                <ManageSubscriptionsDialog user={currentUser} onUserUpdate={setCurrentUser}>
                  <SettingsLink>{t('manageSubscriptions')}</SettingsLink>
                </ManageSubscriptionsDialog>
                 <LanguageRegionDialog>
                    <SettingsLink>{t('languageAndRegion')}</SettingsLink>
                 </LanguageRegionDialog>
                 <LinkedAccountsDialog>
                    <SettingsLink>Linked Accounts</SettingsLink>
                </LinkedAccountsDialog>
            </SettingsAccordionItem>

            <SettingsAccordionItem value="wallet" title={t('wallet')} icon={Wallet}>
                <div className="p-4 space-y-2">
                    <div className="flex justify-between items-center">
                        <span className="font-semibold">{t('goldBalance')}</span>
                        <span className="font-bold text-lg flex items-center gap-1">🪙 {formatNumber(currentUser.gold)}</span>
                    </div>
                     <div className="flex justify-between items-center">
                        <span className="font-semibold">{t('diamondBalance')}</span>
                        <span className="font-bold text-lg flex items-center gap-1">💎 {formatNumber(currentUser.diamonds)}</span>
                    </div>
                </div>
                <TransactionHistoryDialog userId={currentUser.id}>
                  <SettingsLink>{t('transactionHistory')}</SettingsLink>
                </TransactionHistoryDialog>
                <ManagePaymentMethodsDialog>
                  <SettingsLink>{t('managePayments')}</SettingsLink>
                </ManagePaymentMethodsDialog>
            </SettingsAccordionItem>

            <SettingsAccordionItem value="security" title={t('security')} icon={Shield}>
                <ChangePasswordDialog>
                  <SettingsLink>{t('changePassword')}</SettingsLink>
                </ChangePasswordDialog>
                 <TwoFactorAuthDialog 
                    isEnabled={securitySettings.twoFactorEnabled} 
                    onToggle={(enabled) => setSecuritySettings(prev => ({ ...prev, twoFactorEnabled: enabled }))}
                 />
                <LoginActivityDialog>
                    <SettingsLink>{t('loginActivity')}</SettingsLink>
                </LoginActivityDialog>
                <DataManagementDialog
                    title="Delete Your Account"
                    description="This will permanently delete your account, posts, and all associated data. This action is irreversible. Are you sure you want to continue?"
                    actionText="Yes, Delete My Account"
                    onConfirm={() => handleAction('Account Deleted', 'Your account has been scheduled for deletion.')}
                    isDestructive
                 >
                    <SettingsLink>Delete Account</SettingsLink>
                </DataManagementDialog>
            </SettingsAccordionItem>
            
            <SettingsAccordionItem value="notifications" title={t('notifications')} icon={Bell}>
                <SettingsSwitch 
                    label={t('push')} 
                    checked={notificationSwitches.push} 
                    onCheckedChange={(checked) => handleSwitchChange('notifications', 'push', checked)}
                />
                <SettingsSwitch 
                    label={t('likes')}
                    checked={notificationSwitches.likes} 
                    onCheckedChange={(checked) => handleSwitchChange('notifications', 'likes', checked)} 
                    className="ml-8" 
                />
                <SettingsSwitch 
                    label={t('comments')}
                    checked={notificationSwitches.comments} 
                    onCheckedChange={(checked) => handleSwitchChange('notifications', 'comments', checked)} 
                    className="ml-8" 
                />
                <SettingsSwitch 
                    label={t('newFollowers')}
                    checked={notificationSwitches.newFollowers} 
                    onCheckedChange={(checked) => handleSwitchChange('notifications', 'newFollowers', checked)} 
                    className="ml-8" 
                />
                <Separator className="my-2" />
                <SettingsSwitch 
                    label={t('email')}
                    checked={notificationSwitches.email} 
                    onCheckedChange={(checked) => handleSwitchChange('notifications', 'email', checked)} 
                />
                <SettingsSwitch 
                    label={t('weeklySummary')}
                    checked={notificationSwitches.weeklySummary} 
                    onCheckedChange={(checked) => handleSwitchChange('notifications', 'weeklySummary', checked)} 
                    className="ml-8" 
                />
                <SettingsSwitch 
                    label={t('securityAlerts')}
                    checked={notificationSwitches.securityAlerts} 
                    onCheckedChange={(checked) => handleSwitchChange('notifications', 'securityAlerts', checked)} 
                    className="ml-8" 
                />
            </SettingsAccordionItem>

             <SettingsAccordionItem value="privacy" title={t('privacy')} icon={Lock}>
                <SettingsSwitch 
                  label={t('privateAccount')}
                  checked={privacySettings.privateAccount}
                  onCheckedChange={(checked) => handleSwitchChange('privacy', 'privateAccount', checked)}
                />
                <PrivacyControlDialog
                    title={t('whoCanComment')}
                    currentValue={privacySettings.commentPrivacy as PrivacySetting}
                    onSave={(value) => setPrivacySettings(prev => ({...prev, commentPrivacy: value}))}
                >
                    <SettingsLink>{t('whoCanComment')}</SettingsLink>
                </PrivacyControlDialog>
                <PrivacyControlDialog
                    title={t('whoCanTag')}
                    currentValue={privacySettings.tagPrivacy as PrivacySetting}
                    onSave={(value) => setPrivacySettings(prev => ({...prev, tagPrivacy: value}))}
                >
                    <SettingsLink>{t('whoCanTag')}</SettingsLink>
                </PrivacyControlDialog>
                <BlockedAccountsDialog currentUser={currentUser}>
                    <SettingsLink>{t('blockedAccounts')}</SettingsLink>
                </BlockedAccountsDialog>
            </SettingsAccordionItem>
            
             <SettingsAccordionItem value="display" title={t('display')} icon={Eye}>
                <ThemeSelectorDialog>
                  <SettingsLink>{t('theme')}</SettingsLink>
                </ThemeSelectorDialog>
            </SettingsAccordionItem>

            <SettingsAccordionItem value="data" title={t('data')} icon={Download}>
                 <DataManagementDialog
                    title={t('downloadData')}
                    description="We'll send a copy of your photos, posts, and account information to your registered email address. This process may take a few hours."
                    actionText="Request My Data"
                    onConfirm={() => handleAction('Download Request Sent', 'You will receive an email with your data soon.')}
                 >
                    <SettingsLink>{t('downloadData')}</SettingsLink>
                 </DataManagementDialog>
                 <DataManagementDialog
                    title={t('clearCache')}
                    description="This will clear locally stored data from your device. This may log you out and reset some of your preferences. This action cannot be undone."
                    actionText="Clear Cache Now"
                    onConfirm={() => handleAction('Cache Cleared', 'The local application cache has been cleared.')}
                    isDestructive
                 >
                    <SettingsLink>{t('clearCache')}</SettingsLink>
                 </DataManagementDialog>
            </SettingsAccordionItem>
            
            <SettingsAccordionItem value="help" title={t('help')} icon={HelpCircle}>
                 <Link href="/features">
                   <SettingsLink>How It Works</SettingsLink>
                 </Link>
                 <Link href="/help">
                   <SettingsLink>{t('helpCenter')}</SettingsLink>
                 </Link>
                 <ContactSupportDialog user={currentUser}>
                    <SettingsLink>{t('contactSupport')}</SettingsLink>
                 </ContactSupportDialog>
            </SettingsAccordionItem>

             <SettingsAccordionItem value="about" title={t('about')} icon={Info}>
                 <Link href="/privacy-policy"><SettingsLink>{t('privacyPolicy')}</SettingsLink></Link>
                 <Link href="/terms-of-service"><SettingsLink>{t('termsOfService')}</SettingsLink></Link>
                 <Link href="/community-guidelines"><SettingsLink>{t('communityGuidelines')}</SettingsLink></Link>
                 <div className="p-2">
                    <Button variant="destructive" className="w-full" onClick={handleLogout}><LogOut className="mr-2 h-4 w-4"/>{t('logout')}</Button>
                 </div>
            </SettingsAccordionItem>

        </Accordion>
      </main>
    </div>
  );
}

function SettingsAccordionItem({ value, title, icon: Icon, children }: { value: string, title: string, icon: React.ElementType, children: React.ReactNode }) {
    return (
        <AccordionItem value={value}>
            <AccordionTrigger className="text-lg">
                <div className="flex items-center gap-3">
                    <Icon className="h-5 w-5" />
                    <span>{title}</span>
                </div>
            </AccordionTrigger>
            <AccordionContent>
                <div className="flex flex-col">
                    {children}
                </div>
            </AccordionContent>
        </AccordionItem>
    )
}

function SettingsLink({ children, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
    return (
        <button className="flex items-center justify-between p-4 -m-2 rounded-lg hover:bg-accent w-full text-left" {...props}>
            <span className="font-medium">{children}</span>
            <ChevronRight className="h-5 w-5 text-muted-foreground" />
        </button>
    )
}


function SettingsSwitch({ label, checked, onCheckedChange, className, ...props }: { label: string; checked: boolean; onCheckedChange: (checked: boolean) => void; className?: string } & React.ComponentProps<'div'>) {
    const id = `switch-${label.replace(/\s+/g, '-')}`;

    return (
        <div className={`flex items-center justify-between p-4 -m-2 rounded-lg hover:bg-accent ${className}`} {...props}>
            <label htmlFor={id} className="font-medium pr-4 cursor-pointer">{label}</label>
            <Switch
                id={id}
                checked={checked}
                onCheckedChange={onCheckedChange}
            />
        </div>
    );
}

// --- Dialog Components ---

function ChangeUsernameDialog({ username, children, onUsernameUpdate }: { username: string, children: React.ReactNode, onUsernameUpdate: (newUsername: string) => void }) {
    const { toast } = useToast();
    const [newUsername, setNewUsername] = React.useState(username);
    const [isLoading, setIsLoading] = React.useState(false);
    const [isOpen, setIsOpen] = React.useState(false);

    const handleSave = () => {
        if (newUsername.length < 3) {
            toast({ variant: 'destructive', title: 'Username must be at least 3 characters.' });
            return;
        }
        if (newUsername === username) {
             setIsOpen(false);
             return;
        }

        setIsLoading(true);
        setTimeout(async () => {
            // Simulate checking if username is taken
            const userExists = await getUser(newUsername, 'username');
            setIsLoading(false);
            if(userExists) {
                toast({ variant: 'destructive', title: 'Username is already taken.' });
            } else {
                onUsernameUpdate(newUsername);
                toast({ title: 'Username changed successfully!' });
                setIsOpen(false);
            }
        }, 1000);
    }
    
    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Change Username</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                    <div className="space-y-2">
                        <Label htmlFor="newUsername">New Username</Label>
                        <Input id="newUsername" value={newUsername} onChange={e => setNewUsername(e.target.value.toLowerCase())} />
                         <p className="text-xs text-muted-foreground">Your profile will be available at /profile/{newUsername}</p>
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => setIsOpen(false)}>Cancel</Button>
                    <Button onClick={handleSave} disabled={isLoading || !newUsername}>
                        {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin"/>}
                        Save
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

function ChangePasswordDialog({ children }: { children: React.ReactNode }) {
    const { toast } = useToast();
    const [currentPassword, setCurrentPassword] = React.useState('');
    const [newPassword, setNewPassword] = React.useState('');
    const [confirmPassword, setConfirmPassword] = React.useState('');
    const [isLoading, setIsLoading] = React.useState(false);
    const [isOpen, setIsOpen] = React.useState(false);

    const handleSave = () => {
        if (newPassword !== confirmPassword) {
            toast({ variant: 'destructive', title: 'Passwords do not match.' });
            return;
        }
        if (newPassword.length < 8) {
            toast({ variant: 'destructive', title: 'Password must be at least 8 characters long.'});
            return;
        }
        
        setIsLoading(true);
        setTimeout(() => {
            setIsLoading(false);
            toast({ title: 'Password Changed Successfully!' });
            setIsOpen(false);
            setCurrentPassword('');
            setNewPassword('');
            setConfirmPassword('');
        }, 1500);
    }
    
    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Change Password</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                    <div className="space-y-2">
                        <Label htmlFor="currentPassword">Current Password</Label>
                        <Input id="currentPassword" type="password" value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="newPassword">New Password</Label>
                        <Input id="newPassword" type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="confirmPassword">Confirm New Password</Label>
                        <Input id="confirmPassword" type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} />
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => setIsOpen(false)}>Cancel</Button>
                    <Button onClick={handleSave} disabled={isLoading || !currentPassword || !newPassword || !confirmPassword}>
                        {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin"/>}
                        Change Password
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

function LoginActivityDialog({ children }: { children: React.ReactNode }) {
  const { toast } = useToast();
  const [sessions, setSessions] = React.useState<any[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const [isOpen, setIsOpen] = React.useState(false);

  React.useEffect(() => {
    if (isOpen) {
      setIsLoading(true);
      account.listSessions()
        .then(response => setSessions(response.sessions))
        .catch(() => toast({ variant: 'destructive', title: 'Could not fetch sessions' }))
        .finally(() => setIsLoading(false));
    }
  }, [isOpen, toast]);
  
  const handleLogout = (sessionId: string) => {
    account.deleteSession(sessionId).then(() => {
      setSessions(prev => prev.filter(s => s.$id !== sessionId));
      toast({ title: 'Device Logged Out', description: 'The selected session has been terminated.' });
    });
  };

  const handleLogoutAll = () => {
    account.deleteSessions().then(() => {
      toast({ title: 'Logged Out Everywhere', description: 'You have been logged out of all other sessions. Please log in again.' });
      setIsOpen(false);
      // Optional: force a page reload or redirect to login
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Login Activity</DialogTitle>
          <DialogDescription>
            This is a list of devices that have logged into your account. Remove any you don't recognize.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4 max-h-96 overflow-y-auto">
          {isLoading ? <Loader2 className="mx-auto animate-spin" /> : (
            sessions.map(session => (
              <div key={session.$id} className="flex items-center">
                <Smartphone className="h-6 w-6 mr-4 text-muted-foreground" />
                <div className="flex-1">
                  <p className="font-semibold">{session.osName} on {session.deviceName || session.deviceBrand}</p>
                  <p className="text-sm text-muted-foreground">{session.countryName} • {session.current ? 'Active now' : format(new Date(session.$createdAt), 'PPp')}</p>
                </div>
                {!session.current && (
                  <Button variant="ghost" onClick={() => handleLogout(session.$id)}>Log out</Button>
                )}
              </div>
            ))
          )}
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button variant="destructive" onClick={handleLogoutAll}>Log Out From Other Devices</Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function TwoFactorAuthDialog({ isEnabled, onToggle }: { isEnabled: boolean, onToggle: (enabled: boolean) => void }) {
    const [step, setStep] = React.useState(1);
    const [verificationCode, setVerificationCode] = React.useState('');
    const { toast } = useToast();
    const mockAuthCode = "123456"; // For simulation
    const [isOpen, setIsOpen] = React.useState(false);

    const handleVerify = () => {
        if (verificationCode === mockAuthCode) {
            onToggle(true);
            toast({ title: 'Two-Factor Authentication Enabled!' });
            setIsOpen(false);
        } else {
            toast({ variant: 'destructive', title: 'Invalid verification code.' });
        }
    }
    
    const renderContent = () => {
        if (isEnabled) {
            return (
                <div className="text-center py-4">
                     <p className="text-green-600 font-semibold mb-4 flex items-center justify-center gap-2"><Check className="h-5 w-5"/>Two-Factor Authentication is active.</p>
                     <Button variant="destructive" onClick={() => {onToggle(false); setIsOpen(false)}}>Disable 2FA</Button>
                </div>
            )
        }

        switch (step) {
            case 1:
                return (
                    <div className="text-center py-4 space-y-4">
                        <p>Scan this QR code with your authenticator app (e.g., Google Authenticator) and enter the code below.</p>
                        <div className="p-4 bg-white inline-block rounded-lg">
                           <QrCode className="h-40 w-40"/>
                        </div>
                        <p className="text-xs text-muted-foreground">Or manually enter the setup key.</p>
                        <Button onClick={() => setStep(2)}>Scanned, Continue</Button>
                    </div>
                )
            case 2:
                return (
                    <div className="py-4 space-y-4 flex flex-col items-center">
                        <p>Enter the 6-digit code from your authenticator app to complete setup.</p>
                        <InputOTP maxLength={6} value={verificationCode} onChange={setVerificationCode}>
                            <InputOTPGroup>
                                <InputOTPSlot index={0} />
                                <InputOTPSlot index={1} />
                                <InputOTPSlot index={2} />
                                <InputOTPSlot index={3} />
                                <InputOTPSlot index={4} />
                                <InputOTPSlot index={5} />
                            </InputOTPGroup>
                        </InputOTP>
                        <p className="text-xs text-muted-foreground">For testing, the code is {mockAuthCode}.</p>
                        <Button onClick={handleVerify} disabled={verificationCode.length < 6}>Verify &amp; Enable</Button>
                    </div>
                )
            default:
                return null;
        }
    }

    return (
        <Dialog open={isOpen} onOpenChange={(open) => { setIsOpen(open); if(!open) setStep(1); }}>
            <DialogTrigger asChild>
                <div className="flex items-center justify-between p-4 -m-2 rounded-lg hover:bg-accent cursor-pointer" onClick={() => setIsOpen(true)}>
                    <span className="font-medium">Two-Factor Authentication</span>
                    <Switch
                        checked={isEnabled}
                        readOnly
                    />
                </div>
            </DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Two-Factor Authentication</DialogTitle>
                </DialogHeader>
                {renderContent()}
            </DialogContent>
        </Dialog>
    )
}

function ManageSubscriptionsDialog({ user, onUserUpdate, children }: { user: UserType, children: React.ReactNode }) {
    const { toast } = useToast();
    const subscriptionIds = user.subscriptions || [];
    const [subscribedToUsers, setSubscribedToUsers] = React.useState<UserType[]>([]);
    const [isLoading, setIsLoading] = React.useState(false);
    const [isOpen, setIsOpen] = React.useState(false);

    React.useEffect(() => {
        if (!isOpen || subscriptionIds.length === 0) {
            setSubscribedToUsers([]);
            return;
        }
        const fetchCreators = async () => {
            setIsLoading(true);
            try {
                const creators = await Promise.all(subscriptionIds.map(id => getUser(id)));
                setSubscribedToUsers(creators.filter(Boolean) as UserType[]);
            } catch (e) {
                toast({ variant: 'destructive', title: 'Could not load subscriptions.' });
            } finally {
                setIsLoading(false);
            }
        };
        fetchCreators();
    }, [isOpen, user.subscriptions, toast]);

    const handleCancel = async (userId: string) => {
        try {
            const result = await subscribeToCreator(user.id, userId, true);
            if (result.success) {
                const updatedSubs = (user.subscriptions || []).filter(id => id !== userId);
                onUserUpdate({ ...user, subscriptions: updatedSubs });
                toast({ title: result.message });
            } else {
                toast({ variant: 'destructive', title: 'Failed to cancel subscription' });
            }
        } catch (e) {
            toast({ variant: 'destructive', title: 'An error occurred.' });
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Manage Subscriptions</DialogTitle>
                    <DialogDescription>
                        You are currently subscribed to {subscriptionIds.length} creator(s).
                    </DialogDescription>
                </DialogHeader>
                <ScrollArea className="h-96 -mx-6">
                    <div className="px-6 space-y-4">
                        {isLoading ? (
                            <Loader2 className="mx-auto animate-spin" />
                        ) : subscribedToUsers.length > 0 ? (
                            subscribedToUsers.map(subUser => (
                                <div key={subUser.id} className="flex items-center">
                                    <UserAvatar user={subUser} className="h-10 w-10 mr-4"/>
                                    <div className="flex-1">
                                        <p className="font-semibold">{subUser.name}</p>
                                        <p className="text-sm text-muted-foreground">Renews monthly for 10 💎</p>
                                    </div>
                                    <Button variant="destructive" size="sm" onClick={() => handleCancel(subUser.id)}>Cancel</Button>
                                </div>
                            ))
                        ) : (
                            <p className="text-center text-muted-foreground py-8">You are not subscribed to any creators.</p>
                        )}
                    </div>
                </ScrollArea>
            </DialogContent>
        </Dialog>
    );
}

function TransactionHistoryDialog({ userId, children }: { userId: string, children: React.ReactNode }) {
    const [transactions, setTransactions] = React.useState<TransactionType[]>([]);
    const [isLoading, setIsLoading] = React.useState(false);
    const [isOpen, setIsOpen] = React.useState(false);
    
    React.useEffect(() => {
        if (!isOpen) return;
        const fetchTxs = async () => {
            setIsLoading(true);
            const userTxs = await getTransactions(userId);
            setTransactions(userTxs);
            setIsLoading(false);
        }
        fetchTxs();
    }, [userId, isOpen]);


    const getStatusBadge = (status: TransactionType['status']) => {
        switch (status) {
            case 'Completed': return <Badge variant="success">Completed</Badge>;
            case 'Pending': return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300">Pending</Badge>;
            case 'Rejected': return <Badge variant="destructive">Rejected</Badge>;
            default: return <Badge variant="secondary">{status}</Badge>;
        }
    }

    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Transaction History</DialogTitle>
                    <DialogDescription>Your past currency purchases and their status.</DialogDescription>
                </DialogHeader>
                <ScrollArea className="h-96 -mx-6">
                    <div className="space-y-4 px-6">
                       {isLoading ? (
                            <Loader2 className="mx-auto animate-spin" />
                        ) : transactions.length > 0 ? (
                            transactions.map(tx => (
                                <div key={tx.id} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 p-3 rounded-lg bg-secondary/50">
                                    <div className="flex items-center gap-3">
                                        <div className="p-2 bg-background rounded-full">
                                            {tx.currency === 'gold' ? '🪙' : '💎'}
                                        </div>
                                        <div>
                                            <p className="font-bold">{tx.package} Package ({tx.amount})</p>
                                            <p className="text-xs text-muted-foreground">
                                                {format(new Date(tx.date), 'MMM d, yyyy')} • {tx.price}
                                            </p>
                                        </div>
                                    </div>
                                    <div className="flex items-center justify-between sm:justify-end gap-4">
                                         <p className="text-xs font-mono text-muted-foreground hidden sm:block">ID: {tx.transactionCode}</p>
                                        {getStatusBadge(tx.status)}
                                    </div>
                                </div>
                            ))
                        ) : (
                            <p className="text-center py-10 text-muted-foreground">No transactions yet.</p>
                        )}
                    </div>
                </ScrollArea>
            </DialogContent>
        </Dialog>
    );
}

type PayoutProvider = 'orange' | 'mtn';

type MobileMoneyAccount = {
  id: string;
  provider: PayoutProvider;
  accountNumber: string;
  name: string;
};

const mockPaymentMethods: MobileMoneyAccount[] = [
    { id: 'pm-1', provider: 'orange', accountNumber: '0770123456', name: 'Alex Doe' },
];

function ManagePaymentMethodsDialog({ children }: { children: React.ReactNode }) {
    const { toast } = useToast();
    const [methods, setMethods] = React.useState(mockPaymentMethods);
    const [isAdding, setIsAdding] = React.useState(false);

    const handleRemove = (methodId: string) => {
        setMethods(prev => prev.filter(m => m.id !== methodId));
        toast({ title: 'Payment method removed.' });
    };
    
    const handleAdd = (newMethod: Omit<MobileMoneyAccount, 'id'>) => {
        const methodToAdd = { ...newMethod, id: `pm-${Date.now()}` };
        setMethods(prev => [methodToAdd, ...prev]);
        setIsAdding(false);
        toast({ title: 'Payment method added successfully!'});
    }

    return (
        <Dialog>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Manage Payment Methods</DialogTitle>
                </DialogHeader>
                <div className="py-4 space-y-4">
                    {methods.map(method => (
                        <div key={method.id} className="flex items-center p-3 rounded-lg border">
                            <Wallet className="h-6 w-6 mr-4 text-muted-foreground" />
                            <div className="flex-1">
                                <p className="font-semibold">{method.name} ({method.provider === 'orange' ? 'Orange' : 'MTN'})</p>
                                <p className="text-sm text-muted-foreground">**** {method.accountNumber.slice(-4)}</p>
                            </div>
                            <Button variant="ghost" size="icon" onClick={() => handleRemove(method.id)}>
                                <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                        </div>
                    ))}
                    {isAdding ? (
                        <AddPaymentMethodForm onAdd={handleAdd} onCancel={() => setIsAdding(false)} />
                    ) : (
                        <Button variant="outline" className="w-full" onClick={() => setIsAdding(true)}>
                            <PlusCircle className="mr-2 h-4 w-4" /> Add Mobile Wallet
                        </Button>
                    )}
                </div>
            </DialogContent>
        </Dialog>
    );
}

function AddPaymentMethodForm({ onAdd, onCancel }: { onAdd: (method: Omit<MobileMoneyAccount, 'id'>) => void, onCancel: () => void }) {
    const [provider, setProvider] = React.useState<PayoutProvider>('orange');
    const [name, setName] = React.useState('');
    const [accountNumber, setAccountNumber] = React.useState('');

    const handleSave = () => {
        if (!name.trim() || !accountNumber.trim()) {
            return;
        }
        onAdd({ provider, name, accountNumber });
    };

    return (
        <Card>
            <CardHeader><CardTitle>Add Mobile Wallet</CardTitle></CardHeader>
            <CardContent className="space-y-4">
                <div className="space-y-2">
                    <Label>Provider</Label>
                    <RadioGroup value={provider} onValueChange={(v) => setProvider(v as PayoutProvider)} className="grid grid-cols-2 gap-4">
                        <div>
                            <RadioGroupItem value="orange" id="add-orange" className="peer sr-only" />
                            <Label htmlFor="add-orange" className="flex items-center justify-center rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent peer-data-[state=checked]:border-primary">
                                Orange Money
                            </Label>
                        </div>
                        <div>
                            <RadioGroupItem value="mtn" id="add-mtn" className="peer sr-only" />
                            <Label htmlFor="add-mtn" className="flex items-center justify-center rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent peer-data-[state=checked]:border-primary">
                                MTN Momo
                            </Label>
                        </div>
                    </RadioGroup>
                </div>
                <div className="space-y-2">
                    <Label htmlFor="accountName">Account Name</Label>
                    <Input id="accountName" placeholder="e.g. Alex Doe" value={name} onChange={(e) => setName(e.target.value)} />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="accountNumber">Account Number</Label>
                    <Input id="accountNumber" type="tel" placeholder="e.g. 0770123456" value={accountNumber} onChange={(e) => setAccountNumber(e.target.value)} />
                </div>
                <div className="flex gap-2 pt-2">
                    <Button variant="ghost" onClick={onCancel} className="w-full">Cancel</Button>
                    <Button onClick={handleSave} className="w-full">Save Wallet</Button>
                </div>
            </CardContent>
        </Card>
    )
}

function BlockedAccountsDialog({ currentUser, children }: { currentUser: UserType, children: React.ReactNode }) {
    const [blockedUsers, setBlockedUsers] = React.useState<UserType[]>([]);
    const [isLoading, setIsLoading] = React.useState(false);
    const [isOpen, setIsOpen] = React.useState(false);
    const { toast } = useToast();

    React.useEffect(() => {
        if (isOpen) {
            setIsLoading(true);
            getBlockedUsers(currentUser.id).then(setBlockedUsers).finally(() => setIsLoading(false));
        }
    }, [isOpen, currentUser.id]);

    const handleUnblock = (userId: string) => {
        toggleBlock(currentUser.id, userId, true).then(() => {
            setBlockedUsers(prev => prev.filter(u => u.id !== userId));
            toast({ title: 'User unblocked.' });
        });
    };

    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Blocked Accounts</DialogTitle>
                    <DialogDescription>
                        They won't be able to find your profile, posts, or story. They are not notified when you block or unblock them.
                    </DialogDescription>
                </DialogHeader>
                <ScrollArea className="h-80 -mx-6">
                    <div className="px-6 space-y-2">
                        {isLoading ? <Loader2 className="mx-auto animate-spin" /> :
                         blockedUsers.length > 0 ? blockedUsers.map(user => (
                            <div key={user.id} className="flex items-center p-2 rounded-lg hover:bg-accent">
                                <UserAvatar user={user} className="h-10 w-10 mr-4"/>
                                <div className="flex-1">
                                    <p className="font-semibold">{user.name}</p>
                                    <p className="text-sm text-muted-foreground">@{user.username}</p>
                                </div>
                                <Button size="sm" variant="outline" onClick={() => handleUnblock(user.id)}>Unblock</Button>
                            </div>
                        )) : (
                            <p className="text-center text-muted-foreground py-10">You haven't blocked any accounts.</p>
                        )}
                    </div>
                </ScrollArea>
            </DialogContent>
        </Dialog>
    );
}

type PrivacySetting = 'everyone' | 'followers' | 'none';

function PrivacyControlDialog({ children, title, currentValue, onSave }: { children: React.ReactNode, title: string, currentValue: PrivacySetting, onSave: (value: PrivacySetting) => void }) {
    const [selectedValue, setSelectedValue] = React.useState(currentValue);
    const { toast } = useToast();

    const handleSave = () => {
        onSave(selectedValue);
        toast({ title: `Settings for "${title}" updated.` });
    }

    const options = [
        { value: 'everyone', label: 'Everyone' },
        { value: 'followers', label: 'People you follow' },
        { value: 'none', label: 'No one' },
    ];

    return (
        <Dialog>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{title}</DialogTitle>
                </DialogHeader>
                <RadioGroup value={selectedValue} onValueChange={(v) => setSelectedValue(v as PrivacySetting)} className="py-4 space-y-2">
                    {options.map(option => (
                        <Label key={option.value} htmlFor={option.value} className="flex items-center gap-3 p-3 rounded-lg border has-[:checked]:bg-accent has-[:checked]:border-primary">
                            <RadioGroupItem value={option.value} id={option.value} />
                            {option.label}
                        </Label>
                    ))}
                </RadioGroup>
                <DialogFooter>
                    <DialogClose asChild>
                       <Button onClick={handleSave}>Save</Button>
                    </DialogClose>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

function ThemeSelectorDialog({ children }: { children: React.ReactNode }) {
    const { theme, setTheme } = useTheme();

    return (
        <Dialog>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent className="max-w-sm">
                <DialogHeader>
                    <DialogTitle>Select Theme</DialogTitle>
                </DialogHeader>
                <RadioGroup value={theme} onValueChange={setTheme} className="py-4 space-y-2">
                     <Label htmlFor="light" className="flex items-center gap-3 p-3 rounded-lg border has-[:checked]:bg-accent has-[:checked]:border-primary">
                        <RadioGroupItem value="light" id="light" />
                        <Sun className="h-5 w-5"/>
                        Light
                    </Label>
                    <Label htmlFor="dark" className="flex items-center gap-3 p-3 rounded-lg border has-[:checked]:bg-accent has-[:checked]:border-primary">
                        <RadioGroupItem value="dark" id="dark" />
                        <Moon className="h-5 w-5"/>
                        Dark
                    </Label>
                     <Label htmlFor="system" className="flex items-center gap-3 p-3 rounded-lg border has-[:checked]:bg-accent has-[:checked]:border-primary">
                        <RadioGroupItem value="system" id="system" />
                        <Monitor className="h-5 w-5"/>
                        System
                    </Label>
                </RadioGroup>
            </DialogContent>
        </Dialog>
    )
}

function DataManagementDialog({ title, description, actionText, onConfirm, children, isDestructive }: { title: string, description: string, actionText: string, onConfirm: () => void, children: React.ReactNode, isDestructive?: boolean }) {
    const handleConfirm = () => {
        onConfirm();
    }
    return (
        <Dialog>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{title}</DialogTitle>
                    <DialogDescription>
                       {description}
                    </DialogDescription>
                </DialogHeader>
                <DialogFooter>
                    <DialogClose asChild>
                        <Button variant="outline">Cancel</Button>
                    </DialogClose>
                     <DialogClose asChild>
                        <Button variant={isDestructive ? "destructive" : "default"} onClick={handleConfirm}>{actionText}</Button>
                    </DialogClose>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

export function ContactSupportDialog({ user, children }: { user: UserType, children: React.ReactNode }) {
    const [subject, setSubject] = React.useState('');
    const [message, setMessage] = React.useState('');
    const { toast } = useToast();
    const [isOpen, setIsOpen] = React.useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!subject.trim() || !message.trim()) {
            toast({
                variant: 'destructive',
                title: 'Please fill out all fields.',
            });
            return;
        }

        try {
            await createSupportTicket({ user, subject, message });
            toast({
                title: 'Support Ticket Submitted',
                description: 'We have received your request and will get back to you shortly.',
            });
            setSubject('');
            setMessage('');
            setIsOpen(false);
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: 'Could not submit your ticket. Please try again.' });
        }
    }

    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Contact Support</DialogTitle>
                    <DialogDescription>
                        Have an issue or a question? Let us know.
                    </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="subject">Subject</Label>
                        <Input 
                            id="subject" 
                            value={subject}
                            onChange={(e) => setSubject(e.target.value)}
                            placeholder="e.g., Issue with login"
                        />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="message">Message</Label>
                        <Textarea 
                            id="message"
                            value={message}
                            onChange={(e) => setMessage(e.target.value)}
                            placeholder="Please describe your issue in detail..."
                            rows={5}
                        />
                    </div>
                    <DialogFooter>
                        <Button type="submit">
                            <Send className="mr-2 h-4 w-4" /> Submit
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}

function LinkedAccountsDialog({ children }: { children: React.ReactNode }) {
  const { toast } = useToast();
  const [provider, setProvider] = React.useState<string | null>(null);

  React.useEffect(() => {
    account.get().then(acc => {
      // The user object from `account.get()` contains the provider
      if (acc.provider && acc.provider !== 'email') {
        setProvider(acc.provider);
      }
    }).catch(() => {});
  }, []);
  
  const handleUnlink = (provider: string) => {
    toast({ variant: 'destructive', title: 'Unlinking is not supported yet.' });
  };

  return (
    <Dialog>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Linked Accounts</DialogTitle>
          <DialogDescription>
            Manage third-party accounts linked to your VIMore profile for login.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          {provider ? (
            <div className="flex items-center p-3 rounded-lg border">
              <div className="flex-1 flex items-center gap-4">
                <p className="font-semibold capitalize">{provider}</p>
              </div>
              <Button variant="destructive" disabled>Unlink</Button>
            </div>
          ) : (
             <p className="text-sm text-muted-foreground text-center">No accounts are linked.</p>
          )}
          <Button variant="outline" className="w-full" disabled>
            <PlusCircle className="mr-2 h-4 w-4" /> Link Another Account
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function LanguageRegionDialog({ children }: { children: React.ReactNode }) {
    const t = useTranslations('LanguageRegionDialog');
    const { toast } = useToast();
    const router = useRouter();
    const pathname = usePathname();
    const currentLocale = useLocale();
    const [selectedLocale, setSelectedLocale] = React.useState(currentLocale);

    const handleSave = () => {
        router.replace(pathname, { locale: selectedLocale });
        toast({
            title: t('success'),
            description: t('successDescription')
        });
    }

    return (
        <Dialog>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent>
                <DialogHeader><DialogTitle>{t('title')}</DialogTitle></DialogHeader>
                <div className="py-4 space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="language-select">{t('language')}</Label>
                        <Select value={selectedLocale} onValueChange={setSelectedLocale}>
                            <SelectTrigger id="language-select">
                                <SelectValue placeholder="Select language..." />
                            </SelectTrigger>
                            <SelectContent>
                                {languages.map(lang => (
                                    <SelectItem key={lang.code} value={lang.code}>{lang.name}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="region-select">{t('region')}</Label>
                        <Select defaultValue="US">
                             <SelectTrigger id="region-select">
                                <SelectValue placeholder="Select region..." />
                            </SelectTrigger>
                            <SelectContent>
                                {countries.map(country => (
                                    <SelectItem key={country.code} value={country.code}>{country.name}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                </div>
                <DialogFooter>
                    <DialogClose asChild><Button variant="outline">{t('cancel')}</Button></DialogClose>
                    <DialogClose asChild><Button onClick={handleSave}>{t('save')}</Button></DialogClose>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    )
}
