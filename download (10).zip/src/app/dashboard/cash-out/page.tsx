
'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Check, Banknote, Wallet, Info, GitCommitHorizontal, CheckCircle, XCircle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import type { User, PayoutRequest, SavedAccount } from '@/lib/data';
import { formatNumber, formatTime } from '@/lib/utils';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from "@/lib/utils";
import { conversionRates, PLATFORM_FEE } from '@/lib/monetization-config';
import { AppContext } from '@/components/app-shell';
import { getPayoutRequests as fetchPayoutHistory, createPayoutRequest } from '@/services/monetizationService';
import { updateUser } from '@/services/userService';


const minWithdrawal = {
    gold: 500,
    diamond: 50,
}

type PayoutProvider = 'orange' | 'mtn';
type PlatformCurrency = 'gold' | 'diamond';
type RealCurrency = 'USD' | 'LD';


export default function CashOutPage() {
  const router = useRouter();
  const { toast } = useToast();
  const appContext = React.useContext(AppContext);
  
  const [payoutHistory, setPayoutHistory] = React.useState<PayoutRequest[]>([]);
  const [saveAccount, setSaveAccount] = React.useState(true);

  const [step, setStep] = React.useState(1);
  const [provider, setProvider] = React.useState<PayoutProvider | null>(null);
  const [accountName, setAccountName] = React.useState('');
  const [accountNumber, setAccountNumber] = React.useState('');
  
  const [platformCurrency, setPlatformCurrency] = React.useState<PlatformCurrency | null>(null);
  const [withdrawAmount, setWithdrawAmount] = React.useState('');
  
  const [realCurrency, setRealCurrency] = React.useState<RealCurrency | null>(null);

  const [submissionState, setSubmissionState] = React.useState<'idle' | 'loading' | 'submitted'>('idle');
  
  if (!appContext || !appContext.currentUser) return <div className="flex h-screen items-center justify-center"><Loader2 className="animate-spin" /></div>;
  const { currentUser, setCurrentUser } = appContext;

  const savedAccounts = currentUser.savedAccounts || [];

  React.useEffect(() => {
    const loadHistory = async () => {
        const history = await fetchPayoutHistory();
        setPayoutHistory(history as any);
    };
    loadHistory();
  }, []);

  const convertedAmount = React.useMemo(() => {
    if (!platformCurrency || !realCurrency || !withdrawAmount) return 0;
    const amount = parseFloat(withdrawAmount);
    if (isNaN(amount) || amount <= 0) return 0;
    
    return amount * conversionRates[platformCurrency][realCurrency];
  }, [platformCurrency, realCurrency, withdrawAmount]);

  const feeAmount = convertedAmount * PLATFORM_FEE;
  const finalAmount = convertedAmount - feeAmount;

  const canProceedToStep2 = provider && accountName && accountNumber;
  const canProceedToStep3 = platformCurrency && parseFloat(withdrawAmount || '0') >= (minWithdrawal[platformCurrency!] || 0) && parseFloat(withdrawAmount || '0') <= (currentUser.creatorBalance?.[platformCurrency!] || 0);

  const getDynamicProcessingTime = () => {
    const now = new Date();
    const day = now.getDay(); // 0 = Sunday, 6 = Saturday
    const hour = now.getHours();

    if (day > 0 && day < 6 && hour >= 9 && hour < 17) {
      return "Est. 2-4 hours";
    }
    return "By next business day";
  };
  
  const handleQuickWithdraw = (percentage: number) => {
    if (!platformCurrency || !currentUser.creatorBalance) return;
    const balance = currentUser.creatorBalance[platformCurrency] || 0;
    const amount = Math.floor(balance * percentage);
    setWithdrawAmount(amount.toString());
  }

  const resetForm = () => {
      setStep(1);
      setProvider(null);
      setAccountName('');
      setAccountNumber('');
      setPlatformCurrency(null);
      setWithdrawAmount('');
      setRealCurrency(null);
      setSaveAccount(true);
      setSubmissionState('idle');
  }

  const handleSubmit = async () => {
    if (!realCurrency || finalAmount <= 0) {
      toast({ variant: 'destructive', title: 'Invalid Amount', description: 'Please select a currency and ensure the final amount is greater than zero.' });
      return;
    }
    
    if (!platformCurrency || !provider || !currentUser?.email) {
      toast({ variant: 'destructive', title: 'Error', description: 'Missing required information to process request.' });
      return;
    }

    setSubmissionState('loading');
    try {
        const isNewAccount = !savedAccounts.some(acc => acc.accountNumber === accountNumber);
        if (saveAccount && isNewAccount && provider) {
            const newAccount: SavedAccount = {
                id: `sa-${Date.now()}`,
                provider: provider,
                name: accountName,
                accountNumber: accountNumber,
            };
            const updatedSavedAccounts = [...savedAccounts, newAccount];
            await updateUser(currentUser.id, { savedAccounts: updatedSavedAccounts });
            setCurrentUser({ ...currentUser, savedAccounts: updatedSavedAccounts });
        }


        await createPayoutRequest({
            user: currentUser,
            amount: parseFloat(withdrawAmount),
            currency: realCurrency,
            platformCurrency,
            provider,
            accountName,
            accountNumber,
        });

        // Update the user's balance in the context
        if (platformCurrency && currentUser.creatorBalance) {
          const newBalance = (currentUser.creatorBalance[platformCurrency] || 0) - parseFloat(withdrawAmount);
          const updatedUser = { ...currentUser, creatorBalance: { ...(currentUser.creatorBalance || {}), [platformCurrency]: newBalance } };
          setCurrentUser(updatedUser);
        }

        setSubmissionState('submitted');

    } catch (error: any) {
        toast({
            variant: 'destructive',
            title: 'Submission Failed',
            description: error.message || 'Could not submit your payout request.',
        });
        setSubmissionState('idle');
    }
  };
  
  const handleCancelRequest = (requestId: string) => {
    setPayoutHistory(prev => prev.map(p => p.id === requestId ? {...p, status: 'cancelled'} : p));
    toast({ title: "Payout request cancelled." });
  }
  
  const handleSelectSavedAccount = (accountId: string) => {
      if (accountId === 'new') {
        setProvider(null);
        setAccountName('');
        setAccountNumber('');
        return;
      }
      const account = savedAccounts.find(a => a.id === accountId);
      if (account) {
          setProvider(account.provider);
          setAccountName(account.name);
          setAccountNumber(account.accountNumber);
      }
  }
  
  if (submissionState === 'submitted') {
    return (
      <div className="container mx-auto max-w-2xl py-4 sm:py-6">
        <header className="mb-6 flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => router.push('/dashboard')}>
            <ArrowLeft />
          </Button>
          <h1 className="font-headline text-3xl font-bold">Cash Out</h1>
        </header>
        <Card>
          <CardContent className="p-6 text-center space-y-4">
            <CheckCircle className="mx-auto h-16 w-16 text-green-500" />
            <h2 className="text-2xl font-bold">Request Submitted!</h2>
            <p className="text-muted-foreground">Your payout request has been received. You can track its status in the "Recent Payouts" section on your dashboard.</p>
            <Button className="mt-2" onClick={resetForm}>Request Another Payout</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <>
            <CardHeader>
                <CardTitle>Step 1: Payout Destination</CardTitle>
                <CardDescription>Choose where you want to receive your money.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="space-y-2">
                    <Label>Select Payout Account</Label>
                    <Select onValueChange={handleSelectSavedAccount} defaultValue={savedAccounts.length > 0 ? savedAccounts[0].id : 'new'}>
                        <SelectTrigger>
                            <SelectValue placeholder="Select a saved account" />
                        </SelectTrigger>
                        <SelectContent>
                            {savedAccounts.map(acc => (
                                <SelectItem key={acc.id} value={acc.id}>
                                    {acc.name} ({acc.provider}) - ****{acc.accountNumber.slice(-4)}
                                </SelectItem>
                            ))}
                            <SelectItem value="new">Add a new account</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                
                <div className="space-y-2">
                    <Label>Select Mobile Money Provider</Label>
                    <RadioGroup value={provider || ''} onValueChange={(value) => setProvider(value as PayoutProvider)} className="grid grid-cols-2 gap-4">
                        <div>
                            <RadioGroupItem value="orange" id="orange" className="peer sr-only" />
                            <Label htmlFor="orange" className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">
                                Orange Money
                            </Label>
                        </div>
                         <div>
                            <RadioGroupItem value="mtn" id="mtn" className="peer sr-only" />
                            <Label htmlFor="mtn" className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">
                                MTN Momo
                            </Label>
                        </div>
                    </RadioGroup>
                </div>
                 {provider && (
                    <div className="space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="accountName">Account Name</Label>
                            <Input id="accountName" placeholder="e.g. John Doe" value={accountName} onChange={(e) => setAccountName(e.target.value)} />
                        </div>
                         <div className="space-y-2">
                            <Label htmlFor="accountNumber">Account Number</Label>
                            <Input id="accountNumber" type="tel" placeholder="e.g. 0770123456" value={accountNumber} onChange={(e) => setAccountNumber(e.target.value)} />
                        </div>
                        {!savedAccounts.some(acc => acc.accountNumber === accountNumber) && (
                            <div className="flex items-center space-x-2">
                                <input type="checkbox" id="saveAccount" checked={saveAccount} onChange={(e) => setSaveAccount(e.target.checked)} />
                                <Label htmlFor="saveAccount" className="text-sm font-normal">Save this account for future payouts</Label>
                           </div>
                        )}
                    </div>
                 )}
            </CardContent>
            <CardContent>
                <Button className="w-full" disabled={!canProceedToStep2} onClick={() => setStep(2)}>Next</Button>
            </CardContent>
          </>
        );
      case 2:
        return (
            <>
                <CardHeader>
                    <CardTitle>Step 2: Withdrawal Amount</CardTitle>
                    <CardDescription>Choose which currency and how much you want to withdraw.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="space-y-2">
                        <Label>Select currency to withdraw from</Label>
                        <RadioGroup value={platformCurrency || ''} onValueChange={(value) => setPlatformCurrency(value as PlatformCurrency)} className="grid grid-cols-2 gap-4">
                            <div>
                                <RadioGroupItem value="gold" id="gold" className="peer sr-only" />
                                <Label htmlFor="gold" className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">
                                    🪙 Gold
                                </Label>
                            </div>
                             <div>
                                <RadioGroupItem value="diamond" id="diamond" className="peer sr-only" />
                                <Label htmlFor="diamond" className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">
                                    💎 Diamond
                                </Label>
                            </div>
                        </RadioGroup>
                    </div>
                    {platformCurrency && (
                        <div className="space-y-2">
                            <Label htmlFor="withdrawAmount">Amount to Withdraw</Label>
                            <div className="relative">
                                <Input 
                                    id="withdrawAmount" 
                                    type="number" 
                                    placeholder={`e.g. ${minWithdrawal[platformCurrency]}`}
                                    value={withdrawAmount} 
                                    onChange={(e) => setWithdrawAmount(e.target.value)}
                                />
                            </div>
                            <div className="flex justify-between items-center">
                                <p className="text-xs text-muted-foreground">
                                    Minimum: {minWithdrawal[platformCurrency]} {platformCurrency}. 
                                    Your balance: {formatNumber(currentUser.creatorBalance?.[platformCurrency] || 0)}
                                </p>
                                <div className="flex gap-1">
                                    <Button type="button" size="sm" variant="outline" className="text-xs h-6 px-2" onClick={() => handleQuickWithdraw(0.25)}>25%</Button>
                                    <Button type="button" size="sm" variant="outline" className="text-xs h-6 px-2" onClick={() => handleQuickWithdraw(0.50)}>50%</Button>
                                    <Button type="button" size="sm" variant="outline" className="text-xs h-6 px-2" onClick={() => handleQuickWithdraw(1)}>Max</Button>
                                </div>
                            </div>
                        </div>
                    )}
                </CardContent>
                <CardContent className="flex gap-2">
                    <Button variant="outline" onClick={() => setStep(1)}>Back</Button>
                    <Button className="w-full" disabled={!canProceedToStep3} onClick={() => setStep(3)}>Next</Button>
                </CardContent>
            </>
        )
       case 3:
        return (
             <>
                <CardHeader>
                    <CardTitle>Step 3: Confirm and Submit</CardTitle>
                    <CardDescription>Review your payout details and submit your request.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="space-y-2">
                        <Label>Select payout currency</Label>
                        <RadioGroup value={realCurrency || ''} onValueChange={(value) => setRealCurrency(value as RealCurrency)} className="grid grid-cols-2 gap-4">
                            <div>
                                <RadioGroupItem value="USD" id="USD" className="peer sr-only" />
                                <Label htmlFor="USD" className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">
                                    USD
                                </Label>
                            </div>
                             <div>
                                <RadioGroupItem value="LD" id="LD" className="peer sr-only" />
                                <Label htmlFor="LD" className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary">
                                    LD
                                </Label>
                            </div>
                        </RadioGroup>
                    </div>
                    {realCurrency && (
                        <Alert>
                            <Info className="h-4 w-4"/>
                            <AlertTitle>Payout Breakdown</AlertTitle>
                             <AlertDescription className="text-sm space-y-1 mt-2">
                                <div className="flex justify-between"><span>Converted Value:</span><span>{realCurrency === 'USD' ? '$' : ''}{convertedAmount.toFixed(2)} {realCurrency}</span></div>
                                <div className="flex justify-between text-destructive"><span>Platform Fee (10%):</span><span>- {realCurrency === 'USD' ? '$' : ''}{feeAmount.toFixed(2)} {realCurrency}</span></div>
                                <Separator className="my-1"/>
                                <div className="flex justify-between font-bold"><span>You will receive:</span><span>{realCurrency === 'USD' ? '$' : ''}{finalAmount.toFixed(2)} {realCurrency}</span></div>
                            </AlertDescription>
                        </Alert>
                    )}
                    <Separator />
                    <div className="space-y-3 text-sm text-muted-foreground">
                        <h4 className="font-semibold text-foreground">Request Summary</h4>
                        <p><strong>Withdrawal:</strong> {withdrawAmount} {platformCurrency === 'gold' ? '🪙' : '💎'}</p>
                        <p><strong>Provider:</strong> {provider === 'orange' ? 'Orange Money' : 'MTN Momo'}</p>
                        <p><strong>Account:</strong> {accountName} ({accountNumber})</p>
                        <p><strong>Est. Processing Time:</strong> {getDynamicProcessingTime()}</p>
                    </div>
                </CardContent>
                <CardContent className="flex gap-2">
                     <Button variant="outline" onClick={() => setStep(2)}>Back</Button>
                    <Button className="w-full" disabled={!realCurrency || finalAmount <= 0 || submissionState === 'loading'} onClick={handleSubmit}>
                        {submissionState === 'loading' && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        <Check className="mr-2 h-4 w-4"/> Submit Request
                    </Button>
                </CardContent>
             </>
        )
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto max-w-2xl py-4 sm:py-6">
      <header className="mb-6 flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.push('/dashboard')}>
          <ArrowLeft />
        </Button>
        <h1 className="font-headline text-3xl font-bold">Cash Out</h1>
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6">
        <Card className="flex flex-col justify-between">
            <CardHeader>
                <CardTitle className="text-lg text-muted-foreground">Gold Balance</CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-4xl font-bold flex items-center">
                    🪙 {formatNumber(currentUser.creatorBalance?.gold || 0)}
                </p>
            </CardContent>
        </Card>
        <Card className="flex flex-col justify-between">
            <CardHeader>
                <CardTitle className="text-lg text-muted-foreground">Diamond Balance</CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-4xl font-bold flex items-center">
                    💎 {formatNumber(currentUser.creatorBalance?.diamonds || 0)}
                </p>
            </CardContent>
        </Card>
      </div>

      <Card>{renderStep()}</Card>

      <RecentPayouts history={payoutHistory} onCancel={handleCancelRequest} />
    </div>
  );
}

function RecentPayouts({ history, onCancel }: { history: PayoutRequest[], onCancel: (id: string) => void }) {
    if (history.length === 0) return null;

    return (
        <Card className="mt-6">
            <CardHeader>
                <CardTitle>Recent Payouts</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                {history.slice(0, 5).map(req => (
                    <PayoutHistoryItem key={req.id} request={req} onCancel={onCancel} />
                ))}
            </CardContent>
        </Card>
    );
}

function PayoutHistoryItem({ request, onCancel }: { request: PayoutRequest, onCancel: (id: string) => void}) {
    const isCancellable = request.status === 'processing' && (new Date().getTime() - new Date(request.timestamp).getTime()) < 2 * 60 * 1000;
    const [, setForceRender] = React.useState(0);

    React.useEffect(() => {
        if (isCancellable) {
            const timer = setTimeout(() => {
                setForceRender(n => n + 1);
            }, 2 * 60 * 1000 - (new Date().getTime() - new Date(request.timestamp).getTime()));
            return () => clearTimeout(timer);
        }
    }, [isCancellable, request.timestamp]);
    
    return (
        <div className="p-4 rounded-lg bg-secondary">
            <div className="flex justify-between items-start">
                <div>
                    <p className="font-bold">{request.currency === 'USD' ? '$' : ''}{request.amount.toFixed(2)} {request.currency}</p>
                    <p className="text-sm text-muted-foreground">From {request.platformCurrency}</p>
                     <p className="text-xs text-muted-foreground mt-1">{new Date(request.timestamp).toLocaleString()}</p>
                </div>
                 {isCancellable ? (
                    <Button variant="destructive" size="sm" onClick={() => onCancel(request.id)}>Cancel</Button>
                ) : (
                    <div/>
                )}
            </div>
            <StatusTracker status={request.status} />
        </div>
    )
}

function StatusTracker({ status }: { status: PayoutRequest['status'] }) {
    const steps = [
        { name: 'Requested', status: ['processing', 'pending', 'completed'] },
        { name: 'In Review', status: ['pending', 'completed'] },
        { name: 'Sent', status: ['completed'] },
    ];
    
    if (status === 'rejected' || status === 'cancelled') {
        return (
             <div className="flex items-center gap-2 mt-3 text-sm text-destructive">
                <XCircle className="h-4 w-4"/>
                <p>This request was {status}.</p>
             </div>
        )
    }

    return (
        <div className="flex items-center gap-2 mt-4">
            {steps.map((step, index) => {
                const isActive = step.status.includes(status);
                return (
                    <React.Fragment key={step.name}>
                        <div className="flex flex-col items-center">
                            <div className={`w-6 h-6 rounded-full flex items-center justify-center ${isActive ? 'bg-primary' : 'bg-muted border-2'}`}>
                                {isActive && <Check className="w-4 h-4 text-primary-foreground"/>}
                            </div>
                            <p className={`text-xs mt-1 ${isActive ? 'text-foreground' : 'text-muted-foreground'}`}>{step.name}</p>
                        </div>
                        {index < steps.length - 1 && (
                            <div className={`flex-1 h-0.5 ${steps[index+1].status.includes(status) ? 'bg-primary' : 'bg-muted'}`} />
                        )}
                    </React.Fragment>
                )
            })}
        </div>
    );
}

