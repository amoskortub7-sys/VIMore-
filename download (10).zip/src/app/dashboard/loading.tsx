import { ArrowLeft, LayoutDashboard, Pencil, Users2, Crown, Star, Users, Zap, MessageCircle, Calendar, VideoIcon, Video } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardHeader, CardContent } from '@/components/ui/card';

export default function DashboardLoading() {
  return (
    <div className="bg-background min-h-screen">
      <header className="sticky top-0 z-10 flex items-center gap-4 border-b bg-background p-4">
        <Skeleton className="h-10 w-10 rounded-full" />
        <Skeleton className="h-6 w-32" />
      </header>
      
      <main className="p-4 space-y-6">
        <div className="flex gap-2 pb-2">
            <Skeleton className="h-10 w-20 rounded-full" />
            <Skeleton className="h-10 w-24 rounded-full" />
            <Skeleton className="h-10 w-28 rounded-full" />
            <Skeleton className="h-10 w-32 rounded-full" />
        </div>
        
        <Card className="shadow-none border-0 bg-transparent">
            <CardContent className="p-0 flex items-center gap-4">
                <Skeleton className="h-14 w-14 rounded-full" />
                <div className="flex-1 space-y-2">
                    <Skeleton className="h-5 w-32" />
                    <Skeleton className="h-4 w-48" />
                    <Skeleton className="h-2 w-full" />
                </div>
            </CardContent>
        </Card>

        <Card>
            <CardHeader className="flex-row items-center justify-between">
                <Skeleton className="h-6 w-40" />
                <Skeleton className="h-4 w-24" />
            </CardHeader>
            <CardContent className="space-y-3">
                <Skeleton className="h-5 w-3/4" />
                <Skeleton className="h-5 w-1/2" />
                <Skeleton className="h-5 w-2/3" />
                <Skeleton className="h-5 w-3/5" />
            </CardContent>
        </Card>

        <Card>
            <CardHeader>
                <Skeleton className="h-6 w-32" />
            </CardHeader>
            <CardContent>
                 <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-4">
                    {Array.from({ length: 10 }).map((_, i) => (
                         <div key={i} className="flex flex-col items-center gap-2 text-center">
                            <Skeleton className="h-20 w-20 rounded-full" />
                            <Skeleton className="h-3 w-16" />
                        </div>
                    ))}
                 </div>
            </CardContent>
        </Card>
      </main>
    </div>
  );
}
