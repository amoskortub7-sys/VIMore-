'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import {
  ArrowLeft,
  ChevronRight,
  Lightbulb,
  Loader2,
  BookOpen,
  Sparkles,
  CheckCircle,
  Megaphone,
} from 'lucide-react';
import { type GuideArticleContent, type Challenge, type Badge as BadgeType, type User, type Post } from '@/lib/data';
import { formatNumber, cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
// import { generatePostSuggestions } from '@/ai/flows/generate-post-suggestions';
// import { generateCreativeChallenge } from '@/ai/flows/generate-creative-challenge';
// import { generateWeeklyChallenges } from '@/ai/flows/generate-weekly-challenges';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import Link from 'next/link';
import { UserAvatar } from '@/components/user-avatar';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { PostCard } from '@/components/post-card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { getWeek } from 'date-fns';
import { motion, AnimatePresence } from 'framer-motion';
import { CreatePostForm } from '@/components/create-post-form';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { useIsMobile } from '@/hooks/use-is-mobile';
import { getEarnings } from '@/services/monetizationService';
import { getPosts } from '@/services/postService';
import { getFollowers } from '@/services/userService';
import { AppContext } from '@/components/app-shell';
import { EarningsDashboard } from './earnings-dashboard';


const navItems = ["Home", "Insights", "Content", "Engagement", "Earnings"];

const initialChallenges: Challenge[] = [
    { id: 'c1', text: 'Post a Reel this week', isCompleted: false },
    { id: 'c2', text: 'Collaborate with another creator', isCompleted: false },
    { id: 'c3', text: 'Reply to 10 comments', isCompleted: false },
    { id: 'c4', text: 'Go live for 5 minutes', isCompleted: true },
];

export default function DashboardPage() {
  const router = useRouter();
  const [activeTab, setActiveTab] = React.useState('Home');
  const appContext = React.useContext(AppContext);
  const { toast } = useToast();

  const [topPosts, setTopPosts] = React.useState<Post[]>([]);
  const [topFans, setTopFans] = React.useState<User[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);

  const currentUser = appContext?.currentUser;

  React.useEffect(() => {
    const fetchData = async () => {
      if (!currentUser) return;
      setIsLoading(true);
      try {
        const [posts, followers] = await Promise.all([
          getPosts(currentUser.id),
          getFollowers(currentUser.id)
        ]);
        
        setTopPosts(posts.sort((a,b) => ((b.reactions?.length ?? 0) + b.comments.length) - ((a.reactions?.length ?? 0) + a.comments.length)).slice(0, 5));
        setTopFans(followers.slice(0, 5));

      } catch (error) {
        toast({ variant: 'destructive', title: 'Could not load dashboard data.' });
      } finally {
        setIsLoading(false);
      }
    }
    fetchData();
  }, [currentUser, toast]);


  if (!currentUser) {
    return <div className="flex h-screen items-center justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>;
  }

  const renderContent = () => {
    switch(activeTab) {
      case 'Home':
        return (
          <>
            <Card className="shadow-none border-0 bg-transparent">
                <CardContent className="p-0 flex items-center gap-4">
                    <UserAvatar user={currentUser} className="h-14 w-14" />
                    <div className="flex-1">
                        <p className="font-bold text-lg">{currentUser.name}</p>
                        <p className="text-sm text-muted-foreground">
                            {formatNumber(currentUser.followers)} followers • Weekly progress
                        </p>
                         <WeeklyProgress challenges={initialChallenges} />
                    </div>
                </CardContent>
            </Card>

            <WeeklyChecklistCard />
            
            <Accordion type="single" collapsible defaultValue="inspiration">
              <AccordionItem value="inspiration">
                <AccordionTrigger className="text-xl font-bold">Inspiration Tools</AccordionTrigger>
                <AccordionContent className="pt-4 space-y-4">
                  <AIPostSuggestionsCard />
                  <AICreativeChallengeCard />
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="guide">
                <AccordionTrigger className="text-xl font-bold">Creator Guide</AccordionTrigger>
                <AccordionContent className="pt-4">
                  <div className="space-y-1">
                    {guideArticles.map(article => <GuideArticle key={article.id} article={article} />)}
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </>
        )
      case 'Insights':
        return (
           <section>
            <div className="flex justify-between items-center mb-2">
                <h2 className="text-xl font-bold">Insights</h2>
            </div>
             <Card>
                <CardHeader>
                    <CardTitle>Overview</CardTitle>
                    <CardDescription>Your high-level statistics.</CardDescription>
                </CardHeader>
                <CardContent className="p-4 grid grid-cols-2 gap-y-6 gap-x-4">
                   <InsightMetric label="Followers" value={formatNumber(currentUser.followers)} />
                   <InsightMetric label="Following" value={formatNumber(currentUser.following)} />
                   <InsightMetric label="Total Posts" value={formatNumber(topPosts.length)} />
                   <InsightMetric label="Total Likes" value={formatNumber(topPosts.reduce((acc, p) => acc + (p.reactions?.length ?? 0), 0))} />
                </CardContent>
            </Card>
            <Card className="mt-6">
                <CardHeader>
                    <CardTitle>Advanced Analytics</CardTitle>
                    <CardDescription>Advanced audience and traffic source analytics are coming soon!</CardDescription>
                </CardHeader>
            </Card>
        </section>
        );
      case 'Content':
        return (
          <section>
            <h2 className="text-xl font-bold mb-4">Top Content</h2>
             {isLoading ? (
                <div className="space-y-4">
                  <Loader2 className="animate-spin mx-auto"/>
                </div>
            ) : topPosts.length > 0 ? (
                <div className="space-y-4">
                  {topPosts.map(post => <PostCard key={post.id} post={post} onBoostPost={()=>{}} />)}
                </div>
            ) : (
                <p className="text-center text-muted-foreground py-8">You haven't made any posts yet.</p>
            )}
          </section>
        );
      case 'Engagement':
         return (
             <section className="space-y-6">
                <h2 className="text-xl font-bold">Engagement</h2>
                {isLoading ? <Loader2 className="animate-spin mx-auto"/> : <TopFansCard topFans={topFans} creator={currentUser}/>}
            </section>
         )
      case 'Earnings':
          return <EarningsDashboard user={currentUser} />;
      default:
        return null;
    }
  }

  return (
    <div className="bg-background min-h-screen">
      <header className="sticky top-0 z-10 flex items-center gap-4 border-b bg-background p-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ArrowLeft />
        </Button>
        <h1 className="text-xl font-bold">Dashboard</h1>
      </header>
      
      <main className="p-4 space-y-6">
        <ScrollArea className="w-full whitespace-nowrap">
            <div className="flex gap-2 pb-2">
                {navItems.map(item => (
                    <Button 
                        key={item}
                        variant={activeTab === item ? 'default' : 'secondary'}
                        className="rounded-full"
                        onClick={() => setActiveTab(item)}
                    >
                        {item}
                    </Button>
                ))}
            </div>
            <ScrollBar orientation="horizontal" />
        </ScrollArea>
        
        {renderContent()}

      </main>
    </div>
  );
}


function InsightMetric({ label, value }: { label: string, value: string | number }) {
    return (
        <div>
            <p className="text-sm font-medium text-muted-foreground">{label}</p>
            <p className="text-2xl font-bold">{value}</p>
        </div>
    )
}

function AIPostSuggestionsCard() {
    const { toast } = useToast();
    const [isLoading, setIsLoading] = React.useState(false);
    const [suggestions, setSuggestions] = React.useState<string[]>([]);
    const appContext = React.useContext(AppContext);
    const user = appContext?.currentUser;

    const handleGetSuggestions = async () => {
        if (!user) return;
        setIsLoading(true);
        setSuggestions([]);
        // AI functionality is disabled.
        toast({
            variant: 'destructive',
            title: 'AI Feature Disabled',
            description: 'This feature is temporarily unavailable.',
        });
        setSuggestions(["Feature temporarily disabled.", "Try creating a post about your favorite hobby!"]);
        setIsLoading(false);
    };
    
    return (
        <Card className="bg-gradient-to-br from-primary/10 to-accent/10">
            <CardHeader>
                <CardTitle className="flex items-center gap-2"><Lightbulb /> Get AI Post Suggestions</CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-muted-foreground mb-4">Overcome creator's block. Get post ideas tailored to your profile and current trends.</p>
                <Button onClick={handleGetSuggestions} disabled={isLoading}>
                    {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Generate Ideas
                </Button>

                {suggestions.length > 0 && (
                    <div className="mt-4 space-y-2">
                        <h4 className="font-semibold">Here are a few ideas for you:</h4>
                        <ul className="list-disc pl-5 space-y-1 text-sm">
                            {suggestions.map((suggestion, index) => (
                                <li key={index}>{suggestion}</li>
                            ))}
                        </ul>
                    </div>
                )}
            </CardContent>
        </Card>
    )
}

function AICreativeChallengeCard() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = React.useState(false);
  const [challenge, setChallenge] = React.useState<string>('');
  const appContext = React.useContext(AppContext);
  const user = appContext?.currentUser;

  const handleGetChallenge = async () => {
    if (!user) return;
    setIsLoading(true);
    setChallenge('');
    // AI functionality is disabled.
    toast({
      variant: 'destructive',
      title: 'AI Feature Disabled',
      description: 'This feature is temporarily unavailable.',
    });
    setChallenge("Create a 15-second video that tells a story without any dialogue.");
    setIsLoading(false);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><Sparkles /> Creative Challenge</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground mb-4">Spark your creativity with a unique challenge generated just for you.</p>
        <Button onClick={handleGetChallenge} disabled={isLoading}>
          {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          New Challenge
        </Button>
        {challenge && (
          <div className="mt-4 rounded-md bg-accent p-4 text-center">
            <p className="font-semibold italic">"{challenge}"</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

const guideArticles: GuideArticleContent[] = [
    {id: 'g1', icon: BookOpen, title: 'How to Write Engaging Captions', content: '...'},
    {id: 'g2', icon: Video, title: '5 Tips for Better Lighting', content: '...'},
    {id: 'g3', icon: Users, title: 'Understanding Your Audience', content: '...'},
];

function GuideArticle({ article }: { article: GuideArticleContent }) {
    return (
        <Dialog>
            <DialogTrigger asChild>
                <button className="flex items-center gap-3 p-3 rounded-lg hover:bg-accent -mx-3 text-left w-full">
                    <div className="p-2 bg-secondary rounded-md">
                        <article.icon className="h-5 w-5 text-secondary-foreground" />
                    </div>
                    <span className="font-semibold">{article.title}</span>
                    <ChevronRight className="h-5 w-5 text-muted-foreground ml-auto" />
                </button>
            </DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{article.title}</DialogTitle>
                </DialogHeader>
                <div className="prose prose-sm dark:prose-invert mt-4">
                    <p>This is placeholder content for the article. In a real application, this would contain detailed tips and best practices for creators.</p>
                    <ul>
                        <li>Tip 1: Be authentic and show your personality.</li>
                        <li>Tip 2: Use relevant hashtags to increase discoverability.</li>
                        <li>Tip 3: Ask questions to encourage comments and engagement.</li>
                    </ul>
                </div>
            </DialogContent>
        </Dialog>
    );
}

function WeeklyProgress({ challenges }: { challenges: Challenge[] }) {
    const completedCount = challenges.filter(c => c.isCompleted).length;
    const totalCount = challenges.length;
    const progressPercentage = totalCount > 0 ? (completedCount / totalCount) * 100 : 0;

    return (
      <div>
        <Progress value={progressPercentage} className="h-2 mt-2" />
        <p className="text-xs text-muted-foreground mt-1">{completedCount} of {totalCount} completed</p>
      </div>
    );
}

function WeeklyChecklistCard() {
  const [challenges, setChallenges] = React.useState<Challenge[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const appContext = React.useContext(AppContext);
  const currentUser = appContext?.currentUser;
  const { toast } = useToast();

  React.useEffect(() => {
    if (!currentUser) return;

    const fetchChallenges = async () => {
      setIsLoading(true);
      // AI functionality is disabled.
      setChallenges(initialChallenges);
      setIsLoading(false);
    };

    fetchChallenges();
  }, [currentUser, toast]);

  // Simulate automatic completion of challenges
  React.useEffect(() => {
    if (challenges.length > 0 && !isLoading) {
      const timers: NodeJS.Timeout[] = [];
      
      // Simulate completing the first challenge after 3 seconds
      timers.push(setTimeout(() => {
        setChallenges(prev => 
            prev.map((c, i) => i === 0 ? { ...c, isCompleted: true } : c)
        );
      }, 3000));
      
      // Simulate completing a second challenge after 5 seconds
      if (challenges.length > 1) {
        timers.push(setTimeout(() => {
          setChallenges(prev => 
              prev.map((c, i) => i === 1 ? { ...c, isCompleted: true } : c)
          );
        }, 5000));
      }

      return () => timers.forEach(clearTimeout);
    }
  }, [challenges.length, isLoading]);
  
  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2"><CheckCircle /> Weekly Checklist</CardTitle>
        <p className="text-sm text-muted-foreground">Refreshes every Monday</p>
      </CardHeader>
      <CardContent>
        {isLoading ? (
            <div className="space-y-3">
                <div className="h-5 w-3/4 animate-pulse rounded-md bg-muted" />
                <div className="h-5 w-1/2 animate-pulse rounded-md bg-muted" />
                <div className="h-5 w-2/3 animate-pulse rounded-md bg-muted" />
                <div className="h-5 w-3/5 animate-pulse rounded-md bg-muted" />
            </div>
        ) : (
            <div className="space-y-3">
              {challenges.map(challenge => (
                <div key={challenge.id} className="flex items-center space-x-3">
                  <div className="flex h-5 w-5 items-center justify-center rounded-sm border border-primary">
                    <AnimatePresence>
                      {challenge.isCompleted && (
                        <motion.div
                          initial={{ scale: 0, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          exit={{ scale: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                        >
                          <Check className="h-4 w-4 text-primary" />
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                  <label
                    className={cn(
                      "text-sm font-medium leading-none transition-colors",
                      challenge.isCompleted && "text-muted-foreground line-through"
                    )}
                  >
                    {challenge.text}
                  </label>
                </div>
              ))}
            </div>
        )}
      </CardContent>
    </Card>
  );
}

function TopFansCard({ topFans, creator }: { topFans: User[], creator: User }) {
  const [isMentionOpen, setIsMentionOpen] = React.useState(false);
  const isMobile = useIsMobile();
  
  const initialContent = `Huge thanks to my top fans ${topFans.map(f => `@${f.username}`).join(', ')} for all the support! 🚀`;

  const MentionTriggerButton = (
    <Button variant="outline">
      <Megaphone className="mr-2 h-4 w-4" />
      Mention Top Fans
    </Button>
  );

  const MentionContent = (
    <CreatePostForm 
      user={creator} 
      onPostCreated={() => setIsMentionOpen(false)} 
      initialContent={initialContent}
      isSheet={isMobile}
    />
  );
  
  return (
      <Card>
        <CardHeader className="flex-row items-center justify-between">
          <div>
            <CardTitle>Recognize Your Top Fans</CardTitle>
            <CardDescription>Show appreciation to your most engaged followers.</CardDescription>
          </div>
           {isMobile ? (
              <Sheet open={isMentionOpen} onOpenChange={setIsMentionOpen}>
                <SheetTrigger asChild>{MentionTriggerButton}</SheetTrigger>
                <SheetContent side="bottom" className="h-[90vh] p-0">
                  <SheetHeader className="p-4 border-b">
                    <SheetTitle>Mention Your Top Fans</SheetTitle>
                  </SheetHeader>
                  <div className="pt-4 flex-1">
                    {MentionContent}
                  </div>
                </SheetContent>
              </Sheet>
            ) : (
              <Dialog open={isMentionOpen} onOpenChange={setIsMentionOpen}>
                <DialogTrigger asChild>{MentionTriggerButton}</DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Mention Your Top Fans</DialogTitle>
                  </DialogHeader>
                  <div className="pt-4">
                    {MentionContent}
                  </div>
                </DialogContent>
              </Dialog>
            )}
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {topFans.length > 0 ? topFans.map(fan => (
              <div key={fan.id} className="flex items-center">
                <UserAvatar user={fan} />
                <div className="ml-3 flex-1">
                  <p className="font-semibold">{fan.name}</p>
                  <p className="text-sm text-muted-foreground">@{fan.username}</p>
                </div>
              </div>
            )) : <p className="text-sm text-muted-foreground text-center py-4">No top fans to show yet. Keep creating!</p>}
          </div>
        </CardContent>
      </Card>
  );
}
