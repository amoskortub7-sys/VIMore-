'use client';

import * as React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Eye, EyeOff, AlertCircle } from 'lucide-react';
import { VIMoreLogo } from '@/components/icons/logo';
import { account } from '@/lib/appwrite';
import { AppwriteException } from 'appwrite';
import { createUserDocument } from '@/services/userService';

export default function LoginPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [isLoading, setIsLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [showResend, setShowResend] = React.useState(false);
  const [showPassword, setShowPassword] = React.useState(false);

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setShowResend(false);

    try {
      await account.createEmailPasswordSession(email, password);
      
      toast({ title: 'Login Successful', description: 'Welcome back!' });
      // The AppShell will handle redirection for logged-in users.
      router.push('/'); // Force refresh
    } catch (error: any) {
      if (error instanceof AppwriteException) {
        if (error.code === 401 && error.message.includes('Please verify your email')) {
            setError("Please verify your email before logging in.");
            setShowResend(true);
        } else {
            setError(error.message);
        }
      } else {
        setError("An unknown error occurred.");
      }
      setPassword('');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendVerification = async () => {
    setIsLoading(true);
    try {
      const verificationUrl = `${window.location.origin}/verify-action`;
      await account.createVerification(verificationUrl);
      toast({ title: 'Verification Email Sent', description: 'Please check your inbox.' });
      setError("Verification email sent. Please check your inbox (and spam folder).");
    } catch (e: any) {
        setError(e.message || "Failed to resend verification email.");
    } finally {
        setIsLoading(false);
    }
  }
  
  return (
    <div className="flex min-h-screen w-full flex-col items-center justify-center bg-background p-4">
       <div className="w-full max-w-sm space-y-6">
            <div className="text-center">
                <VIMoreLogo className="mx-auto h-16 w-16 mb-4" />
                <h1 className="text-3xl font-bold">Log in to VIMore</h1>
            </div>

            <form onSubmit={handleEmailLogin} className="space-y-4">
                <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input 
                        id="email" 
                        type="email" 
                        placeholder="name@example.com" 
                        required 
                        value={email} 
                        onChange={(e) => setEmail(e.target.value)} 
                        autoComplete="username" 
                        disabled={isLoading}
                    />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <div className="relative">
                        <Input 
                            id="password" 
                            type={showPassword ? "text" : "password"} 
                            required 
                            value={password} 
                            onChange={(e) => setPassword(e.target.value)} 
                            autoComplete="current-password" 
                            disabled={isLoading}
                        />
                        <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute inset-y-0 right-0 flex items-center pr-3 text-muted-foreground">
                            {showPassword ? <EyeOff className="h-5 w-5"/> : <Eye className="h-5 w-5"/>}
                        </button>
                    </div>
                </div>
                {error && (
                    <div className="flex items-center gap-2 text-sm text-destructive">
                        <AlertCircle className="h-4 w-4" />
                        <p>{error}</p>
                    </div>
                )}
                 {showResend && (
                    <Button type="button" variant="link" className="p-0 h-auto" onClick={handleResendVerification}>
                        Resend verification email
                    </Button>
                )}
                <Button type="submit" className="w-full" disabled={isLoading || !email.trim() || !password.trim()}>
                    {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Log In
                </Button>
                <div className="text-center">
                    <Link href="/forgot-password" className="inline-block text-sm text-primary hover:underline">
                        Forgot Password?
                    </Link>
                </div>
            </form>
        </div>
        <footer className="absolute bottom-4 text-center text-sm w-full max-w-sm">
            <div className="w-full border-t pt-4">
                 Don't have an account?{' '}
                <Link href="/signup" className="font-semibold text-primary hover:underline">
                    Sign up
                </Link>
            </div>
        </footer>
    </div>
  );
}
