
'use client';

import * as React from 'react';
import {
  Users,
  BarChart3,
  FileText,
  Banknote,
  MoreHorizontal,
  XCircle,
  Clock,
  ArrowUp,
  ArrowDown,
  Loader2,
  Eye,
  Search,
  Calendar as CalendarIcon,
  ChevronDown,
  AlertTriangle,
  Award,
  Sparkles,
  UserPlus,
  Landmark,
  Edit,
  LifeBuoy,
  Send,
  ShieldAlert,
  ShieldCheck,
  UserCog,
  Trash2,
  Megaphone,
  Coins,
  Settings,
  Diamond,
  UploadCloud,
  X,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { type SupportTicket, Post } from '@/lib/data';
import type { User, Transaction, Badge as BadgeType, LinkPreview, PurchaseRequest, PayoutRequest, MobileMoneyAccount, CurrencyPackage } from '@/lib/data';
import { formatNumber, cn } from '@/lib/utils';
import { format, subDays, differenceInDays } from 'date-fns';
import { UserAvatar } from '@/components/user-avatar';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import Image from 'next/image';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { DateRange } from 'react-day-picker';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
// import { moderatePost, ModeratePostOutput } from '@/ai/flows/moderate-post-flow';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { PostCard } from '@/components/post-card';
import { Separator } from '@/components/ui/separator';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { getUsers, updateUser } from '@/services/userService';
import { getPosts, createPost } from '@/services/postService';
import { getMonetizationConfig, updateMonetizationConfig, getPaymentDetails, updatePaymentDetails, getPurchaseRequests, updatePurchaseRequestStatus, getPayoutRequests, updatePayoutRequestStatus, getTransactions } from '@/services/monetizationService';
import { getSupportTickets, resolveSupportTicket } from '@/services/supportService';
import { AppContext } from '@/components/app-shell';


export default function AdminDashboardPage() {
    const appContext = React.useContext(AppContext);
    const [allUsers, setAllUsers] = React.useState<User[]>([]);
    const [allPosts, setAllPosts] = React.useState<Post[]>([]);
    const [isLoading, setIsLoading] = React.useState(true);
    
    // Monetization States
    const [conversionRates, setConversionRates] = React.useState({ diamond: { USD: 0, LD: 0 }, gold: { USD: 0, LD: 0 }});
    const [goldPackages, setGoldPackages] = React.useState<CurrencyPackage[]>([]);
    const [diamondPackages, setDiamondPackages] = React.useState<CurrencyPackage[]>([]);
    const [paymentDetails, setPaymentDetails] = React.useState<{ orange: MobileMoneyAccount, mtn: MobileMoneyAccount, momoPSB: MobileMoneyAccount }>({ orange: { name: '', number: '' }, mtn: { name: '', number: '' }, momoPSB: { name: '', number: '' } });
    const [purchaseRequests, setPurchaseRequests] = React.useState<PurchaseRequest[]>([]);
    const [payoutRequests, setPayoutRequests] = React.useState<PayoutRequest[]>([]);
    const [transactions, setTransactions] = React.useState<Transaction[]>([]);
    const [supportTickets, setSupportTickets] = React.useState<SupportTicket[]>([]);


    React.useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            const [users, posts, config, payments, purchases, payouts, txs, tickets] = await Promise.all([
                getUsers(), 
                getPosts(),
                getMonetizationConfig(),
                getPaymentDetails(),
                getPurchaseRequests('all'),
                getPayoutRequests('all'),
                getTransactions(),
                getSupportTickets('all'),
            ]);
            setAllUsers(users);
            setAllPosts(posts);
            setConversionRates(config.conversionRates);
            setGoldPackages(config.goldPackages);
            setDiamondPackages(config.diamondPackages);
            setPaymentDetails(payments);
            setPurchaseRequests(purchases);
            setPayoutRequests(payouts);
            setTransactions(txs);
            setSupportTickets(tickets);
            setIsLoading(false);
        }
        fetchData();
    }, []);

    const [dateRange, setDateRange] = React.useState<DateRange | undefined>({
        from: subDays(new Date(), 29),
        to: new Date(),
    });
    
    const loggedInAdmin = allUsers.find(u => u.id === appContext?.currentUser?.id);
    const superAdmin = allUsers.find(u => u.isSuperAdmin); // Find the super admin
    
    const isAdminSuper = !!loggedInAdmin?.isSuperAdmin;
    const adminRole = isAdminSuper ? undefined : loggedInAdmin?.adminRole;

    const days = dateRange?.from && dateRange?.to 
            ? Math.max(differenceInDays(dateRange.to, dateRange.from) + 1, 1)
            : 30;
    
    const kpiData = React.useMemo(() => {
        const factor = days / 30;
        const totalRevenue = transactions.filter(t => t.price).reduce((sum, tx) => sum + parseFloat(tx.price?.replace('$', '').replace(' USD', '').replace(' LD', '') || '0'), 0);
        const newSubscriptions = allUsers.filter(u => u.subscriptions && u.subscriptions.length > 0).length;
        
        return {
            dailyActiveUsers: { value: Math.round(allUsers.filter(u => u.isOnline).length * factor), change: (Math.random() - 0.3) * 10 * (30/days) },
            newUsers: { value: Math.round(allUsers.length * factor), change: (Math.random() - 0.2) * 15 * (30/days) },
            totalPosts: { value: Math.round(allPosts.length * factor), change: (Math.random() - 0.5) * 5 * (30/days) },
            totalRevenue: { value: Math.round(totalRevenue * factor), change: (Math.random() - 0.4) * 20 * (30/days) },
            newSubscriptions: { value: Math.round(newSubscriptions * factor), change: (Math.random() - 0.4) * 18 * (30/days) },
        }
    }, [days, allUsers, allPosts, transactions]);
    
    const userGrowthData = React.useMemo(() => {
        if (!dateRange?.from || allUsers.length === 0) return [];
        
        const data = Array.from({ length: days }, (_, i) => {
            const date = subDays(new Date(), days - 1 - i);
            return {
                date: format(date, 'MMM d'),
                users: 0,
            };
        });

        let cumulativeUsers = 0;
        const sortedUsers = allUsers.sort((a,b) => a.createdAt.getTime() - b.createdAt.getTime());

        let userIndex = 0;
        for (let i = 0; i < data.length; i++) {
            const dayEnd = new Date(data[i].date);
            dayEnd.setHours(23, 59, 59, 999);

            while(userIndex < sortedUsers.length && sortedUsers[userIndex].createdAt <= dayEnd) {
                cumulativeUsers++;
                userIndex++;
            }
            data[i].users = cumulativeUsers;
        }

        return data;
    }, [days, allUsers, dateRange]);
    
    const periodLabel = `vs previous ${days} day${days > 1 ? 's' : ''}`;
    
    const platformLiability = React.useMemo(() => {
        const totalGold = allUsers.reduce((sum, user) => sum + (user.creatorBalance?.gold || 0), 0);
        const totalDiamonds = allUsers.reduce((sum, user) => sum + (user.creatorBalance?.diamonds || 0), 0);
        const goldValue = totalGold * (conversionRates?.gold?.USD || 0);
        const diamondValue = totalDiamonds * (conversionRates?.diamond?.USD || 0);
        return goldValue + diamondValue;
    }, [allUsers, conversionRates]);
    
    const tabs = [
        { value: 'overview', label: 'Overview', role: undefined },
        { value: 'monetization', label: 'Monetization', role: 'financial' },
        { value: 'moderation', label: 'Moderation', role: 'moderator' },
        { value: 'users', label: 'Users', role: undefined },
        { value: 'roles', label: 'Admin Roles', role: 'super' },
        { value: 'support', label: 'Support', role: undefined },
    ];
    
    const visibleTabs = tabs.filter(tab => {
        if (isAdminSuper) return true; // Super admin sees all
        if (tab.role === 'super') return false; // Hide super-only tabs from non-super
        if (!adminRole) return !tab.role; // Default view for users without a specific role (non-super)
        return tab.role === adminRole || !tab.role; // Role-specific view
    });
    
    const defaultTab = visibleTabs[0].value;
    
    if (isLoading || !loggedInAdmin) {
        return <div className="flex h-screen items-center justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>;
    }


  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="bg-background border-b p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-2xl font-bold">Platform Analyst Dashboard</h1>
        {(!adminRole || adminRole === undefined) && <DateRangePicker date={dateRange} onDateChange={setDateRange} />}
      </header>
      <main className="p-4 sm:p-6 space-y-6">
        <Tabs defaultValue={defaultTab}>
            <ScrollArea className="w-full whitespace-nowrap">
                <TabsList className="inline-flex">
                    {visibleTabs.map(tab => (
                       <TabsTrigger key={tab.value} value={tab.value}>{tab.label}</TabsTrigger>
                    ))}
                </TabsList>
                <ScrollBar orientation="horizontal" />
            </ScrollArea>
          
            {(!adminRole || adminRole === undefined) && (
                <TabsContent value="overview" className="mt-6 space-y-6">
                    <KpiGrid data={kpiData} periodLabel={periodLabel} platformLiability={platformLiability} />
                    <UserGrowthChart data={userGrowthData}/>
                </TabsContent>
            )}

            {(!adminRole || adminRole === 'financial') && (
                <TabsContent value="monetization" className="mt-6 space-y-6">
                    {(!adminRole) && (
                        <div className="grid gap-4 md:grid-cols-2">
                            <KpiCard title="Total Revenue" value={`$${formatNumber(kpiData.totalRevenue.value)}`} change={kpiData.totalRevenue.change} icon={Banknote} periodLabel={periodLabel}/>
                            <KpiCard title="New Subscribers" value={formatNumber(kpiData.newSubscriptions.value)} change={kpiData.newSubscriptions.change} icon={UserPlus} periodLabel={periodLabel}/>
                        </div>
                    )}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      <PendingPurchasesCard requests={purchaseRequests} setRequests={setPurchaseRequests} />
                      <PendingPayoutsCard requests={payoutRequests} setRequests={setPayoutRequests} />
                    </div>
                     {(!adminRole) && (
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                          <TransactionHistoryCard transactions={transactions} dateRange={dateRange}/>
                          {isAdminSuper && <PaymentDetailsCard paymentDetails={paymentDetails} setPaymentDetails={setPaymentDetails} />}
                        </div>
                     )}
                     {isAdminSuper && <MonetizationSettingsCard 
                        conversionRates={conversionRates} 
                        setConversionRates={setConversionRates} 
                        goldPackages={goldPackages}
                        setGoldPackages={setGoldPackages}
                        diamondPackages={diamondPackages}
                        setDiamondPackages={setDiamondPackages}
                      />}
                </TabsContent>
            )}

            {(!adminRole || adminRole === 'moderator') && (
                 <TabsContent value="moderation" className="mt-6 space-y-6">
                    <div className="flex justify-end">
                       <CreateSponsoredPostDialog />
                    </div>
                    <ContentModerationCard allPosts={allPosts} />
                </TabsContent>
            )}
            
            {(!adminRole || adminRole === undefined) && (
                <TabsContent value="users" className="mt-6 space-y-6">
                    <UserManagementCard allUsers={allUsers}/>
                </TabsContent>
            )}

            {isAdminSuper && (
                <TabsContent value="roles" className="mt-6 space-y-6">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <AdminRoleManager 
                            title="Financial Admins" 
                            description="These users can only view and manage monetization tasks."
                            role="financial"
                            users={allUsers}
                            setUsers={setAllUsers}
                            superAdminId={superAdmin?.id || ''}
                        />
                        <AdminRoleManager 
                            title="Moderation Admins"
                            description="These users can only view and manage content moderation tasks."
                            role="moderator"
                            users={allUsers}
                            setUsers={setAllUsers}
                            superAdminId={superAdmin?.id || ''}
                        />
                    </div>
                    <AnnouncementCard />
                </TabsContent>
            )}
            
             {(!adminRole || adminRole === undefined) && (
                <TabsContent value="support" className="mt-6 space-y-6">
                    <SupportTicketsCard tickets={supportTickets} setTickets={setSupportTickets} />
                </TabsContent>
             )}
        </Tabs>
      </main>
    </div>
  );
}

function KpiCard({ title, value, change, icon: Icon, periodLabel, description }: { title: string, value: string | number, change?: number, icon: React.ElementType, periodLabel?: string, description?: string }) {
    const isPositive = change !== undefined ? change >= 0 : undefined;
    return (
        <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{title}</CardTitle>
                <Icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{value}</div>
                {change !== undefined && periodLabel && (
                    <p className={cn("text-xs", isPositive ? "text-green-600" : "text-red-600")}>
                        <span className="flex items-center">
                            {isPositive ? <ArrowUp className="h-3 w-3 mr-1"/> : <ArrowDown className="h-3 w-3 mr-1"/>} {Math.abs(change).toFixed(1)}%
                        </span>
                        <span className="text-muted-foreground"> {periodLabel}</span>
                    </p>
                )}
                {description && <p className="text-xs text-muted-foreground">{description}</p>}
            </CardContent>
        </Card>
    )
}

function KpiGrid({ data, periodLabel, platformLiability }: { data: any, periodLabel: string, platformLiability: number }) {
    return (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
            <KpiCard title="Active Users" value={formatNumber(data.dailyActiveUsers.value)} change={data.dailyActiveUsers.change} icon={Users} periodLabel={periodLabel} />
            <KpiCard title="New Users" value={formatNumber(data.newUsers.value)} change={data.newUsers.change} icon={UserPlus} periodLabel={periodLabel}/>
            <KpiCard title="Total Posts" value={formatNumber(data.totalPosts.value)} change={data.totalPosts.change} icon={FileText} periodLabel={periodLabel}/>
            <KpiCard title="Revenue" value={`$${formatNumber(data.totalRevenue.value)}`} change={data.totalRevenue.change} icon={Banknote} periodLabel={periodLabel}/>
            <KpiCard title="Platform Liability" value={`$${formatNumber(platformLiability)}`} icon={Landmark} description="Total value of user balances"/>
        </div>
    )
}

function UserGrowthChart({ data }: { data: {date: string, users: number}[]}) {
    return (
        <Card>
            <CardHeader>
                <CardTitle>User Growth</CardTitle>
            </CardHeader>
            <CardContent className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={data}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" fontSize={10} tickLine={false} axisLine={false}/>
                        <YAxis fontSize={10} tickLine={false} axisLine={false} tickFormatter={(value) => formatNumber(value as number)} />
                        <Tooltip
                            contentStyle={{
                                background: 'hsl(var(--background))',
                                border: '1px solid hsl(var(--border))',
                                borderRadius: 'var(--radius)',
                            }}
                        />
                        <Line type="monotone" dataKey="users" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
                    </LineChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
    )
}

function PendingPurchasesCard({ requests, setRequests }: { requests: PurchaseRequest[], setRequests: React.Dispatch<React.SetStateAction<PurchaseRequest[]>> }) {
    const { toast } = useToast();
    const [searchTerm, setSearchTerm] = React.useState('');

    const handleAction = async (requestId: string, action: 'approved' | 'rejected') => {
        try {
            await updatePurchaseRequestStatus(requestId, action);
            setRequests(prev => prev.map(r => r.id === requestId ? { ...r, status: action } : r));
            const request = requests.find(r => r.id === requestId);
            toast({
                title: `Purchase ${action === 'approved' ? 'Approved' : 'Rejected'}`,
                description: `Request from @${request?.user.username} has been processed.`,
            });
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: 'Could not process the request.' });
        }
    }

    const filteredRequests = requests.filter(req => 
        (req.user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        req.user.username.toLowerCase().includes(searchTerm.toLowerCase())) &&
        req.status === 'pending'
    );

    return (
        <Card>
            <CardHeader>
                <CardTitle>Pending Currency Purchases</CardTitle>
                <CardDescription>Review and process manual currency purchases submitted by users.</CardDescription>
            </CardHeader>
            <CardContent>
                 <div className="relative mb-4">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input 
                        placeholder="Search by user..." 
                        className="pl-9"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>User</TableHead>
                            <TableHead>Package</TableHead>
                            <TableHead>Amount</TableHead>
                            <TableHead>Payment Proof</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {filteredRequests.map(req => (
                            <TableRow key={req.id}>
                                <TableCell>
                                    <div className="flex items-center gap-2">
                                        <UserAvatar user={req.user} className="h-8 w-8" />
                                        <div>
                                            <p className="font-medium">{req.user.name}</p>
                                            <p className="text-xs text-muted-foreground">@{req.user.username}</p>
                                        </div>
                                    </div>
                                </TableCell>
                                <TableCell>{req.transaction.package} {req.transaction.currency}</TableCell>
                                <TableCell>{req.transaction.price}</TableCell>
                                <TableCell>
                                    <ScreenshotDialog screenshotUrl={req.screenshot} transactionCode={req.transaction.transactionCode}>
                                        <Button variant="outline" size="sm" className="gap-2">
                                            <Eye className="h-4 w-4"/> View Proof
                                        </Button>
                                    </ScreenshotDialog>
                                </TableCell>
                                <TableCell className="text-right">
                                    <Button variant="ghost" size="sm" className="text-green-600 hover:text-green-700" onClick={() => handleAction(req.id, 'approved')}>Approve</Button>
                                    <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700" onClick={() => handleAction(req.id, 'rejected')}>Reject</Button>
                                </TableCell>
                            </TableRow>
                        ))}
                         {filteredRequests.length === 0 && (
                            <TableRow>
                                <TableCell colSpan={5} className="text-center h-24">No pending purchases.</TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    );
}

function PendingPayoutsCard({ requests, setRequests }: { requests: PayoutRequest[], setRequests: React.Dispatch<React.SetStateAction<PayoutRequest[]>> }) {
    const { toast } = useToast();
    const [searchTerm, setSearchTerm] = React.useState('');

    const handleAction = async (requestId: string, action: 'completed' | 'rejected') => {
        try {
            await updatePayoutRequestStatus(requestId, action);
            setRequests(prev => prev.map(r => r.id === requestId ? { ...r, status: action } : r));
            const request = requests.find(r => r.id === requestId);
            toast({
                title: `Payout ${action === 'completed' ? 'Approved' : 'Rejected'}`,
                description: `Payout for @${request?.user.username} has been processed.`,
            });
        } catch (error) {
             toast({ variant: 'destructive', title: 'Error', description: 'Could not process the request.' });
        }
    }

    const filteredRequests = requests.filter(req => 
        req.status === 'pending' &&
        (req.user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        req.user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
        req.accountNumber.includes(searchTerm))
    );

    return (
        <Card>
            <CardHeader>
                <CardTitle>Pending Payouts</CardTitle>
                <CardDescription>Review and process creator cash-out requests.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="relative mb-4">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input 
                        placeholder="Search by user or account number..." 
                        className="pl-9"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>User</TableHead>
                            <TableHead>Amount</TableHead>
                            <TableHead>Payout Method</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {filteredRequests.map(req => (
                             <TableRow key={req.id}>
                                <TableCell>
                                    <div className="flex items-center gap-2">
                                        <UserAvatar user={req.user} className="h-8 w-8" />
                                        <div>
                                            <p className="font-medium">{req.user.name}</p>
                                            <p className="text-xs text-muted-foreground">@{req.user.username}</p>
                                        </div>
                                    </div>
                                </TableCell>
                                <TableCell>
                                    <p className="font-medium">{req.currency === 'USD' ? '$' : ''}{formatNumber(req.amount)} {req.currency}</p>
                                    <p className="text-xs text-muted-foreground">from {req.platformCurrency}</p>
                                </TableCell>
                                <TableCell>
                                    <p className="font-medium capitalize">{req.provider} Money</p>
                                    <p className="text-xs text-muted-foreground">{req.accountName} - {req.accountNumber}</p>
                                </TableCell>
                                <TableCell>{format(new Date(req.timestamp), 'MMM d, yyyy')}</TableCell>
                                <TableCell className="text-right">
                                    <Button variant="ghost" size="sm" className="text-green-600 hover:text-green-700" onClick={() => handleAction(req.id, 'completed')}>Approve</Button>
                                    <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700" onClick={() => handleAction(req.id, 'rejected')}>Reject</Button>
                                </TableCell>
                            </TableRow>
                        ))}
                        {filteredRequests.length === 0 && (
                            <TableRow>
                                <TableCell colSpan={5} className="text-center h-24">No pending payouts.</TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    );
}

function TransactionHistoryCard({ transactions, dateRange }: { transactions: Transaction[], dateRange?: DateRange }) {
    const [searchTerm, setSearchTerm] = React.useState('');

    const history = React.useMemo(() => {
        if (!transactions) return [];
        return transactions.filter(tx => {
            const txDate = new Date(tx.date);
            const isInDateRange = !dateRange?.from || !dateRange?.to || (txDate >= dateRange.from && txDate <= dateRange.to);
            const matchesSearch = !searchTerm || tx.transactionCode?.toLowerCase().includes(searchTerm.toLowerCase());
            return isInDateRange && matchesSearch;
        })
    }, [dateRange, searchTerm, transactions]);

  const getStatusBadge = (status: Transaction['status']) => {
        switch (status) {
            case 'Completed': return <Badge variant="success">Completed</Badge>;
            case 'Pending': return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300">Pending</Badge>;
            case 'Rejected': return <Badge variant="destructive">Rejected</Badge>;
            default: return <Badge variant="secondary">{status}</Badge>;
        }
    }

  return (
    <Card>
        <CardHeader>
            <CardTitle>Transaction History</CardTitle>
            <CardDescription>A log of all completed and rejected financial transactions.</CardDescription>
        </CardHeader>
        <CardContent>
             <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                    placeholder="Search by transaction ID..." 
                    className="pl-9"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Transaction ID</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Status</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {history.map(tx => (
                        <TableRow key={tx.id}>
                            <TableCell className="font-mono text-xs">{tx.transactionCode}</TableCell>
                            <TableCell>{format(new Date(tx.date), 'MMM d, yyyy')}</TableCell>
                            <TableCell>{tx.package}</TableCell>
                            <TableCell>{tx.price}</TableCell>
                            <TableCell>{getStatusBadge(tx.status)}</TableCell>
                        </TableRow>
                    ))}
                     {history.length === 0 && (
                        <TableRow>
                            <TableCell colSpan={5} className="text-center h-24">No transactions found.</TableCell>
                        </TableRow>
                    )}
                </TableBody>
            </Table>
        </CardContent>
    </Card>
  )
}

function UserManagementCard({ allUsers }: { allUsers: User[] }) {
    const { toast } = useToast();
    const [searchTerm, setSearchTerm] = React.useState('');
    const totalUsers = allUsers.length;

    const handleAction = (user: User, action: 'suspend' | 'ban') => {
        toast({
            title: `User ${action === 'suspend' ? 'Suspended' : 'Banned'}`,
            description: `@${user.username} has been ${action === 'suspend' ? 'suspended' : 'banned'}.`,
            variant: 'destructive'
        });
    }

    const filteredUsers = allUsers.filter(user => 
        user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.username.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <Card>
            <CardHeader>
                <CardTitle>User Management</CardTitle>
                <CardDescription>Search, view, and manage all {formatNumber(totalUsers)} users on the platform.</CardDescription>
            </CardHeader>
            <CardContent>
                 <div className="relative mb-4">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input 
                        placeholder="Search by name or username..." 
                        className="pl-9"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>User</TableHead>
                            <TableHead>Followers</TableHead>
                            <TableHead>Joined</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {filteredUsers.map(user => (
                            <TableRow key={user.id}>
                                <TableCell>
                                    <div className="flex items-center gap-2">
                                        <UserAvatar user={user} className="h-8 w-8" />
                                        <div>
                                            <p className="font-medium">{user.name}</p>
                                            <p className="text-xs text-muted-foreground">@{user.username}</p>
                                        </div>
                                    </div>
                                </TableCell>
                                <TableCell>{formatNumber(user.followers)}</TableCell>
                                <TableCell>{format(new Date(user.createdAt), 'MMM d, yyyy')}</TableCell>
                                <TableCell className="text-right">
                                    <DropdownMenu>
                                        <DropdownMenuTrigger asChild>
                                            <Button variant="ghost" size="icon" className="h-8 w-8">
                                                <MoreHorizontal className="h-4 w-4" />
                                            </Button>
                                        </DropdownMenuTrigger>
                                        <DropdownMenuContent>
                                            <UserDetailsDialog user={user}>
                                                <DropdownMenuItem onSelect={(e) => e.preventDefault()}>View Details</DropdownMenuItem>
                                            </UserDetailsDialog>
                                            <DropdownMenuItem onClick={() => handleAction(user, 'suspend')}>
                                                <AlertTriangle className="mr-2 h-4 w-4"/> Suspend User
                                            </DropdownMenuItem>
                                            <DropdownMenuItem className="text-destructive" onClick={() => handleAction(user, 'ban')}>
                                                <XCircle className="mr-2 h-4 w-4"/> Ban User
                                            </DropdownMenuItem>
                                        </DropdownMenuContent>
                                    </DropdownMenu>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    );
}

function ScreenshotDialog({ children, screenshotUrl, transactionCode }: { children: React.ReactNode, screenshotUrl: string, transactionCode?: string }) {
    return (
        <Dialog>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent className="max-w-lg">
                <DialogHeader>
                    <DialogTitle>Payment Screenshot</DialogTitle>
                    <DialogDescription>
                        Manually verify the transaction code against the user's payment proof.
                    </DialogDescription>
                </DialogHeader>

                <Alert>
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Required Code</AlertTitle>
                    <AlertDescription>
                        Please confirm the code below is visible in the screenshot's reference/note section.
                        <div className="mt-2 font-mono text-lg font-bold p-2 bg-secondary rounded-md text-center">
                            {transactionCode}
                        </div>
                    </AlertDescription>
                </Alert>

                <div className="mt-4 rounded-lg overflow-hidden border">
                    <Image src={screenshotUrl} alt="Payment Screenshot" width={600} height={800} className="w-full h-auto" />
                </div>
            </DialogContent>
        </Dialog>
    )
}

function UserDetailsDialog({ user }: { user: User }) {
    const [topPosts, setTopPosts] = React.useState<Post[]>([]);

    React.useEffect(() => {
        const fetchPosts = async () => {
            const allPosts = await getPosts();
            const userPosts = allPosts.filter(p => p.author.id === user.id)
                .sort((a, b) => ((a.reactions?.length || 0) + a.comments.length) - ((a.reactions?.length || 0) + a.comments.length))
                .slice(0, 3);
            setTopPosts(userPosts);
        };
        fetchPosts();
    }, [user.id]);
    
    return (
        <Dialog>
            <DialogTrigger asChild><div/></DialogTrigger> {/* This is a placeholder; trigger is in parent */}
            <DialogContent className="max-w-2xl">
                 <DialogHeader>
                    <DialogTitle>User Details</DialogTitle>
                </DialogHeader>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                    <div>
                        <div className="flex items-center gap-4">
                            <UserAvatar user={user} className="h-16 w-16" />
                            <div>
                                <h3 className="text-xl font-bold">{user.name}</h3>
                                <p className="text-muted-foreground">@{user.username}</p>
                            </div>
                        </div>
                        <Separator className="my-4"/>
                        <div className="space-y-2 text-sm">
                            <p><strong>Followers:</strong> {formatNumber(user.followers)}</p>
                            <p><strong>Following:</strong> {formatNumber(user.following)}</p>
                            <p><strong>Joined:</strong> {format(new Date(user.createdAt), 'MMM d, yyyy')}</p>
                             <p><strong>Bio:</strong> {user.bio}</p>
                        </div>
                         <Separator className="my-4"/>
                         <h4 className="font-semibold mb-2">Badges</h4>
                    </div>
                    <div>
                         <h4 className="font-semibold mb-2">Top Posts</h4>
                         <div className="space-y-2">
                            {topPosts.map(post => (
                                <Card key={post.id} className="p-2">
                                    <p className="text-xs truncate">{post.content}</p>
                                    <div className="flex justify-end gap-2 text-xs text-muted-foreground mt-1">
                                        <span>❤️ {formatNumber(post.reactions?.length || 0)}</span>
                                        <span>💬 {formatNumber(post.comments.length)}</span>
                                    </div>
                                </Card>
                            ))}
                         </div>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}

function DateRangePicker({ className, date, onDateChange }: { className?: string, date?: DateRange, onDateChange: (date?: DateRange) => void }) {
  return (
    <div className={cn("grid gap-2", className)}>
      <Popover>
        <PopoverTrigger asChild>
          <Button
            id="date"
            variant={"outline"}
            className={cn(
              "w-[300px] justify-start text-left font-normal",
              !date && "text-muted-foreground"
            )}
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            {date?.from ? (
              date.to ? (
                <>
                  {format(date.from, "LLL dd, y")} -{" "}
                  {format(date.to, "LLL dd, y")}
                </>
              ) : (
                format(date.from, "LLL dd, y")
              )
            ) : (
              <span>Pick a date</span>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="end">
          <Calendar
            initialFocus
            mode="range"
            defaultMonth={date?.from}
            selected={date}
            onSelect={onDateChange}
            numberOfMonths={2}
          />
        </PopoverContent>
      </Popover>
    </div>
  )
}

function PaymentDetailsCard({ paymentDetails, setPaymentDetails }: { paymentDetails: { orange: MobileMoneyAccount, mtn: MobileMoneyAccount, momoPSB: MobileMoneyAccount }, setPaymentDetails: React.Dispatch<React.SetStateAction<{ orange: MobileMoneyAccount, mtn: MobileMoneyAccount, momoPSB: MobileMoneyAccount }>> }) {
  const { toast } = useToast();
  
  const handleSave = async (updatedDetails: { orange: MobileMoneyAccount, mtn: MobileMoneyAccount, momoPSB: MobileMoneyAccount }) => {
    try {
        await updatePaymentDetails(updatedDetails);
        setPaymentDetails(updatedDetails);
        toast({ title: "Payment details updated successfully!"});
    } catch (e) {
        toast({ variant: 'destructive', title: 'Error', description: 'Could not update payment details.'});
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Payout Account Details</CardTitle>
        <CardDescription>Manage the mobile money accounts used for currency purchases.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between p-3 rounded-md bg-secondary">
          <div>
            <p className="font-semibold text-orange-500">Orange Money (Liberia)</p>
            <p className="text-sm">{paymentDetails.orange.name} - {paymentDetails.orange.number}</p>
          </div>
          <EditPaymentDialog provider="orange" details={paymentDetails} onSave={handleSave}>
            <Button variant="ghost" size="icon"><Edit className="h-4 w-4" /></Button>
          </EditPaymentDialog>
        </div>
        <div className="flex items-center justify-between p-3 rounded-md bg-secondary">
          <div>
            <p className="font-semibold text-yellow-500">Lonestar Cell MTN Momo</p>
            <p className="text-sm">{paymentDetails.mtn.name} - {paymentDetails.mtn.number}</p>
          </div>
          <EditPaymentDialog provider="mtn" details={paymentDetails} onSave={handleSave}>
            <Button variant="ghost" size="icon"><Edit className="h-4 w-4" /></Button>
          </EditPaymentDialog>
        </div>
        <div className="flex items-center justify-between p-3 rounded-md bg-secondary">
          <div>
            <p className="font-semibold text-green-500">Momo PSB (Nigeria)</p>
            <p className="text-sm">{paymentDetails.momoPSB.name} - {paymentDetails.momoPSB.number}</p>
          </div>
          <EditPaymentDialog provider="momoPSB" details={paymentDetails} onSave={handleSave}>
            <Button variant="ghost" size="icon"><Edit className="h-4 w-4" /></Button>
          </EditPaymentDialog>
        </div>
      </CardContent>
    </Card>
  )
}

function EditPaymentDialog({ children, provider, details, onSave }: { children: React.ReactNode, provider: 'orange' | 'mtn' | 'momoPSB', details: any, onSave: (details: any) => void }) {
  const [name, setName] = React.useState(details[provider]?.name || '');
  const [number, setNumber] = React.useState(details[provider]?.number || '');
  const [isOpen, setIsOpen] = React.useState(false);

  const providerNames = {
    orange: 'Orange Money (Liberia)',
    mtn: 'Lonestar Cell MTN Momo',
    momoPSB: 'Momo PSB (Nigeria)'
  }

  const handleSave = () => {
    const updatedDetails = {
      ...details,
      [provider]: { name, number }
    };
    onSave(updatedDetails);
    setIsOpen(false);
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit {providerNames[provider]} Details</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="accountName">Account Name</Label>
            <Input id="accountName" value={name} onChange={e => setName(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="accountNumber">Account Number</Label>
            <Input id="accountNumber" value={number} onChange={e => setNumber(e.target.value)} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setIsOpen(false)}>Cancel</Button>
          <Button onClick={handleSave}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function SupportTicketsCard({ tickets, setTickets }: { tickets: SupportTicket[], setTickets: React.Dispatch<React.SetStateAction<SupportTicket[]>> }) {
  const { toast } = useToast();

  const openTickets = tickets.filter(t => t.status === 'open');
  const resolvedTickets = tickets.filter(t => t.status === 'resolved');

  const handleResolve = async (ticketId: string, response: string) => {
    try {
        await resolveSupportTicket(ticketId, response);
        setTickets(prev => prev.map(t => t.id === ticketId ? { ...t, status: 'resolved', response, resolvedAt: new Date() } : t));
        const ticket = tickets.find(t => t.id === ticketId);
        toast({ title: "Response Sent", description: `Your response has been sent to @${ticket?.user.username}`});
    } catch(e) {
        toast({ variant: 'destructive', title: 'Error', description: 'Could not resolve ticket.'});
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Support Tickets</CardTitle>
        <CardDescription>Respond to user-submitted help requests.</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="open">
          <TabsList>
            <TabsTrigger value="open">Open ({openTickets.length})</TabsTrigger>
            <TabsTrigger value="resolved">Resolved ({resolvedTickets.length})</TabsTrigger>
          </TabsList>
          <TabsContent value="open" className="mt-4">
            {openTickets.length > 0 ? (
              openTickets.map(ticket => <SupportTicketItem key={ticket.id} ticket={ticket} onResolve={handleResolve} />)
            ) : (
              <p className="text-center text-muted-foreground py-8">No open tickets.</p>
            )}
          </TabsContent>
          <TabsContent value="resolved" className="mt-4">
            {resolvedTickets.length > 0 ? (
              resolvedTickets.map(ticket => <SupportTicketItem key={ticket.id} ticket={ticket} onResolve={handleResolve} />)
            ) : (
              <p className="text-center text-muted-foreground py-8">No resolved tickets.</p>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

function SupportTicketItem({ ticket, onResolve }: { ticket: SupportTicket, onResolve: (id: string, response: string) => void }) {
  const [response, setResponse] = React.useState('');

  return (
    <Card className="mb-4">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg">{ticket.subject}</CardTitle>
            <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
              <UserAvatar user={ticket.user} className="h-6 w-6"/>
              <span>@{ticket.user.username}</span>
              <span>•</span>
              <span>{format(new Date(ticket.timestamp), 'PPp')}</span>
            </div>
          </div>
           <Badge variant={ticket.status === 'open' ? 'destructive' : 'secondary'}>{ticket.status}</Badge>
        </div>
      </CardHeader>
      <CardContent>
        <p className="whitespace-pre-wrap p-3 bg-secondary rounded-md">{ticket.message}</p>
        {ticket.status === 'open' ? (
          <div className="mt-4 space-y-2">
            <Label htmlFor={`response-${ticket.id}`}>Your Response</Label>
            <Textarea
              id={`response-${ticket.id}`}
              placeholder="Type your response here..."
              value={response}
              onChange={e => setResponse(e.target.value)}
            />
            <Button onClick={() => onResolve(ticket.id, response)} disabled={!response.trim()} size="sm">
              <Send className="mr-2 h-4 w-4"/> Send & Resolve
            </Button>
          </div>
        ) : (
          <div className="mt-4 border-l-2 pl-4">
            <p className="text-sm font-semibold">Your response:</p>
            <p className="text-sm text-muted-foreground italic whitespace-pre-wrap">"{ticket.response}"</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}


function ContentModerationCard({ allPosts }: { allPosts: Post[] }) {
    const { toast } = useToast();
    const [flaggedPosts, setFlaggedPosts] = React.useState<(Post & { moderationResult: any })[]>([]);
    const [isLoading, setIsLoading] = React.useState(false);
    
    const scanPosts = async () => {
        setIsLoading(true);
        // AI call is disabled.
        toast({
          variant: 'destructive',
          title: 'AI Moderation Disabled',
          description: 'This feature is temporarily unavailable.',
        });
        setFlaggedPosts([]);
        setIsLoading(false);
    };

    const handleAction = (postId: string, action: 'ignore' | 'remove') => {
        setFlaggedPosts(prev => prev.filter(p => p.id !== postId));
        const post = flaggedPosts.find(p => p.id === postId);
        toast({
            title: `Post ${action === 'ignore' ? 'Ignored' : 'Removed'}`,
            description: `Post by @${post?.author.username} has been processed.`,
        });
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle>AI Content Moderation</CardTitle>
                <CardDescription>Review posts automatically flagged by AI for potential community guideline violations.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="flex flex-wrap gap-2 mb-4">
                    <Button onClick={scanPosts} disabled={isLoading}>
                        {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <ShieldAlert className="mr-2 h-4 w-4"/>}
                        {isLoading ? 'Scanning...' : 'Scan All Posts'}
                    </Button>
                </div>
                
                 {isLoading ? (
                    <div className="text-center p-8"><Loader2 className="h-8 w-8 animate-spin mx-auto"/></div>
                ) : flaggedPosts.length > 0 ? (
                    <div className="space-y-4">
                        {flaggedPosts.map(post => (
                             <Card key={post.id} className="bg-secondary">
                                <CardHeader>
                                    <AlertTitle className="flex items-center gap-2 text-destructive"><AlertTriangle/> Potential Violation: {post.moderationResult.reason}</AlertTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-xs text-muted-foreground">Post by @{post.author.username}</p>
                                    <p className="italic border-l-4 pl-3 mt-2">"{post.content}"</p>
                                </CardContent>
                                <CardContent className="flex justify-end gap-2">
                                     <Button variant="ghost" size="sm" onClick={() => handleAction(post.id, 'ignore')}>Ignore</Button>
                                     <Button variant="destructive" size="sm" onClick={() => handleAction(post.id, 'remove')}>Remove Post</Button>
                                </CardContent>
                             </Card>
                        ))}
                    </div>
                ) : (
                    <p className="text-center text-muted-foreground py-8">No flagged posts to review. Run a scan to check for violations.</p>
                )}
            </CardContent>
        </Card>
    )
}

function AdminRoleManager({ title, description, role, users, setUsers, superAdminId }: { title: string, description: string, role: 'financial' | 'moderator', users: User[], setUsers: React.Dispatch<React.SetStateAction<User[]>>, superAdminId: string }) {
    const { toast } = useToast();
    const currentAdmins = users.filter(u => u.adminRole === role);

    const handleRemoveAdmin = async (userId: string) => {
        try {
            // Remove admin role and verification status
            await updateUser(userId, { adminRole: undefined, isVerified: false });
            setUsers(prevUsers => prevUsers.map(u => u.id === userId ? { ...u, adminRole: undefined, isVerified: false } : u));
            const user = users.find(u => u.id === userId);
            toast({ title: "Admin Removed", description: `${user?.name} is no longer a ${role} admin.` });
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: 'Could not remove admin role.' });
        }
    };

    const handleAddAdmins = async (newAdmins: User[]) => {
        try {
            // Grant admin role and free verification
            await Promise.all(newAdmins.map(admin => updateUser(admin.id, { adminRole: role, isVerified: true })));
            setUsers(prevUsers => prevUsers.map(u => newAdmins.find(na => na.id === u.id) ? { ...u, adminRole: role, isVerified: true } : u));
            toast({ title: "Admin(s) Added", description: `${newAdmins.length} user(s) have been granted ${role} privileges and a verification badge.` });
        } catch (error) {
             toast({ variant: 'destructive', title: 'Error', description: 'Could not add admin roles.' });
        }
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    {role === 'financial' ? <Banknote/> : <ShieldCheck />}
                    {title}
                </CardTitle>
                <CardDescription>{description}</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                    {currentAdmins.map(admin => (
                        <div key={admin.id} className="flex items-center p-3 rounded-md bg-secondary">
                            <UserAvatar user={admin} className="h-8 w-8 mr-3"/>
                            <div className="flex-1">
                                <p className="font-semibold">{admin.name}</p>
                                <p className="text-xs text-muted-foreground">@{admin.username}</p>
                            </div>
                            <Button variant="ghost" size="icon" onClick={() => handleRemoveAdmin(admin.id)}>
                                <Trash2 className="h-4 w-4 text-destructive"/>
                            </Button>
                        </div>
                    ))}
                     {currentAdmins.length === 0 && (
                        <p className="text-center text-sm text-muted-foreground py-4">No {role} admins assigned.</p>
                     )}
                     <AddAdminDialog 
                        role={role}
                        onAddAdmins={handleAddAdmins}
                        allUsers={users}
                        superAdminId={superAdminId}
                     >
                        <Button variant="outline" className="w-full">
                            <UserPlus className="mr-2 h-4 w-4"/> Add {role.charAt(0).toUpperCase() + role.slice(1)} Admin
                        </Button>
                    </AddAdminDialog>
                </div>
            </CardContent>
        </Card>
    );
}

function AddAdminDialog({ children, role, onAddAdmins, allUsers, superAdminId }: { children: React.ReactNode, role: 'financial' | 'moderator', onAddAdmins: (newAdmins: User[]) => void, allUsers: User[], superAdminId: string }) {
    const [isOpen, setIsOpen] = React.useState(false);
    const [selectedUsers, setSelectedUsers] = React.useState<User[]>([]);
    const [searchQuery, setSearchQuery] = React.useState('');
    const { toast } = useToast();
    
    const MAX_ADMINS = 5;

    // Users who are not the super admin and not already an admin of any type
    const eligibleUsers = React.useMemo(() => {
        return allUsers.filter(u => u.id !== superAdminId && !u.adminRole);
    }, [allUsers, superAdminId]);
    
    const filteredUsers = eligibleUsers.filter(u => 
        u.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        u.username.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const handleSelectUser = (user: User) => {
        const isSelected = selectedUsers.some(su => su.id === user.id);
        if (isSelected) {
            setSelectedUsers(prev => prev.filter(su => su.id !== user.id));
        } else {
            const currentAdminCount = allUsers.filter(u => u.adminRole === role).length;
            if (currentAdminCount + selectedUsers.length >= MAX_ADMINS) {
                toast({ variant: 'destructive', title: `You can only have up to ${MAX_ADMINS} ${role} admins.` });
                return;
            }
            setSelectedUsers(prev => [...prev, user]);
        }
    };
    
    const handleSave = () => {
        onAddAdmins(selectedUsers);
        setIsOpen(false);
        setSelectedUsers([]);
        setSearchQuery('');
    };

    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Add {role.charAt(0).toUpperCase() + role.slice(1)} Admins</DialogTitle>
                    <DialogDescription>Select users to grant administrative privileges.</DialogDescription>
                </DialogHeader>
                <div className="relative my-2">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input 
                        placeholder="Search for users..." 
                        className="pl-9"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </div>
                <ScrollArea className="h-72">
                    <div className="space-y-2 pr-4">
                        {filteredUsers.map(user => (
                            <div key={user.id} className="flex items-center p-2 rounded-md hover:bg-accent" onClick={() => handleSelectUser(user)}>
                                <Checkbox 
                                    id={`user-select-${user.id}`}
                                    checked={selectedUsers.some(su => su.id === user.id)}
                                    className="mr-3"
                                />
                                <label htmlFor={`user-select-${user.id}`} className="flex items-center gap-3 cursor-pointer flex-1">
                                    <UserAvatar user={user} />
                                    <div>
                                        <p className="font-semibold">{user.name}</p>
                                        <p className="text-xs text-muted-foreground">@{user.username}</p>
                                    </div>
                                </label>
                            </div>
                        ))}
                        {filteredUsers.length === 0 && <p className="text-center text-sm text-muted-foreground py-8">No eligible users found.</p>}
                    </div>
                </ScrollArea>
                <DialogFooter>
                    <Button variant="ghost" onClick={() => setIsOpen(false)}>Cancel</Button>
                    <Button onClick={handleSave} disabled={selectedUsers.length === 0}>
                        Add {selectedUsers.length > 0 ? selectedUsers.length : ''} Admin(s)
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

// --- Monetization Settings ---

function MonetizationSettingsCard({ conversionRates, setConversionRates, goldPackages, setGoldPackages, diamondPackages, setDiamondPackages }: { conversionRates: any, setConversionRates: Function, goldPackages: CurrencyPackage[], setGoldPackages: Function, diamondPackages: CurrencyPackage[], setDiamondPackages: Function }) {
  const { toast } = useToast();
  
  const handleConfigSave = async (data: any) => {
    try {
        await updateMonetizationConfig(data);
        if(data.conversionRates) setConversionRates(data.conversionRates);
        if(data.goldPackages) setGoldPackages(data.goldPackages);
        if(data.diamondPackages) setDiamondPackages(data.diamondPackages);
        toast({ title: 'Settings saved successfully!'});
    } catch (error) {
        toast({ variant: 'destructive', title: 'Error saving settings' });
    }
  }

  return (
    <Card className="col-span-full">
        <CardHeader>
            <CardTitle className="flex items-center gap-2"><Settings/> Monetization Settings</CardTitle>
            <CardDescription>Manage platform-wide currency conversion rates and package pricing.</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
           <Card>
                <CardHeader className="flex-row items-center justify-between">
                    <CardTitle className="text-base">Conversion Rates</CardTitle>
                     <EditConversionRatesDialog onSave={(newRates) => handleConfigSave({ conversionRates: newRates })} rates={conversionRates}>
                         <Button variant="outline" size="sm"><Edit className="mr-2 h-4 w-4"/>Edit</Button>
                    </EditConversionRatesDialog>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                    <p>1 💎 = <strong>${conversionRates.diamond.USD.toFixed(2)} USD</strong> / <strong>{conversionRates.diamond.LD} LD</strong></p>
                    <p>1 🪙 = <strong>${conversionRates.gold.USD.toFixed(2)} USD</strong> / <strong>{conversionRates.gold.LD} LD</strong></p>
                </CardContent>
           </Card>
           <Card>
                <CardHeader>
                    <CardTitle className="text-base">Currency Packages</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                   {goldPackages.map(p => <PackagePriceItem key={p.id} pkg={p} onSave={(pkg) => handleConfigSave({ goldPackages: goldPackages.map(gp => gp.id === pkg.id ? pkg : gp) })} />)}
                   {diamondPackages.map(p => <PackagePriceItem key={p.id} pkg={p} onSave={(pkg) => handleConfigSave({ diamondPackages: diamondPackages.map(dp => dp.id === pkg.id ? pkg : dp) })} />)}
                </CardContent>
           </Card>
        </CardContent>
    </Card>
  )
}

function PackagePriceItem({ pkg, onSave }: { pkg: CurrencyPackage, onSave: (p: CurrencyPackage) => void }) {
    return (
        <div className="flex items-center justify-between p-2 rounded-md bg-secondary">
          <div className="flex items-center gap-2">
            {pkg.id.startsWith('gold') ? <Coins/> : <Diamond/>}
            <p className="font-semibold">{pkg.name} ({pkg.amount})</p>
          </div>
          <div className="flex items-center gap-2">
            <p className="text-sm text-muted-foreground">{pkg.prices.map(p => p.display).join(' / ')}</p>
            <EditPackageDialog pkg={pkg} onSave={onSave}>
                <Button variant="ghost" size="icon"><Edit className="h-4 w-4" /></Button>
            </EditPackageDialog>
          </div>
        </div>
    )
}

function EditConversionRatesDialog({ children, rates, onSave }: { children: React.ReactNode, rates: any, onSave: (r: any) => void }) {
    const [diamondUsd, setDiamondUsd] = React.useState(rates.diamond.USD);
    const [diamondLd, setDiamondLd] = React.useState(rates.diamond.LD);
    const [goldUsd, setGoldUsd] = React.useState(rates.gold.USD);
    const [goldLd, setGoldLd] = React.useState(rates.gold.LD);
    const [isOpen, setIsOpen] = React.useState(false);

    const handleSave = () => {
        const newRates = {
            diamond: { USD: diamondUsd, LD: diamondLd },
            gold: { USD: goldUsd, LD: goldLd },
        };
        onSave(newRates);
        setIsOpen(false);
    }
    
    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent>
                <DialogHeader><DialogTitle>Edit Conversion Rates</DialogTitle></DialogHeader>
                <div className="py-4 space-y-4">
                    <fieldset className="border p-4 rounded-lg">
                        <legend className="px-2 font-semibold">Diamond (💎)</legend>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="diamondUsd">USD Value</Label>
                                <Input id="diamondUsd" type="number" value={diamondUsd} onChange={e => setDiamondUsd(parseFloat(e.target.value))} step="0.01"/>
                            </div>
                             <div className="space-y-2">
                                <Label htmlFor="diamondLd">LD Value</Label>
                                <Input id="diamondLd" type="number" value={diamondLd} onChange={e => setDiamondLd(parseFloat(e.target.value))} step="1"/>
                            </div>
                        </div>
                    </fieldset>
                    <fieldset className="border p-4 rounded-lg">
                        <legend className="px-2 font-semibold">Gold (🪙)</legend>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="goldUsd">USD Value</Label>
                                <Input id="goldUsd" type="number" value={goldUsd} onChange={e => setGoldUsd(parseFloat(e.target.value))} step="0.01"/>
                            </div>
                             <div className="space-y-2">
                                <Label htmlFor="goldLd">LD Value</Label>
                                <Input id="goldLd" type="number" value={goldLd} onChange={e => setGoldLd(parseFloat(e.target.value))} step="0.1"/>
                            </div>
                        </div>
                    </fieldset>
                </div>
                 <DialogFooter>
                    <Button variant="outline" onClick={() => setIsOpen(false)}>Cancel</Button>
                    <Button onClick={handleSave}>Save Changes</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    )
}

function EditPackageDialog({ children, pkg, onSave }: { children: React.ReactNode, pkg: CurrencyPackage, onSave: (p: CurrencyPackage) => void }) {
    const [prices, setPrices] = React.useState(pkg.prices);
    const [isOpen, setIsOpen] = React.useState(false);
    
    const handlePriceChange = (currency: 'USD' | 'LD', value: string) => {
        const newPrices = [...prices];
        const priceIndex = newPrices.findIndex(p => p.currency === currency);
        if (priceIndex > -1) {
            newPrices[priceIndex].value = parseFloat(value);
            newPrices[priceIndex].display = `${currency === 'USD' ? '$' : ''}${parseFloat(value).toLocaleString()}${currency === 'USD' ? ' USD' : ' LD'}`;
        }
        setPrices(newPrices);
    }
    
    const handleSave = () => {
        onSave({ ...pkg, prices });
        setIsOpen(false);
    }

    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent>
                 <DialogHeader>
                    <DialogTitle>Edit {pkg.name} Package</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                    {prices.map(price => (
                         <div key={price.currency} className="space-y-2">
                            <Label htmlFor={`price-${price.currency}`}>Price in {price.currency}</Label>
                            <Input id={`price-${price.currency}`} type="number" value={price.value} onChange={e => handlePriceChange(price.currency, e.target.value)} />
                        </div>
                    ))}
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => setIsOpen(false)}>Cancel</Button>
                    <Button onClick={handleSave}>Save Changes</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    )
}

function AnnouncementCard() {
    const { toast } = useToast();
    const [message, setMessage] = React.useState('');
    const [target, setTarget] = React.useState('all');

    const handleSend = () => {
        if (!message.trim()) {
            toast({ variant: 'destructive', title: 'Message cannot be empty.' });
            return;
        }
        // In a real app, this would trigger a backend function.
        // For now, we just show a toast.
        toast({
            title: 'Announcement Sent!',
            description: `Your message has been sent to: ${target}`,
        });
        setMessage('');
        setTarget('all');
    }

    return (
        <Card className="col-span-full">
            <CardHeader>
                <CardTitle className="flex items-center gap-2"><Megaphone/> Announcement Center</CardTitle>
                <CardDescription>Send notifications to a targeted group of users.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="space-y-2">
                    <Label htmlFor="announcement-message">Message</Label>
                    <Textarea 
                        id="announcement-message"
                        placeholder="Type your notification message here..."
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        rows={4}
                    />
                </div>
                 <div className="space-y-2">
                    <Label htmlFor="announcement-target">Target Audience</Label>
                     <Select value={target} onValueChange={setTarget}>
                        <SelectTrigger id="announcement-target">
                            <SelectValue placeholder="Select audience..." />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Users</SelectItem>
                            <SelectItem value="creators_top">Top Creators (>50k followers)</SelectItem>
                            <SelectItem value="creators_growing">Growing Creators (1k-50k followers)</SelectItem>
                            <SelectItem value="users_new">New Users (<1k followers)</SelectItem>
                            <SelectItem value="admins">Admins Only</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                <Button onClick={handleSend} disabled={!message.trim()}>
                    <Send className="mr-2 h-4 w-4" /> Send Announcement
                </Button>
            </CardContent>
        </Card>
    );
}

function CreateSponsoredPostDialog() {
  const { toast } = useToast();
  const [isOpen, setIsOpen] = React.useState(false);
  const [brandName, setBrandName] = React.useState('');
  const [postText, setPostText] = React.useState('');
  const [ctaLink, setCtaLink] = React.useState('');
  const [image, setImage] = React.useState<File | null>(null);
  const [imagePreview, setImagePreview] = React.useState<string | null>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImage(file);
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handlePublish = async () => {
    if (!brandName || !postText || !ctaLink || !image) {
      toast({ variant: 'destructive', title: 'All fields are required.' });
      return;
    }
    
    // In a real app, you'd upload the image to storage. For now, we use the preview.
    const virtualAuthor = {
      id: `sponsored-${Date.now()}`,
      name: brandName,
      username: brandName.toLowerCase().replace(/\s/g, ''),
      avatar: { imageUrl: imagePreview!, id: `ava-${Date.now()}`, imageHint: 'logo', description: 'brand logo' },
    };

    try {
      await createPost({
        author: virtualAuthor as User,
        content: postText,
        linkPreview: {
          url: ctaLink,
          title: `Visit ${brandName}`,
          description: 'Click the link to learn more.',
          image: { imageUrl: imagePreview!, id: `lp-${Date.now()}`, imageHint: 'ad', description: 'ad' },
        },
        isSponsored: true,
        isBoosted: true, // Automatically boost sponsored posts
      });

      toast({ title: 'Sponsored post published successfully!' });
      setIsOpen(false);
      // Reset form
      setBrandName(''); setPostText(''); setCtaLink(''); setImage(null); setImagePreview(null);

    } catch(e) {
      toast({ variant: 'destructive', title: 'Failed to publish post.' });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline">
          <Sparkles className="mr-2 h-4 w-4" />
          Create Sponsored Post
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create Sponsored Post</DialogTitle>
          <DialogDescription>
            This post will appear in user feeds as "Sponsored" content and will be automatically boosted for maximum reach.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="brandName">Brand Name</Label>
            <Input id="brandName" value={brandName} onChange={e => setBrandName(e.target.value)} placeholder="e.g., VIMore Official" />
          </div>
          <div className="space-y-2">
            <Label>Promotional Photo</Label>
            {imagePreview ? (
              <div className="relative">
                <Image src={imagePreview} width={400} height={200} alt="preview" className="rounded-md w-full object-cover aspect-video" />
                <Button variant="destructive" size="icon" className="absolute top-2 right-2 h-6 w-6" onClick={() => {setImage(null); setImagePreview(null)}}>
                    <X className="h-4 w-4"/>
                </Button>
              </div>
            ) : (
               <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer hover:bg-accent">
                 <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <UploadCloud className="w-8 h-8 mb-4 text-muted-foreground" />
                    <p className="mb-2 text-sm text-muted-foreground">Click to upload image</p>
                 </div>
                 <input type="file" className="hidden" onChange={handleImageChange} accept="image/*" />
               </label>
            )}
          </div>
          <div className="space-y-2">
            <Label htmlFor="postText">Post Text</Label>
            <Textarea id="postText" value={postText} onChange={e => setPostText(e.target.value)} placeholder="Write your ad copy here..."/>
          </div>
          <div className="space-y-2">
            <Label htmlFor="ctaLink">Call-to-Action Link</Label>
            <Input id="ctaLink" value={ctaLink} onChange={e => setCtaLink(e.target.value)} placeholder="https://example.com" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setIsOpen(false)}>Cancel</Button>
          <Button onClick={handlePublish}>Publish Post</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
