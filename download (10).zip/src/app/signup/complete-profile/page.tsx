
'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Calendar as CalendarIcon, ArrowLeft } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { Progress } from '@/components/ui/progress';
import { AppContext } from '@/components/app-shell';
import { updateUser } from '@/services/userService';

export default function CompleteProfilePage() {
  const router = useRouter();
  const { toast } = useToast();
  const appContext = React.useContext(AppContext);
  const { currentUser, setCurrentUser } = appContext || {};
  
  const [dob, setDob] = React.useState<Date | undefined>();
  const [isLoading, setIsLoading] = React.useState(false);

  React.useEffect(() => {
    // If for some reason user lands here but profile is complete, redirect them.
    if (currentUser && currentUser.dob) {
      router.push('/');
    }
  }, [currentUser, router]);

  const handleSubmit = async () => {
    if (!currentUser || !dob) return;
    
    setIsLoading(true);
    try {
      await updateUser(currentUser.id, { dob });
      // Manually update the user in context to avoid a full reload
      if (setCurrentUser) {
        setCurrentUser({ ...currentUser, dob });
      }
      toast({ title: 'Profile completed!', description: 'Welcome to VIMore!' });
      router.push('/');
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Update failed',
        description: 'Could not save your date of birth. Please try again.',
      });
      setIsLoading(false);
    }
  };

  if (!currentUser) {
    return (
      <div className="flex h-screen w-screen items-center justify-center bg-background">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen w-full flex-col bg-background p-4">
      <header className="flex h-14 items-center">
        {/* No back button, as this is a required step */}
      </header>
      <div className="flex-1 flex flex-col justify-center">
        <div className="w-full max-w-sm mx-auto">
          <Progress value={100} className="mb-8" />
          <div className="space-y-6">
            <h1 className="text-2xl font-bold text-center">Just one more step!</h1>
            <p className="text-sm text-center text-muted-foreground">Please provide your date of birth to continue. This is for age verification and will not be shown on your public profile.</p>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant={"outline"} className={cn("w-full justify-start text-left font-normal", !dob && "text-muted-foreground")}>
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dob ? format(dob, "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar mode="single" selected={dob} onSelect={setDob} fromYear={1920} toYear={new Date().getFullYear() - 13} captionLayout="dropdown-buttons" initialFocus />
              </PopoverContent>
            </Popover>
            <Button onClick={handleSubmit} disabled={!dob || isLoading} className="w-full">
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Continue
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
