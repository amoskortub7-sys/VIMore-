'use client';

import * as React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Calendar as CalendarIcon, ArrowLeft, Eye, EyeOff, AlertCircle } from 'lucide-react';
import { account, ID } from '@/lib/appwrite';
import { createUserDocument } from '@/services/userService';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { Progress } from '@/components/ui/progress';

const steps = [
  { id: 1, name: "Name" },
  { id: 2, name: "Birthday" },
  { id: 3, name: "Email" },
  { id: 4, name: "Password" },
  { id: 5, name: "Confirm" },
  { id: 6, name: "Done" },
];

export default function SignupPage() {
  const router = useRouter();
  const { toast } = useToast();
  
  const [currentStep, setCurrentStep] = React.useState(1);
  const [isLoading, setIsLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  
  const [formData, setFormData] = React.useState({
    name: '',
    dob: undefined as Date | undefined,
    email: '',
    password: '',
  });

  const [showPassword, setShowPassword] = React.useState(false);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const nextStep = () => setCurrentStep(prev => Math.min(prev + 1, steps.length));
  const prevStep = () => setCurrentStep(prev => Math.max(prev - 1, 1));

  const handleFinalSubmit = async () => {
    setIsLoading(true);
    setError(null);

    if (formData.password.length < 8) {
      setError('Password must be at least 8 characters long.');
      setIsLoading(false);
      return;
    }

    try {
      // 1. Create the user in Appwrite Auth
      const newAppwriteUser = await account.create(ID.unique(), formData.email, formData.password, formData.name);
      
      // 2. Create the user document in the database
      await createUserDocument(newAppwriteUser, { 
        name: formData.name, 
        dob: formData.dob,
      });

      // 3. Initiate email verification
      const verificationUrl = `${window.location.origin}/login`; // Redirect to login after verification
      await account.createVerification(verificationUrl);

      // 4. Move to the final step to instruct user to check email
      nextStep();
    } catch (error: any) {
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <StepLayout title="What's your name?">
            <Input id="name" name="name" value={formData.name} onChange={handleInputChange} placeholder="Full Name" required autoFocus/>
            <Button onClick={nextStep} disabled={!formData.name.trim()} className="w-full">Next</Button>
          </StepLayout>
        );
      case 2:
        return (
          <StepLayout title="What's your date of birth?">
             <p className="text-xs text-muted-foreground text-center">This won't be part of your public profile. It's used to verify your age.</p>
             <Popover>
                <PopoverTrigger asChild>
                  <Button variant={"outline"} className={cn("w-full justify-start text-left font-normal", !formData.dob && "text-muted-foreground")}>
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {formData.dob ? format(formData.dob, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={formData.dob} onSelect={(d) => setFormData(p => ({...p, dob: d}))} fromYear={1920} toYear={new Date().getFullYear() - 13} captionLayout="dropdown-buttons" initialFocus />
                </PopoverContent>
              </Popover>
            <Button onClick={nextStep} disabled={!formData.dob} className="w-full">Next</Button>
          </StepLayout>
        );
      case 3:
        return (
            <StepLayout title="What's your email?">
                <Input id="email" name="email" type="email" value={formData.email} onChange={handleInputChange} placeholder="name@example.com" required />
                <Button onClick={nextStep} disabled={!formData.email.includes('@')} className="w-full">Next</Button>
            </StepLayout>
        );
      case 4:
        return (
            <StepLayout title="Create a password">
                <div className="relative">
                    <Input id="password" name="password" type={showPassword ? "text" : "password"} value={formData.password} onChange={handleInputChange} required />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute inset-y-0 right-0 flex items-center pr-3 text-muted-foreground">
                        {showPassword ? <EyeOff className="h-5 w-5"/> : <Eye className="h-5 w-5"/>}
                    </button>
                </div>
                <p className="text-xs text-muted-foreground">Use 8 or more characters with a mix of letters, numbers & symbols.</p>
                <Button onClick={nextStep} disabled={formData.password.length < 8} className="w-full">Next</Button>
            </StepLayout>
        );
      case 5:
        return (
            <StepLayout title="Finish signing up">
                <p className="text-sm text-muted-foreground text-center px-4">
                    By tapping Sign Up, you agree to our{' '}
                    <Link href="/terms-of-service" className="text-primary hover:underline">Terms of Service</Link> and{' '}
                    <Link href="/privacy-policy" className="text-primary hover:underline">Privacy Policy</Link>.
                </p>
                <Button onClick={handleFinalSubmit} disabled={isLoading} className="w-full">
                    {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Sign Up
                </Button>
            </StepLayout>
        );
      case 6:
        return (
             <StepLayout title="Verify your email">
                <div className="text-center space-y-4">
                    <p className="text-muted-foreground">
                        We've sent a verification link to <strong>{formData.email}</strong>. Please check your inbox and click the link to activate your account.
                    </p>
                     <Button onClick={() => router.push('/login')} className="w-full">Go to Login</Button>
                </div>
             </StepLayout>
        )
      default:
        return null;
    }
  }

  return (
    <div className="flex min-h-screen w-full flex-col bg-background p-4">
        <header className="flex h-14 items-center">
            {currentStep > 1 && currentStep < steps.length && (
                 <Button variant="ghost" size="icon" onClick={prevStep}><ArrowLeft/></Button>
            )}
        </header>
        <div className="flex-1 flex flex-col justify-center">
            <div className="w-full max-w-sm mx-auto">
                <Progress value={(currentStep / steps.length) * 100} className="mb-8" />
                {renderStepContent()}
                 {error && (
                    <div className="mt-4 flex items-center justify-center gap-2 text-sm text-destructive">
                        <AlertCircle className="h-4 w-4" />
                        <p>{error}</p>
                    </div>
                )}
            </div>
        </div>
         <footer className="h-14 text-center text-sm">
            {currentStep < steps.length && (
                 <Link href="/login" className="font-semibold text-primary hover:underline">
                    Already have an account?
                </Link>
            )}
        </footer>
    </div>
  );
}


function StepLayout({ title, children }: { title: string, children: React.ReactNode }) {
    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-center">{title}</h1>
            {children}
        </div>
    )
}
