
'use client';

import * as React from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from '@/components/ui/textarea';
import { UserAvatar } from '@/components/user-avatar';
import { useIsMobile } from '@/hooks/use-mobile';
import type { Post, Comment, User } from '@/lib/data';
import { VerifiedBadge } from './verified-badge';

export function CommentsSheet({ post, children, currentUser }: { post: Post; children: React.ReactNode, currentUser: User }) {
  const isMobile = useIsMobile();
  const [open, setOpen] = React.useState(false);

  if (isMobile) {
    return (
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>{children}</SheetTrigger>
        <SheetContent side="bottom" className="h-[95vh] flex flex-col p-0">
          <SheetHeader className="p-4">
            <SheetTitle>Comments</SheetTitle>
          </SheetHeader>
          <CommentSection post={post} currentUser={currentUser} />
        </SheetContent>
      </Sheet>
    );
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Comments</DialogTitle>
        </DialogHeader>
        <CommentSection post={post} currentUser={currentUser} />
      </DialogContent>
    </Dialog>
  );
}

function CommentSection({ post, currentUser }: { post: Post, currentUser: User }) {
  const [comments, setComments] = React.useState<Comment[]>(post.comments);
  const [newComment, setNewComment] = React.useState('');
  const scrollAreaRef = React.useRef<HTMLDivElement>(null);

  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    const commentToAdd: Comment = {
      id: `comment-${Date.now()}`,
      author: currentUser,
      content: newComment,
      createdAt: 'Just now',
    };

    setComments([commentToAdd, ...comments]);
    setNewComment('');
  };

  React.useEffect(() => {
    // Scroll to bottom when new comment is added
    if (scrollAreaRef.current) {
        // We scroll to top because the list is reversed
        scrollAreaRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [comments])

  return (
    <div className="flex flex-1 flex-col overflow-hidden">
       <ScrollArea className="flex-1" ref={scrollAreaRef}>
        <div className="p-4 space-y-4">
            {comments.map((comment) => (
            <div key={comment.id} className="flex items-start gap-3">
                <Link href={`/profile/${comment.author.username}`}>
                    <UserAvatar user={comment.author} className="h-8 w-8" />
                </Link>
                <div className="flex-1">
                <div className="text-sm bg-secondary rounded-lg p-2 px-3">
                    <Link href={`/profile/${comment.author.username}`} className="hover:underline inline-flex items-center">
                        <span className="font-semibold">{comment.author.name}</span>
                        <VerifiedBadge user={comment.author} />
                    </Link>
                    <p className="whitespace-pre-wrap">{comment.content}</p>
                </div>
                <div className="text-xs text-muted-foreground flex gap-2 px-2 pt-1">
                    <span>{comment.createdAt}</span>
                    <button className="font-semibold hover:underline">Like</button>
                    <button className="font-semibold hover:underline">Reply</button>
                </div>
                </div>
            </div>
            ))}
            {comments.length === 0 && (
            <p className="text-sm text-center text-muted-foreground py-10">No comments yet.</p>
            )}
        </div>
      </ScrollArea>
      <div className="mt-auto border-t bg-background p-4">
        <form onSubmit={handlePostComment} className="flex items-start gap-3">
          <UserAvatar user={currentUser} className="h-8 w-8" />
          <Textarea
            placeholder="Write a comment..."
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            className="flex-1 text-sm bg-secondary border-0 focus-visible:ring-1"
            rows={1}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handlePostComment(e);
              }
            }}
          />
          <Button type="submit" size="sm" disabled={!newComment.trim()}>
            Post
          </Button>
        </form>
      </div>
    </div>
  );
}
