
'use client';

import * as React from 'react';
import { Send, Link as LinkIcon, Edit, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Post } from '@/lib/data';
import { AppContext } from './app-shell';
import { createPost } from '@/services/postService';

export function ShareDialog({ children, post, postUrl }: { children: React.ReactNode, post?: Post, postUrl: string }) {
  const { toast } = useToast();
  const appContext = React.useContext(AppContext);
  const [isSharing, setIsSharing] = React.useState(false);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(postUrl);
    toast({ title: 'Link copied!' });
  };
  
  const handleShareAsPost = async () => {
    if (!post || !appContext?.currentUser) {
        toast({ variant: 'destructive', title: 'Could not share post', description: 'User or post data is missing.' });
        return;
    }
    
    setIsSharing(true);

    try {
        const newPostData = {
          author: appContext.currentUser,
          content: `Check out this post from @${post.author.username}!\n\n> ${post.content.substring(0, 100)}...`,
          linkPreview: {
            url: postUrl,
            title: `Post by ${post.author.name}`,
            description: post.content,
            image: post.images?.[0] ?? post.author.avatar,
          },
        };

        await createPost(newPostData);

        toast({
            title: 'Shared to your profile!',
        });
    } catch (error) {
        toast({
            variant: 'destructive',
            title: 'Failed to share post',
            description: 'Please try again later.',
        });
    } finally {
        setIsSharing(false);
    }
  }
  
  return (
    <Dialog>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Share Post</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col gap-4">
          <p className="text-sm text-muted-foreground">Share this post with others.</p>
          <div className="flex items-center space-x-2">
            <Input defaultValue={postUrl} readOnly className="flex-1" />
            <Button onClick={handleCopyLink} size="sm">
              <LinkIcon className="h-4 w-4 mr-2" /> Copy Link
            </Button>
          </div>
            <DialogClose asChild>
               <Button variant="outline" onClick={handleShareAsPost} disabled={isSharing}>
                  {isSharing ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Edit className="mr-2 h-4 w-4" />}
                  {isSharing ? 'Sharing...' : 'Share as Post'}
                </Button>
            </DialogClose>
           <Button>
              <Send className="mr-2 h-4 w-4" />
              Share to Direct Message
            </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
