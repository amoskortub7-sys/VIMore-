
'use client';

import Image from 'next/image';
import { Button } from './ui/button';
import { X } from 'lucide-react';
import type { LinkPreview } from '@/lib/data';

interface LinkPreviewCardProps {
    preview: LinkPreview;
    onRemove?: () => void;
}

export function LinkPreviewCard({ preview, onRemove }: LinkPreviewCardProps) {
  return (
    <div className="relative">
      <a href={preview.url} target="_blank" rel="noopener noreferrer" className="mt-4 block rounded-lg border overflow-hidden hover:bg-accent transition-colors">
        <div className="flex flex-col sm:flex-row">
          <div className="relative w-full sm:w-1/3 aspect-video sm:aspect-square">
            <Image
              src={preview.image.imageUrl}
              alt={preview.title}
              fill
              className="object-cover"
              data-ai-hint={preview.image.imageHint}
            />
          </div>
          <div className="p-4 flex-1">
            <p className="text-sm font-semibold">{preview.title}</p>
            <p className="text-xs text-muted-foreground line-clamp-2">{preview.description}</p>
            <p className="text-xs text-muted-foreground mt-2 uppercase">{new URL(preview.url).hostname}</p>
          </div>
        </div>
      </a>
      {onRemove && (
        <Button 
            variant="secondary" 
            size="icon" 
            className="absolute top-2 right-2 h-6 w-6 rounded-full bg-black/50 text-white hover:bg-black/70"
            onClick={onRemove}
        >
          <X className="h-4 w-4" />
        </Button>
      )}
    </div>
  );
}
