

'use client';

import * as React from 'react';
import Link from 'next/link';
import { Gift, Wallet } from 'lucide-react';
import { type User, type Gift as GiftType } from '@/lib/data';
import { useIsMobile } from '@/hooks/use-mobile';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose, DialogDescription } from '@/components/ui/dialog';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';
import { cn, formatNumber } from '@/lib/utils';
import { Separator } from './ui/separator';
import { AppContext } from './app-shell';
import { processTransaction } from '@/ai/flows/process-transaction';

const mockGoldGifts: GiftType[] = [
  { id: 'g1', name: 'Rose', icon: '🌹', price: 1, currency: 'gold' },
  { id: 'g2', name: 'Lollipop', icon: '🍭', price: 5, currency: 'gold' },
  { id: 'g3', name: 'Donut', icon: '🍩', price: 10, currency: 'gold' },
  { id: 'g4', name: 'Perfume', icon: '✨', price: 50, currency: 'gold' },
  { id: 'g5', name: 'Handbag', icon: '👜', price: 100, currency: 'gold' },
  { id: 'g6', name: 'Diamond Ring', icon: '💍', price: 500, currency: 'gold' },
  { id: 'g7', name: 'Kiss', icon: '😘', price: 1000, currency: 'gold' },
];

const mockDiamondGifts: GiftType[] = [
  { id: 'd1', name: 'Money Gun', icon: '💸', price: 1, currency: 'diamond' },
  { id: 'd2', name: 'Heart', icon: '❤️', price: 5, currency: 'diamond' },
  { id: 'd3', name: 'Bouquet', icon: '💐', price: 10, currency: 'diamond' },
  { id: 'd4', name: 'Confetti', icon: '🎉', price: 50, currency: 'diamond' },
  { id: 'd5', name: 'VIMore', icon: '💎', price: 100, currency: 'diamond' },
  { id: 'd6', name: 'Car', icon: '🚗', price: 500, currency: 'diamond' },
  { id: 'd7', name: 'Jet', icon: '✈️', price: 1000, currency: 'diamond' },
];


interface GiftingDialogProps {
  creator: User;
  children: React.ReactNode;
}

export function GiftingDialog({ creator, children }: GiftingDialogProps) {
  const isMobile = useIsMobile();
  const [isOpen, setIsOpen] = React.useState(false);
  const [selectedGift, setSelectedGift] = React.useState<GiftType | null>(null);
  const [showConfirm, setShowConfirm] = React.useState(false);
  
  const appContext = React.useContext(AppContext);
  if (!appContext) return null;
  const { currentUser, setCurrentUser } = appContext;
  

  const { toast } = useToast();

  const handleSelectGift = (gift: GiftType) => {
    setSelectedGift(gift);
    setShowConfirm(true);
  };

  const handleConfirmSend = async () => {
    if (!selectedGift || !currentUser) return;

    setShowConfirm(false);
    setIsOpen(false);
    
    toast({
        title: 'Sending Gift...',
        description: `Processing your ${selectedGift.name} gift.`,
    });

    try {
        const result = await processTransaction({
            fromUserId: currentUser.id,
            toUserId: creator.id,
            amount: selectedGift.price,
            currency: selectedGift.currency,
            type: 'gift',
        });

        if (result.success) {
            setCurrentUser({ ...currentUser, [selectedGift.currency]: result.newBalance! });
            toast({
              title: 'Gift Sent!',
              description: `You sent a ${selectedGift.name} to ${creator.name}.`,
            });
        } else {
            toast({
                variant: 'destructive',
                title: 'Transaction Failed',
                description: result.message || 'Please check your balance and try again.',
                action: result.message === 'Insufficient funds.' ? <Link href="/buy-currency"><Button variant="secondary">Buy Currency</Button></Link> : undefined,
            });
        }

    } catch (error) {
        toast({ variant: 'destructive', title: 'Error', description: 'An unexpected error occurred.' });
    }

    setSelectedGift(null);
  };
  
  const GiftingContent = () => (
    <div className="flex flex-col h-full">
      <DialogHeader className={cn(!isMobile && 'p-6 pb-2')}>
        <DialogTitle>Send a Gift to {creator.name}</DialogTitle>
      </DialogHeader>
      <div className={cn("flex-none", isMobile ? 'px-4 pb-4' : 'px-6 pb-4')}>
          <div className="p-3 rounded-lg bg-secondary flex items-center justify-between">
              <div className="flex gap-4">
                  <div className="text-center">
                    <p className="font-bold text-lg">{formatNumber(currentUser.gold)}</p>
                    <p className="text-xs">🪙 Gold</p>
                  </div>
                   <div className="text-center">
                    <p className="font-bold text-lg">{formatNumber(currentUser.diamonds)}</p>
                    <p className="text-xs">💎 Diamonds</p>
                  </div>
              </div>
              <Link href="/buy-currency">
                <Button>Buy Currency</Button>
              </Link>
          </div>
      </div>
      <Tabs defaultValue="gold" className="flex-1 flex flex-col overflow-hidden">
        <TabsList className="grid w-full grid-cols-2 flex-none mx-auto max-w-sm">
          <TabsTrigger value="gold">🪙 Gold Gifts</TabsTrigger>
          <TabsTrigger value="diamond">💎 Diamond Gifts</TabsTrigger>
        </TabsList>
        <div className="flex-1 overflow-y-auto">
          <TabsContent value="gold" className="mt-0">
             <ScrollArea className={cn(isMobile ? 'h-[calc(90vh-220px)]' : 'h-96')}>
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-4 p-4">
                    {mockGoldGifts.map(gift => (
                        <GiftButton key={gift.id} gift={gift} onSelect={handleSelectGift} />
                    ))}
                </div>
            </ScrollArea>
          </TabsContent>
          <TabsContent value="diamond" className="mt-0">
            <ScrollArea className={cn(isMobile ? 'h-[calc(90vh-220px)]' : 'h-96')}>
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-4 p-4">
                    {mockDiamondGifts.map(gift => (
                        <GiftButton key={gift.id} gift={gift} onSelect={handleSelectGift} />
                    ))}
                </div>
            </ScrollArea>
          </TabsContent>
        </div>
      </Tabs>

        {/* Confirmation Dialog within the main dialog */}
       <Dialog open={showConfirm} onOpenChange={setShowConfirm}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Confirm Your Gift</DialogTitle>
                    <DialogDescription>
                        Are you sure you want to send the {selectedGift?.name} gift for {selectedGift?.price} {selectedGift?.currency === 'gold' ? '🪙' : '💎'}?
                    </DialogDescription>
                </DialogHeader>
                <DialogFooter>
                    <Button variant="ghost" onClick={() => setShowConfirm(false)}>Cancel</Button>
                    <Button onClick={handleConfirmSend}>Confirm & Send</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    </div>
  );

  if (isMobile) {
    return (
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild>{children}</SheetTrigger>
        <SheetContent side="bottom" className="h-[90vh] p-0 flex flex-col">
            <GiftingContent />
        </SheetContent>
      </Sheet>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="max-w-xl p-0">
         <GiftingContent />
      </DialogContent>
    </Dialog>
  );
}

function GiftButton({ gift, onSelect }: { gift: GiftType, onSelect: (gift: GiftType) => void }) {
    return (
        <button 
            className="flex flex-col items-center gap-2 p-2 rounded-lg hover:bg-accent transition-colors"
            onClick={() => onSelect(gift)}
        >
            <span className="text-5xl">{gift.icon}</span>
            <p className="text-sm font-semibold">{gift.name}</p>
            <div className="flex items-center gap-1">
                <span className="text-xs font-bold">{gift.price}</span>
                <span>{gift.currency === 'gold' ? '🪙' : '💎'}</span>
            </div>
        </button>
    )
}
