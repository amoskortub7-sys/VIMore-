

'use client';

import * as React from 'react';
import Link from 'next/link';
import { Heart } from 'lucide-react';
import { mockUsers, type User } from '@/lib/data';
import { useIsMobile } from '@/hooks/use-mobile';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose, DialogDescription } from '@/components/ui/dialog';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { useToast } from '@/hooks/use-toast';
import { cn, formatNumber } from '@/lib/utils';
import { Input } from './ui/input';
import { processTransaction } from '@/ai/flows/process-transaction';
import { AppContext } from './app-shell';

interface SupportDialogProps {
  creator: User;
  children: React.ReactNode;
}

export function SupportDialog({ creator, children }: SupportDialogProps) {
  const isMobile = useIsMobile();
  const [isOpen, setIsOpen] = React.useState(false);
  const [amount, setAmount] = React.useState('');
  const [showConfirm, setShowConfirm] = React.useState(false);

  const appContext = React.useContext(AppContext);
  if (!appContext) return null;
  const { currentUser, setCurrentUser } = appContext;
  

  const { toast } = useToast();

  const handleSendClick = () => {
    if (parseInt(amount, 10) > 0) {
        setShowConfirm(true);
    } else {
        toast({
            variant: 'destructive',
            title: 'Invalid Amount',
            description: 'Please enter a valid amount of Gold to send.',
        });
    }
  };

  const handleConfirmSend = async () => {
    if (!currentUser) return;
    const tipAmount = parseInt(amount, 10);
    if (isNaN(tipAmount) || tipAmount <= 0) return;

    setShowConfirm(false);
    setIsOpen(false);
    
    toast({
        title: 'Sending Tip...',
        description: `Processing your tip of ${tipAmount} 🪙.`,
    });

    try {
        const result = await processTransaction({
            fromUserId: currentUser.id,
            toUserId: creator.id,
            amount: tipAmount,
            currency: 'gold', // Tipping is always in Gold
            type: 'tip',
        });
        
        if (result.success) {
            setCurrentUser({ ...currentUser, gold: result.newBalance! });
            toast({
                title: 'Support Sent!',
                description: `You sent a tip of ${tipAmount} 🪙 to ${creator.name}.`,
            });
        } else {
             toast({
                variant: 'destructive',
                title: 'Transaction Failed',
                description: result.message || 'Please check your balance and try again.',
                action: result.message === 'Insufficient funds.' ? <Link href="/buy-currency"><Button variant="secondary">Buy Gold</Button></Link> : undefined,
            });
        }
    } catch (error) {
         toast({ variant: 'destructive', title: 'Error', description: 'An unexpected error occurred.' });
    }

    setAmount('');
  };
  
  const SupportContent = () => {
    if (!currentUser) return null;
    return (
    <>
      <DialogHeader className={cn(!isMobile && 'p-6 pb-4')}>
        <DialogTitle>Support {creator.name}</DialogTitle>
        <DialogDescription>
            Send a tip in Gold to show your appreciation for their work. The creator receives 80% of the amount.
        </DialogDescription>
      </DialogHeader>
      <div className={cn("p-6 pt-0 space-y-4", isMobile && "p-4 pt-2")}>
        <div className="text-center p-4 bg-secondary rounded-lg">
            <p className="text-sm text-muted-foreground">Your Gold Balance</p>
            <p className="text-3xl font-bold flex items-center justify-center gap-2">
                🪙 {formatNumber(currentUser.gold)}
            </p>
        </div>
         <div className="relative">
             <Input 
                type="number"
                placeholder="Enter amount of Gold"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="text-lg h-12 pr-10"
                min="1"
            />
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xl">🪙</span>
         </div>
      </div>
      <DialogFooter className={cn(isMobile && "p-4 border-t")}>
        <Button onClick={handleSendClick} className="w-full" disabled={!amount}>
            Send Tip
        </Button>
      </DialogFooter>

      {/* Confirmation Dialog */}
      <Dialog open={showConfirm} onOpenChange={setShowConfirm}>
        <DialogContent>
            <DialogHeader>
                <DialogTitle>Confirm Your Tip</DialogTitle>
                <DialogDescription>
                    Are you sure you want to send {amount} 🪙 to {creator.name}?
                </DialogDescription>
            </DialogHeader>
            <DialogFooter>
                <Button variant="ghost" onClick={() => setShowConfirm(false)}>Cancel</Button>
                <Button onClick={handleConfirmSend}>Confirm & Send</Button>
            </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )};

  if (isMobile) {
    return (
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild>{children}</SheetTrigger>
        <SheetContent side="bottom" className="p-0 flex flex-col">
            <SupportContent />
        </SheetContent>
      </Sheet>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="max-w-md p-0">
         <SupportContent />
      </DialogContent>
    </Dialog>
  );
}
