

'use client';

import * as React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  ImageIcon,
  BarChart3,
  Smile,
  CalendarClock,
  X,
  Globe,
  Users2,
  Lock,
  Search as SearchIcon,
  Plus,
  Video,
  ChevronDown,
  Loader2,
  CheckCircle2,
  AlertTriangle,
  Palette,
  Sparkles,
  MapPin,
  UserPlus,
  Unlock,
  FileText,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import type { Poll, User, Post } from '@/lib/data';
import { UserAvatar } from './user-avatar';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { Separator } from './ui/separator';
import { ScrollArea } from './ui/scroll-area';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Dialog, DialogContent, DialogTitle, DialogTrigger, DialogClose, DialogFooter, DialogHeader } from '@/components/ui/dialog';
import { Input } from './ui/input';
import { mockTrendingItems } from '@/lib/data';
import { Checkbox } from './ui/checkbox';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Calendar } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { format } from 'date-fns';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Label } from './ui/label';
import { AppContext } from './app-shell';
import { createPost } from '@/services/postService';
import { uploadFile } from '@/services/storageService';
import { getUsers } from '@/services/userService';
import { Skeleton } from './ui/skeleton';

const audienceOptions = [
  { value: 'public', label: 'Public', icon: Globe },
  { value: 'followers', label: 'Followers', icon: Users2 },
  { value: 'private', label: 'Only me', icon: Lock },
];

const backgroundOptions = [
  'bg-white',
  'bg-gradient-to-br from-rose-400 to-rose-600',
  'bg-gradient-to-br from-orange-400 to-orange-600',
  'bg-gradient-to-br from-amber-400 to-amber-600',
  'bg-gradient-to-br from-lime-400 to-lime-600',
  'bg-gradient-to-br from-emerald-400 to-emerald-600',
  'bg-gradient-to-br from-cyan-400 to-cyan-600',
  'bg-gradient-to-br from-sky-400 to-sky-600',
  'bg-gradient-to-br from-indigo-400 to-indigo-600',
  'bg-gradient-to-br from-purple-400 to-purple-600',
  'bg-gradient-to-br from-pink-400 to-pink-600',
]

const getDailyAiBackground = () => {
  const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000);
  const seed = dayOfYear + new Date().getFullYear();
  return `https://picsum.photos/seed/${seed}/800/800`;
};

export function CreatePostForm({ user, onPostCreated, isSheet, initialContent = '', onAction }: { user: User; onPostCreated?: () => void; isSheet?: boolean; initialContent?: string; onAction?: () => void; }) {
  const router = useRouter();
  const [content, setContent] = React.useState(initialContent);
  const [isChecking, setIsChecking] = React.useState(false);
  const [isSafe, setIsSafe] = React.useState<boolean | null>(null);
  
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const [imageFiles, setImageFiles] = React.useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = React.useState<string[]>([]);
  
  const { toast } = useToast();
  const [audience, setAudience] = React.useState(audienceOptions[0]);

  const [taggedUsers, setTaggedUsers] = React.useState<User[]>([]);
  const [location, setLocation] = React.useState<string>('');
  const [feeling, setFeeling] = React.useState<{ emoji: string; label: string } | null>(null);
  const [scheduledAt, setScheduledAt] = React.useState<Date | null>(null);
  const [poll, setPoll] = React.useState<Omit<Poll, 'totalVotes' | 'options'> & { options: string[] } | null>(null);
  const [background, setBackground] = React.useState<string>('bg-white');
  const [isBackgroundSelectorOpen, setIsBackgroundSelectorOpen] = React.useState(false);
  const [unlockPrice, setUnlockPrice] = React.useState<number | null>(null);
  
  const appContext = React.useContext(AppContext);
  if (!appContext) return null;
  const { isFreeMode } = appContext;
  
  React.useEffect(() => {
    setContent(initialContent);
  }, [initialContent]);

  const isEligibleForLock = user.followers > 10000;
  const isTextOnlyPost = imagePreviews.length === 0 && !poll;
  const hasBackground = isTextOnlyPost && background !== 'bg-white';

  React.useEffect(() => {
    if (!content.trim()) {
      setIsSafe(null);
      setIsChecking(false);
      return;
    }

    setIsChecking(true);
    const handler = setTimeout(() => {
      const randomSafe = Math.random() > 0.2;
      setIsSafe(randomSafe);
      setIsChecking(false);
    }, 1000);

    return () => {
      clearTimeout(handler);
    };
  }, [content]);
  
  const handleFileSelect = (files: FileList | null) => {
    if (!files) return;
    const newFiles = Array.from(files).filter(file => file.type.startsWith('image/'));

    setImageFiles(prev => [...prev, ...newFiles]);
    newFiles.forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
            setImagePreviews(prev => [...prev, reader.result as string]);
        };
        reader.readAsDataURL(file);
    });
  }

  const removeImage = (index: number) => {
    setImageFiles(prev => prev.filter((_, i) => i !== index));
    setImagePreviews(previews => previews.filter((_, i) => i !== index));
  }

  const handleSetPoll = (newPoll: Omit<Poll, 'totalVotes' | 'options'> & { options: string[] } | null) => {
    setPoll(newPoll);
    if (newPoll) {
        setBackground('bg-white');
    }
  }

  const formRef = React.useRef<HTMLFormElement>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() && imageFiles.length === 0 && !poll) {
      toast({
        variant: "destructive",
        title: "Nothing to post",
        description: "Write something or add media to create a post."
      });
      return;
    }

    try {
      const uploadedImageUrls = await Promise.all(
        imageFiles.map(file => uploadFile(file))
      );
      
      const newPostData = {
        author: user,
        content,
        images: uploadedImageUrls.map((url, i) => ({ id: `img-${Date.now()}-${i}`, imageUrl: url, description: 'new post', imageHint: 'new post' })),
        poll: poll ? { ...poll, totalVotes: 0, options: poll.options.map(opt => ({ text: opt, votes: 0 })) } : undefined,
        background: hasBackground ? background : undefined,
        unlockPrice: unlockPrice ?? undefined,
      };

      await createPost(newPostData);
      
      if (onPostCreated) onPostCreated();

      toast({
        title: "Post Published!",
        description: "Your post is now live.",
      });
      router.refresh();

    } catch (error) {
      console.error(error);
      toast({
        variant: "destructive",
        title: "Failed to create post",
        description: "There was an error saving your post. Please try again."
      });
    }
  }

  const formContent = (
    <form ref={formRef} onSubmit={handleSubmit} className="flex flex-col gap-4 h-full p-4">
      <div className="flex items-start gap-4">
        <UserAvatar user={user} className="h-12 w-12" />
        <div className="flex-1">
          <div className="font-semibold">{user.name} <PostMetadata a_taggedUsers={taggedUsers} a_location={location} a_feeling={feeling} isInline /></div>
          <div className="flex items-center gap-2">
            <DropdownMenu>
                <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="h-7 rounded-full text-xs -ml-1">
                    {React.createElement(audience.icon, { className: "h-3 w-3 mr-1"})}
                    {audience.label}
                    <ChevronDown className="h-3 w-3 ml-1" />
                </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56">
                {audienceOptions.map((option) => (
                <DropdownMenuItem key={option.value} onClick={() => setAudience(option)}>
                    <option.icon className="mr-2 h-4 w-4" />
                    <span>{option.label}</span>
                </DropdownMenuItem>
                ))}
                </DropdownMenuContent>
            </DropdownMenu>
            {isEligibleForLock && (
                <LockPostButton onSetPrice={setUnlockPrice} isLocked={!!unlockPrice}>
                    <Button variant="outline" size="sm" className="h-7 rounded-full text-xs">
                        {unlockPrice ? <Unlock className="h-3 w-3 mr-1" /> : <Lock className="h-3 w-3 mr-1" />}
                        {unlockPrice ? `${unlockPrice} 🪙` : 'Lock'}
                    </Button>
                </LockPostButton>
            )}
          </div>
        </div>
      </div>
      
      <ScrollArea className={cn("flex-1 -mx-4", isSheet ? '' : 'max-h-80')}>
        <div className="px-4">
            <div 
                className={cn(
                    'relative w-full rounded-lg transition-all', 
                    hasBackground ? 'flex items-center justify-center p-6 min-h-[250px]' : '',
                    background.startsWith('bg-gradient') ? background : 'bg-white'
                )}
                style={{ backgroundImage: background.startsWith('https') ? `url(${background})` : undefined, backgroundSize: 'cover', backgroundPosition: 'center' }}
            >
                {hasBackground && <div className="absolute inset-0 bg-black/20 pointer-events-none" />}
                <Textarea
                  placeholder="What's on your mind?"
                  className={cn(
                      "relative flex-1 border-0 bg-transparent px-0 shadow-none focus-visible:ring-0 text-lg min-h-[120px] resize-none",
                      hasBackground && "text-white placeholder:text-gray-200 text-center text-2xl font-bold"
                  )}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                />
            </div>
            {imagePreviews.length > 0 && (
                <div className="mt-4 grid grid-cols-3 gap-2">
                    {imagePreviews.map((preview, index) => (
                        <div key={index} className="relative">
                            <Image
                            src={preview}
                            alt={`Image preview ${index + 1}`}
                            width={150}
                            height={150}
                            className="rounded-lg object-cover w-full aspect-square"
                            />
                            <Button
                            variant="destructive"
                            size="icon"
                            className="absolute top-1 right-1 h-5 w-5 rounded-full"
                            onClick={() => removeImage(index)}
                            >
                            <X className="h-3 w-3" />
                            </Button>
                        </div>
                    ))}
                    {imagePreviews.length < 5 && (
                        <Button variant="outline" className="aspect-square w-full h-full" onClick={() => fileInputRef.current?.click()}>
                            <Plus className="h-6 w-6" />
                        </Button>
                    )}
                </div>
            )}
            {poll && <PostPoll poll={poll} onRemove={() => handleSetPoll(null)} />}
            <PostMetadata a_taggedUsers={taggedUsers} a_location={location} a_feeling={feeling} a_scheduledAt={scheduledAt}/>
        </div>
      </ScrollArea>
      
      <div className="mt-auto flex flex-col gap-2">
         <Card className="p-2">
            <input type="file" ref={fileInputRef} onChange={(e) => handleFileSelect(e.target.files)} multiple accept="image/*" className="hidden" />
            <div className="flex items-center justify-between">
                <p className="font-semibold text-sm px-2">Add to your post</p>
                <div className="flex items-center text-primary">
                    <IconButton icon={ImageIcon} tooltip="Photo" onClick={() => fileInputRef.current?.click()} />
                    {!isFreeMode && <Link href="/create/video" passHref onClick={onAction}><IconButton icon={Video} tooltip="Video" /></Link>}
                     {isTextOnlyPost && (
                        <BackgroundSelectorButton onSelect={setBackground} current={background} isOpen={isBackgroundSelectorOpen} onOpenChange={setIsBackgroundSelectorOpen}>
                            <IconButton icon={Palette} tooltip="Background"/>
                        </BackgroundSelectorButton>
                      )}
                    <TagPeopleButton a_taggedUsers={taggedUsers} setTaggedUsers={setTaggedUsers}><IconButton icon={UserPlus} tooltip="Tag people" /></TagPeopleButton>
                    <AddLocationButton a_location={location} setLocation={setLocation}><IconButton icon={MapPin} tooltip="Check in" /></AddLocationButton>
                    <AddFeelingButton a_feeling={feeling} setFeeling={setFeeling}><IconButton icon={Smile} tooltip="Feeling/activity" /></AddFeelingButton>
                    <CreatePollButton setPoll={handleSetPoll}><IconButton icon={BarChart3} tooltip="Poll" /></CreatePollButton>
                </div>
            </div>
        </Card>
      </div>
    </form>
  );

  return (
    <Card className={cn("border-0 shadow-none", isSheet && "h-full flex flex-col")}>
      <CardHeader className={cn("p-4 flex flex-row items-center justify-between", isSheet ? "border-b" : "")}>
        <DialogTitle>Create Post</DialogTitle>
        <Button onClick={handleSubmit}>Post</Button>
      </CardHeader>
      <CardContent className={cn("p-0", isSheet && "flex-1 flex flex-col")}>
        {formContent}
      </CardContent>
    </Card>
  );
}

function SafetyCheckStatus({ isChecking, isSafe }: { isChecking: boolean, isSafe: boolean | null }) {
    if (isChecking) {
        return (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                <span>Checking...</span>
            </div>
        )
    }

    if (isSafe === true) {
        return (
            <div className="flex items-center gap-2 text-xs text-green-600">
                <CheckCircle2 className="h-4 w-4" />
                <span>Looks good!</span>
            </div>
        )
    }
    
    if (isSafe === false) {
        return (
            <div className="flex items-center gap-2 text-xs text-yellow-600">
                <AlertTriangle className="h-4 w-4" />
                <span>May violate guidelines</span>
            </div>
        )
    }

    return null;
}

function PostMetadata({ a_taggedUsers, a_location, a_feeling, a_scheduledAt, isInline }: { a_taggedUsers: User[], a_location: string, a_feeling: {emoji: string, label: string} | null, a_scheduledAt?: Date | null, isInline?: boolean }) {
  const hasData = a_taggedUsers.length > 0 || !!a_location || !!a_feeling || !!a_scheduledAt;
  if (!hasData) return null;

  const content = (
    <>
      {a_feeling && (
        <span className="flex items-center gap-1">
          — is feeling {a_feeling.emoji} {a_feeling.label}
        </span>
      )}
      {a_taggedUsers.length > 0 && (
        <span className="flex items-center gap-1">
          with <Badge variant="secondary">{a_taggedUsers[0].name}</Badge>
          {a_taggedUsers.length > 1 && <Badge variant="secondary">and {a_taggedUsers.length - 1} others</Badge>}
        </span>
      )}
      {a_location && (
        <span className="flex items-center gap-1">
          at <Badge variant="secondary">{a_location}</Badge>
        </span>
      )}
       {a_scheduledAt && (
        <span className="flex items-center gap-1">
          · scheduled for <Badge variant="secondary">{format(a_scheduledAt, 'PPp')}</Badge>
        </span>
      )}
    </>
  );

  if (isInline) {
    return <span className="text-sm font-normal text-muted-foreground">{content}</span>
  }

  return (
    <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground mt-2">
      {content}
    </div>
  );
}


function TagPeopleButton({ children, a_taggedUsers, setTaggedUsers }: { children: React.ReactNode, a_taggedUsers: User[], setTaggedUsers: (users: User[]) => void }) {
  const [searchQuery, setSearchQuery] = React.useState('');
  const [allUsers, setAllUsers] = React.useState<User[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const [selectedUsers, setSelectedUsers] = React.useState<User[]>(a_taggedUsers);

  React.useEffect(() => {
    getUsers().then(users => {
      setAllUsers(users);
      setIsLoading(false);
    });
  }, []);

  React.useEffect(() => {
    setSelectedUsers(a_taggedUsers);
  }, [a_taggedUsers]);
  
  const filteredUsers = allUsers.filter(u => u.name.toLowerCase().includes(searchQuery.toLowerCase()));

  const handleSelectUser = (user: User) => {
    setSelectedUsers(prev => 
      prev.some(u => u.id === user.id) 
        ? prev.filter(u => u.id !== user.id)
        : [...prev, user]
    );
  };
  
  const handleSave = () => {
    setTaggedUsers(selectedUsers);
  }

  return (
    <Dialog>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Tag People</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col gap-4">
            <div className="relative">
                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search people..." className="pl-9" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
            </div>
            <ScrollArea className="h-64">
                <div className="flex flex-col gap-2 p-1">
                    {isLoading ? (
                      Array.from({ length: 3 }).map((_, i) => (
                        <div key={i} className="flex items-center gap-3 p-2">
                          <Skeleton className="h-4 w-4" />
                          <Skeleton className="h-8 w-8 rounded-full" />
                          <Skeleton className="h-4 w-32" />
                        </div>
                      ))
                    ) : (
                      filteredUsers.map(user => (
                          <div key={user.id} className="flex items-center gap-3 p-2 rounded-md hover:bg-accent" >
                              <Checkbox 
                                  id={`user-${user.id}`} 
                                  checked={selectedUsers.some(u => u.id === user.id)}
                                  onCheckedChange={() => handleSelectUser(user)}
                              />
                              <label htmlFor={`user-${user.id}`} className="flex items-center gap-3 cursor-pointer flex-1">
                                  <UserAvatar user={user} />
                                  <span className="font-medium">{user.name}</span>
                              </label>
                          </div>
                      ))
                    )}
                </div>
            </ScrollArea>
        </div>
        <DialogClose asChild>
            <Button onClick={handleSave}>Done</Button>
        </DialogClose>
      </DialogContent>
    </Dialog>
  )
}

function AddLocationButton({ children, a_location, setLocation }: { children: React.ReactNode, a_location: string, setLocation: (location: string) => void }) {
    const [currentLocation, setCurrentLocation] = React.useState(a_location);

    const handleSave = () => {
        setLocation(currentLocation);
    }
  return (
    <Dialog>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add Location</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col gap-4">
            <Input placeholder="Where are you?" value={currentLocation} onChange={(e) => setCurrentLocation(e.target.value)} />
        </div>
         <DialogClose asChild>
            <Button onClick={handleSave}>Set Location</Button>
        </DialogClose>
      </DialogContent>
    </Dialog>
  )
}

const feelings = [
    { emoji: '😊', label: 'happy' },
    { emoji: '❤️', label: 'loved' },
    { emoji: '😢', label: 'sad' },
    { emoji: '😠', label: 'angry' },
    { emoji: '🤔', label: 'thinking' },
    { emoji: '🥳', label: 'celebrating' },
    { emoji: '😴', label: 'tired' },
    { emoji: '🙏', label: 'blessed' },
];

function AddFeelingButton({ children, a_feeling, setFeeling }: { children: React.ReactNode; a_feeling: { emoji: string; label: string } | null; setFeeling: (feeling: { emoji: string; label: string } | null) => void; }) {
  const handleSelectFeeling = (feeling: { emoji: string; label: string }) => {
    setFeeling(feeling);
  };
  
  return (
    <Dialog>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>How are you feeling?</DialogTitle>
        </DialogHeader>
        <Tabs defaultValue="feelings">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="feelings">Feelings</TabsTrigger>
            <TabsTrigger value="activities" disabled>Activities</TabsTrigger>
          </TabsList>
          <TabsContent value="feelings">
            <ScrollArea className="h-64">
                <div className="grid grid-cols-2 gap-2 p-1">
                    {feelings.map(feeling => (
                        <DialogClose key={feeling.label} asChild>
                            <Button variant="outline" className="justify-start gap-2" onClick={() => handleSelectFeeling(feeling)}>
                                <span className="text-xl">{feeling.emoji}</span>
                                <span>{feeling.label}</span>
                            </Button>
                        </DialogClose>
                    ))}
                </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}

function SchedulePostButton({ children, setScheduledAt }: { children: React.ReactNode; setScheduledAt: (date: Date | null) => void; }) {
  const [date, setDate] = React.useState<Date | undefined>(new Date());
  const [hour, setHour] = React.useState(new Date().getHours());
  const [minute, setMinute] = React.useState(new Date().getMinutes());

  const handleSave = () => {
    if (date) {
      const newDate = new Date(date);
      newDate.setHours(hour);
      newDate.setMinutes(minute);
      setScheduledAt(newDate);
    }
  };
  
  const hours = Array.from({ length: 24 }, (_, i) => i);
  const minutes = Array.from({ length: 60 }, (_, i) => i);

  return (
     <Dialog>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Schedule Post</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col items-center gap-4">
          <Calendar
            mode="single"
            selected={date}
            onSelect={setDate}
            className="rounded-md border"
          />
          <div className="flex w-full items-center gap-2">
            <p className="text-sm font-medium">Time:</p>
             <Select value={hour.toString()} onValueChange={(val) => setHour(parseInt(val))}>
              <SelectTrigger className="w-[80px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {hours.map(h => <SelectItem key={h} value={h.toString()}>{h.toString().padStart(2, '0')}</SelectItem>)}
              </SelectContent>
            </Select>
            <span>:</span>
             <Select value={minute.toString()} onValueChange={(val) => setMinute(parseInt(val))}>
              <SelectTrigger className="w-[80px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                 {minutes.map(m => <SelectItem key={m} value={m.toString()}>{m.toString().padStart(2, '0')}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>
         <DialogClose asChild>
            <Button onClick={handleSave}>Confirm</Button>
        </DialogClose>
      </DialogContent>
    </Dialog>
  )
}

export function CreatePollButton({ children, setPoll }: { children: React.ReactNode; setPoll: (poll: Omit<Poll, 'totalVotes' | 'options'> & { options: string[] } | null) => void; }) {
  const [question, setQuestion] = React.useState('');
  const [options, setOptions] = React.useState(['', '']);

  const handleOptionChange = (index: number, value: string) => {
    const newOptions = [...options];
    newOptions[index] = value;
    setOptions(newOptions);
  };

  const addOption = () => {
    if (options.length < 5) { // Limit to 5 options
      setOptions([...options, '']);
    }
  };

  const removeOption = (index: number) => {
    if (options.length > 2) {
      const newOptions = options.filter((_, i) => i !== index);
      setOptions(newOptions);
    }
  };
  
  const handleSave = () => {
    if (question.trim() && options.every(o => o.trim())) {
      setPoll({ question, options });
    }
  }

  const canSave = question.trim() && options.every(o => o.trim());

  return (
    <Dialog>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create Poll</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col gap-4">
          <Textarea 
            placeholder="Poll question..." 
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
          />
          <div className="flex flex-col gap-2">
            <Label>Options</Label>
            {options.map((option, index) => (
              <div key={index} className="flex items-center gap-2">
                <Input 
                  placeholder={`Option ${index + 1}`}
                  value={option}
                  onChange={(e) => handleOptionChange(index, e.target.value)}
                />
                <Button variant="ghost" size="icon" onClick={() => removeOption(index)} disabled={options.length <= 2}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
          <Button variant="outline" onClick={addOption} disabled={options.length >= 5}>
            <Plus className="h-4 w-4 mr-2" /> Add Option
          </Button>
        </div>
        <DialogClose asChild>
          <Button onClick={handleSave} disabled={!canSave}>Create Poll</Button>
        </DialogClose>
      </DialogContent>
    </Dialog>
  )
}

export function PostPoll({ poll, onRemove }: { poll: { question: string; options: string[] }; onRemove?: () => void; }) {
  return (
    <div className="relative mt-4 rounded-lg border p-4">
      <h3 className="font-semibold">{poll.question}</h3>
      <div className="mt-2 flex flex-col gap-2">
        {poll.options.map((option, index) => (
          <div key={index} className="rounded-md border p-2 text-sm">{option}</div>
        ))}
      </div>
      {onRemove && (
        <Button
            variant="destructive"
            size="icon"
            className="absolute top-2 right-2 h-6 w-6 rounded-full"
            onClick={onRemove}
        >
            <X className="h-4 w-4" />
        </Button>
      )}
    </div>
  )
}

function BackgroundSelectorButton({ children, onSelect, current, isOpen, onOpenChange, disabled }: { children: React.ReactNode, onSelect: (bg: string) => void, current: string, isOpen: boolean, onOpenChange: (open: boolean) => void, disabled?: boolean }) {
  return (
    <Popover open={isOpen} onOpenChange={onOpenChange}>
      <PopoverTrigger asChild disabled={disabled}>{children}</PopoverTrigger>
      <PopoverContent className="w-auto p-2">
        <div className="flex items-center gap-2">
            {backgroundOptions.map(bg => (
                <button key={bg} onClick={() => onSelect(bg)} className={cn('w-8 h-8 rounded-full border-2 transition-transform hover:scale-110', current === bg ? 'border-primary scale-110' : 'border-transparent', bg)} />
            ))}
            <button onClick={() => onSelect(getDailyAiBackground())} className={cn('w-8 h-8 rounded-full border-2 flex items-center justify-center bg-gray-700 transition-transform hover:scale-110', current.startsWith('https') ? 'border-primary scale-110' : 'border-transparent' )}>
                <Sparkles className="w-5 h-5 text-white"/>
            </button>
        </div>
      </PopoverContent>
    </Popover>
  )
}

function LockPostButton({ onSetPrice, children, isLocked }: { onSetPrice: (price: number | null) => void; children: React.ReactNode, isLocked: boolean }) {
    const [price, setPrice] = React.useState('');
    
    const handleSave = () => {
        const priceNum = parseInt(price, 10);
        if (!isNaN(priceNum) && priceNum > 0) {
            onSetPrice(Math.min(priceNum, 200)); // Cap at 200
        }
    };

    return (
        <Dialog>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent className="max-w-sm">
                <DialogHeader>
                    <DialogTitle>Lock Post</DialogTitle>
                    <p className="text-sm text-muted-foreground pt-2">Set an unlock price in Gold 🪙. Viewers will have to pay this amount to see your post. Max 200 🪙.</p>
                </DialogHeader>
                <div className="flex items-center gap-2">
                    <Input
                        type="number"
                        placeholder="Unlock price (1-200)"
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                        min="1"
                        max="200"
                    />
                    <span className="text-xl">🪙</span>
                </div>
                <DialogFooter className="gap-2 sm:gap-0">
                    {isLocked && (
                        <DialogClose asChild>
                            <Button variant="outline" onClick={() => onSetPrice(null)}>
                               <Unlock className="mr-2 h-4 w-4"/> Remove Lock
                            </Button>
                        </DialogClose>
                    )}
                    <DialogClose asChild>
                        <Button onClick={handleSave} disabled={!price}>Set Price</Button>
                    </DialogClose>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

function IconButton({icon: Icon, tooltip, ...props}: {icon: React.ElementType, tooltip: string} & React.ComponentProps<typeof Button>) {
  return (
    <Button variant="ghost" size="icon" type="button" aria-label={tooltip} {...props}>
      <Icon className="h-6 w-6" />
    </Button>
  )
}
