'use client';

import { MusicPlayerProvider } from '@/components/music/music-player-provider';

export function AppProviders({ children }: { children: React.ReactNode }) {
  return (
    <MusicPlayerProvider>
      {children}
    </MusicPlayerProvider>
  );
}
