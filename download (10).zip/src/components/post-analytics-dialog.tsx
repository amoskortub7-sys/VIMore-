
'use client';

import * as React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Post, User } from '@/lib/data';
import { Eye, Heart, MessageCircle, Share2, BarChart3, Users, MapPin, TrendingUp, UserCheck, Lock, AlertTriangle, GitCommitHorizontal, CheckCircle, XCircle } from 'lucide-react';
import { cn, formatNumber } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Separator } from './ui/separator';
import { ChartContainer, ChartTooltip, ChartTooltipContent, ChartLegend, ChartLegendContent } from '@/components/ui/chart';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Progress } from './ui/progress';

interface PostAnalyticsDialogProps {
  children: React.ReactNode;
  post: Post;
}

// Mock data generation for demonstration
const generateAnalytics = (post: Post) => ({
  reach: Math.floor(Math.random() * 50000) + 1000,
  impressions: Math.floor(Math.random() * 80000) + 5000,
  engagement: post.reactions.length + post.comments.length + post.shares,
  profileVisits: Math.floor(Math.random() * 500) + 10,
  newFollows: Math.floor(Math.random() * 50),
  demographics: {
    age: [
      { name: '13-17', value: Math.random() },
      { name: '18-24', value: Math.random() },
      { name: '25-34', value: Math.random() },
      { name: '35+', value: Math.random() },
    ],
    gender: [
      { name: 'Woman', value: Math.random() },
      { name: 'Man', value: Math.random() },
      { name: 'Other', value: Math.random() },
    ],
    locations: [
      { name: 'USA', value: 45 }, { name: 'Brazil', value: 20 }, { name: 'India', value: 15 },
    ]
  },
  discovery: [
    { name: 'For You Feed', value: 65 },
    { name: 'Following Feed', value: 20 },
    { name: 'Profile', value: 8 },
    { name: 'Hashtags', value: 7 },
  ],
  videoRetention: Array.from({ length: 10 }, (_, i) => ({
    second: i * ((post.video?.length || 10) / 10),
    retention: 100 - (i * (Math.random() * 5 + 5)),
  })),
  pollResults: post.poll?.options.map(opt => ({
      ...opt,
      demographics: {
          '18-24': Math.floor(Math.random() * opt.votes),
          '25-34': Math.floor(Math.random() * (opt.votes * 0.5)),
      }
  })),
  unlockFunnel: {
      impressions: Math.floor(Math.random() * 10000) + 1000,
      clicks: Math.floor(Math.random() * 500) + 50,
      unlocks: Math.floor(Math.random() * 40) + 5,
  }
});


export function PostAnalyticsDialog({ children, post }: PostAnalyticsDialogProps) {
  const analyticsData = React.useMemo(() => generateAnalytics(post), [post]);
  
  const conversionRate = analyticsData.unlockFunnel.impressions > 0 
    ? ((analyticsData.unlockFunnel.unlocks / analyticsData.unlockFunnel.impressions) * 100).toFixed(1) 
    : 0;
    
  const genderChartConfig = {
    Woman: { label: 'Woman', color: 'hsl(var(--chart-1))' },
    Man: { label: 'Man', color: 'hsl(var(--chart-2))' },
    Other: { label: 'Other', color: 'hsl(var(--chart-3))' },
  } satisfies import('@/components/ui/chart').ChartConfig;

  const discoveryChartConfig = {
    discovery: { label: "Discovery" },
    ...Object.fromEntries(analyticsData.discovery.map((d, i) => [d.name.replace(/\s+/g, ''), { label: d.name, color: `hsl(var(--chart-${i+1}))` }]))
  } satisfies import('@/components/ui/chart').ChartConfig;

  const likeCount = post.reactions.filter(r => r.type === 'like').length;

  return (
    <Dialog>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><BarChart3/> Post Analytics</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4 max-h-[80vh] overflow-y-auto pr-2">
            
            {/* Left Column */}
            <div className="space-y-6">
                <Card>
                    <CardHeader>
                        <CardTitle>Performance Overview</CardTitle>
                    </CardHeader>
                    <CardContent className="grid grid-cols-2 gap-4 text-center">
                        <Metric icon={Eye} label="Reach" value={formatNumber(analyticsData.reach)} />
                        <Metric icon={TrendingUp} label="Impressions" value={formatNumber(analyticsData.impressions)} />
                        <Metric icon={Heart} label="Likes" value={formatNumber(likeCount)} />
                        <Metric icon={MessageCircle} label="Comments" value={formatNumber(post.comments.length)} />
                        <Metric icon={Share2} label="Shares" value={formatNumber(post.shares)} />
                        <Metric icon={UserCheck} label="New Follows" value={formatNumber(analyticsData.newFollows)} />
                    </CardContent>
                </Card>

                {post.unlockPrice && (
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2"><Lock/> Locked Post Performance</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="flex justify-around text-center">
                                <div>
                                    <p className="text-2xl font-bold">{formatNumber(analyticsData.unlockFunnel.impressions)}</p>
                                    <p className="text-xs text-muted-foreground">Impressions</p>
                                </div>
                                <div>
                                    <p className="text-2xl font-bold">{formatNumber(analyticsData.unlockFunnel.unlocks)}</p>
                                    <p className="text-xs text-muted-foreground">Unlocks</p>
                                </div>
                                 <div>
                                    <p className="text-2xl font-bold">{conversionRate}%</p>
                                    <p className="text-xs text-muted-foreground">Conversion</p>
                                </div>
                            </div>
                            <div className="text-center p-3 bg-secondary rounded-lg">
                                <p className="text-xs text-muted-foreground">Total Earnings</p>
                                <p className="text-2xl font-bold text-primary">{formatNumber(analyticsData.unlockFunnel.unlocks * post.unlockPrice * 0.8)} 🪙</p>
                            </div>
                        </CardContent>
                    </Card>
                )}
                
                {post.video && (
                    <Card>
                        <CardHeader><CardTitle>Video Retention</CardTitle></CardHeader>
                        <CardContent className="h-48">
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={analyticsData.videoRetention}>
                                    <XAxis dataKey="second" unit="s" fontSize={10} />
                                    <YAxis domain={[0, 100]} unit="%" fontSize={10} />
                                    <ChartTooltip cursor={{fill: 'hsl(var(--accent))'}} content={<ChartTooltipContent indicator="dot" />} />
                                    <Bar dataKey="retention" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                                </BarChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>
                )}
            </div>

            {/* Right Column */}
            <div className="space-y-6">
                <Card>
                    <CardHeader><CardTitle>Discovery</CardTitle></CardHeader>
                    <CardContent>
                        <ChartContainer
                            config={discoveryChartConfig}
                            className="h-48 w-full"
                        >
                            <PieChart>
                                <ChartTooltip content={<ChartTooltipContent hideLabel />} />
                                <Pie data={analyticsData.discovery} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={40} outerRadius={60} labelLine={false} label={({ cx, cy, midAngle, innerRadius, outerRadius, percent }) => {
                                    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
                                    const x = cx + radius * Math.cos(-midAngle * (Math.PI / 180));
                                    const y = cy + radius * Math.sin(-midAngle * (Math.PI / 180));
                                    return (
                                    <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central" fontSize={12}>
                                        {`${(percent * 100).toFixed(0)}%`}
                                    </text>
                                    );
                                }}>
                                    {analyticsData.discovery.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={`hsl(var(--chart-${index + 1}))`} />
                                    ))}
                                </Pie>
                                <ChartLegend content={<ChartLegendContent />} />
                            </PieChart>
                        </ChartContainer>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader><CardTitle>Audience Demographics</CardTitle></CardHeader>
                    <CardContent className="space-y-4">
                        <div>
                            <h3 className="font-semibold text-sm mb-2">Top Locations</h3>
                            {analyticsData.demographics.locations.map(loc => (
                                <div key={loc.name} className="text-xs">
                                    <div className="flex justify-between mb-1"><span>{loc.name}</span><span>{loc.value}%</span></div>
                                    <Progress value={loc.value} className="h-1.5" />
                                </div>
                            ))}
                        </div>
                         <div>
                            <h3 className="font-semibold text-sm mb-2">Gender</h3>
                             <ChartContainer config={genderChartConfig} className="h-auto">
                                <BarChart data={analyticsData.demographics.gender} layout="vertical" barCategoryGap={0} className="h-[20px]">
                                    {Object.keys(genderChartConfig).map((key) => <Bar key={key} dataKey={key} stackId="a" fill={`var(--color-${key})`} />)}
                                </BarChart>
                                <ChartLegend content={<ChartLegendContent />} />
                            </ChartContainer>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Metric({ icon: Icon, label, value }: { icon: React.ElementType, label: string, value: string | number }) {
  return (
    <div className="p-2 bg-secondary/50 rounded-lg">
      <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
        <Icon className="h-4 w-4" /> {label}
      </div>
      <p className="text-2xl font-bold mt-1">{value}</p>
    </div>
  );
}
