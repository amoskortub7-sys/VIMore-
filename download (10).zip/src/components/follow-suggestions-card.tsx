

'use client';

import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { UserAvatar } from '@/components/user-avatar';
import { type User } from '@/lib/data';
import Image from 'next/image';
import { X, UserPlus, UserCheck } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import Link from 'next/link';
import { getUsers } from '@/services/userService';
import { AppContext } from './app-shell';

export function FollowSuggestionsCard() {
  const { toast } = useToast();
  const appContext = React.useContext(AppContext);
  const currentUser = appContext?.currentUser;

  const [followers, setFollowers] = React.useState<User[]>([]);
  const [suggestions, setSuggestions] = React.useState<User[]>([]);

  React.useEffect(() => {
    const fetchSuggestions = async () => {
      if (!currentUser) return;
      
      const allUsers = await getUsers();
      const nonFriends = allUsers.filter(u => u.id !== currentUser.id && !u.followers); // simplified logic
      
      // This is a placeholder for a real suggestion algorithm
      setFollowers(nonFriends.slice(0, 5));
      setSuggestions(nonFriends.slice(5, 10));
    };
    fetchSuggestions();
  }, [currentUser]);


  const followBackSuggestions = followers.slice(0, 5);
  const newSuggestions = suggestions.slice(0, 5);

  const allSuggestions = [
    ...followBackSuggestions.map(user => ({ user, type: 'follow_back' as const })),
    ...newSuggestions.map(user => ({ user, type: 'suggestion' as const })),
  ];
  
  const [activeSuggestions, setActiveSuggestions] = React.useState(allSuggestions);
  
  React.useEffect(() => {
      setActiveSuggestions(allSuggestions);
  }, [followers, suggestions])

  const handleFollow = (userToFollow: User, type: 'follow_back' | 'suggestion') => {
    // Optimistically update the UI
    handleDismiss(userToFollow.id);
    
    toast({
      title: type === 'follow_back' ? `Followed back ${userToFollow.name}` : `You are now following ${userToFollow.name}`,
    });
  };

  const handleDismiss = (userIdToDismiss: string) => {
    setActiveSuggestions(prev => prev.filter(({ user }) => user.id !== userIdToDismiss));
  };
  
  if (activeSuggestions.length === 0) {
    return null;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Suggestions for You</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="w-full">
          <div className="flex gap-4 pb-4">
            {activeSuggestions.map(({ user, type }) => (
                <div key={user.id} className="relative w-40 shrink-0">
                     <Card className="overflow-hidden group">
                        <div className="relative h-24 w-full">
                             <Image src={user.coverPhoto.imageUrl} alt={`${user.name}'s cover photo`} fill className="object-cover" />
                             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/3">
                                <UserAvatar user={user} className="h-16 w-16 border-4 border-card"/>
                             </div>
                        </div>
                        <CardContent className="p-4 pt-10 text-center">
                            <Link href={`/profile/${user.username}`}>
                              <p className="font-semibold text-sm truncate hover:underline">{user.name}</p>
                            </Link>
                            <p className="text-xs text-muted-foreground truncate">@{user.username}</p>
                            <Button className="mt-4 w-full" size="sm" onClick={() => handleFollow(user, type)}>
                                {type === 'follow_back' ? <UserCheck className="mr-2 h-4 w-4"/> : <UserPlus className="mr-2 h-4 w-4"/>}
                                {type === 'follow_back' ? 'Follow Back' : 'Follow'}
                            </Button>
                        </CardContent>
                     </Card>
                     <Button 
                        variant="secondary" 
                        size="icon" 
                        className="absolute top-2 right-2 h-6 w-6 rounded-full bg-black/40 text-white hover:bg-black/60"
                        onClick={() => handleDismiss(user.id)}
                    >
                        <X className="h-4 w-4" />
                     </Button>
                </div>
            ))}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
