
'use client';

import * as React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { MessageCircle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';
import { UserAvatar } from '@/components/user-avatar';
import { Post, User, PostReaction, type Conversation } from '@/lib/data';
import { useToast } from '@/hooks/use-toast';
import { VerifiedBadge } from './verified-badge';
import { useIsMobile } from '@/hooks/use-mobile';
import { getFollowers, getFollowing, toggleFollow } from '@/services/userService';
import { AppContext } from './app-shell';
import { Skeleton } from './ui/skeleton';

export function ReactionsDialog({ post, reactions, children }: { post: Post, reactions: PostReaction[], children: React.ReactNode }) {
  const isMobile = useIsMobile();
  const reactionCount = reactions.length;

  if (reactionCount === 0) {
    return <>{children}</>;
  }
  
  if (isMobile) {
    return (
        <Sheet>
            <SheetTrigger asChild>{children}</SheetTrigger>
            <SheetContent side="bottom" className="h-[80vh] flex flex-col p-0">
                 <SheetHeader className="p-4">
                    <SheetTitle>Reactions</SheetTitle>
                </SheetHeader>
                <ReactionsList reactions={reactions} />
            </SheetContent>
        </Sheet>
    )
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Reactions</DialogTitle>
        </DialogHeader>
        <ReactionsList reactions={reactions} />
      </DialogContent>
    </Dialog>
  );
}

function ReactionsList({ reactions }: { reactions: PostReaction[] }) {
    const router = useRouter();
    const { toast } = useToast();
    const appContext = React.useContext(AppContext);
    
    const [friends, setFriends] = React.useState<User[]>([]); // "Friends" means who the current user is following
    const [followers, setFollowers] = React.useState<User[]>([]);
    const [isLoading, setIsLoading] = React.useState(true);

    const currentUser = appContext?.currentUser;

    React.useEffect(() => {
        const fetchRelations = async () => {
            if (!currentUser) return;
            setIsLoading(true);
            try {
                const [userFollowers, userFollowing] = await Promise.all([
                    getFollowers(currentUser.id),
                    getFollowing(currentUser.id)
                ]);
                setFollowers(userFollowers);
                setFriends(userFollowing);
            } catch (error) {
                console.error("Failed to fetch relationship data", error);
            } finally {
                setIsLoading(false);
            }
        }
        fetchRelations();
    }, [currentUser]);


    const handleMessage = (user: User) => {
        if (!currentUser || !appContext) return;
        const { conversations, createConversation } = appContext;
        
        const existingConvo = conversations.find(c => 
          c.type === 'direct' &&
          c.participants.length === 2 &&
          c.participants.some(p => p.id === user.id) &&
          c.participants.some(p => p.id === currentUser.id)
        );

        if (existingConvo) {
          router.push(`/messages?conversationId=${existingConvo.id}`);
        } else {
          const newConvo: Conversation = {
            id: `dm-${Date.now()}`,
            type: 'direct',
            participants: [currentUser, user],
            messages: [],
            unreadCount: 0,
          };
          createConversation(newConvo);
        }
    };
    
    const handleFollowToggle = async (targetUser: User, isFollowing: boolean) => {
        if (!currentUser) return;

        const oldFriends = [...friends];
        if (isFollowing) {
            setFriends(prev => prev.filter(f => f.id !== targetUser.id));
            toast({ title: `Unfollowed ${targetUser.name}` });
        } else {
            setFriends(prev => [...prev, targetUser]);
            toast({ title: `You are now following ${targetUser.name}` });
        }
        
        try {
            await toggleFollow(currentUser.id, targetUser.id, isFollowing);
        } catch (error) {
            setFriends(oldFriends);
            toast({ variant: 'destructive', title: 'Action failed. Please try again.' });
        }
    };
    
    const getButtonAction = (user: User) => {
        if (!currentUser || user.id === currentUser.id) return null;

        const isFriend = friends.some(f => f.id === user.id);
        const isFollower = followers.some(f => f.id === user.id);

        if (isFriend) {
            return (
                <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline" onClick={() => handleFollowToggle(user, true)}>Following</Button>
                    <Button size="sm" variant="ghost" className="px-2" onClick={() => handleMessage(user)}>
                        <MessageCircle className="h-5 w-5 text-muted-foreground" />
                    </Button>
                </div>
            );
        }
        if (isFollower) {
            return <Button size="sm" onClick={() => handleFollowToggle(user, false)}>Follow Back</Button>;
        }
        return <Button size="sm" onClick={() => handleFollowToggle(user, false)}>Follow</Button>;
    };

    const reactionEmojis: Record<PostReaction['type'], string> = {
        like: '❤️',
        angry: '😠',
        sad: '😢',
        funny: '😂',
        wow: '😮',
    };
    
    if (isLoading || !currentUser) {
        return (
            <div className="h-96 p-4 space-y-4">
                {Array.from({length: 5}).map((_, i) => (
                    <div key={i} className="flex items-center gap-4">
                        <Skeleton className="h-10 w-10 rounded-full" />
                        <div className="flex-1 space-y-2">
                            <Skeleton className="h-4 w-2/3" />
                            <Skeleton className="h-3 w-1/3" />
                        </div>
                    </div>
                ))}
            </div>
        );
    }

    return (
        <ScrollArea className="h-96 -mx-6">
            <div className="flex flex-col gap-4 p-4">
                {reactions.map(reaction => (
                    <div key={reaction.user.id} className="flex items-center gap-4">
                        <Link href={`/profile/${reaction.user.username}`}>
                            <UserAvatar user={reaction.user} />
                        </Link>
                        <div className="flex-1">
                            <Link href={`/profile/${reaction.user.username}`} className="hover:underline">
                                <p className="font-semibold inline-flex items-center">
                                  {reaction.user.name}
                                  <VerifiedBadge user={reaction.user} />
                                </p>
                            </Link>
                            <p className="text-sm text-muted-foreground">@{reaction.user.username}</p>
                        </div>
                         <div className="flex items-center gap-2">
                            <span className="text-xl">{reactionEmojis[reaction.type]}</span>
                            {getButtonAction(reaction.user)}
                        </div>
                    </div>
                ))}
            </div>
        </ScrollArea>
    );
}
