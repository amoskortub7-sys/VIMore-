
'use client';

import Image from 'next/image';
import type { User } from '@/lib/data';
import { cn } from '@/lib/utils';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';


type UserAvatarProps = {
  user: User;
  className?: string;
  isOnline?: boolean;
};

export function UserAvatar({ user, className, isOnline: isOnlineProp }: UserAvatarProps) {
  const isOnline = isOnlineProp === undefined ? user.isOnline : isOnlineProp;
  const nameInitial = user.name?.charAt(0) ?? '';

  return (
    <div className={cn("relative shrink-0", className)}>
      <Avatar>
          <AvatarImage src={user.avatar.imageUrl} alt={user.name} data-ai-hint={user.avatar.imageHint} />
          <AvatarFallback>{nameInitial}</AvatarFallback>
      </Avatar>
      {isOnline && (
        <span className="absolute bottom-0 right-0 block h-2.5 w-2.5 translate-x-1/3 translate-y-1/3 rounded-full bg-green-500 ring-2 ring-background" />
      )}
    </div>
  );
}
