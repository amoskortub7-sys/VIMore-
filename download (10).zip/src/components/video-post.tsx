

'use client';

import * as React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { 
    Play, 
    Pause, 
    Heart, 
    MessageCircle, 
    Share2, 
    Music,
    MoreHorizontal,
    Flag,
    ThumbsDown,
    Link as LinkIcon,
    Gift,
    Download,
    Loader2,
    TrendingUp,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

import type { Post, User } from '@/lib/data';
import { cn, formatNumber } from '@/lib/utils';
import { UserAvatar } from './user-avatar';
import { Button } from './ui/button';
import { CommentsSheet } from './comments-sheet';
import { ShareDialog } from './share-dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { GiftingDialog } from './gifting-dialog';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from './ui/dialog';
import { BoostPostDialog } from './boost-post-dialog';
import { AppContext } from './app-shell';


const CONTENT_LENGTH_THRESHOLD = 100;

export function VideoPost({ post }: { post: Post }) {
  const videoRef = React.useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = React.useState(false);
  const [showControls, setShowControls] = React.useState(false);
  const [isLiked, setIsLiked] = React.useState(false);
  const [isExpanded, setIsExpanded] = React.useState(false);
  const [showDownloadDialog, setShowDownloadDialog] = React.useState(false);
  const [isDownloading, setIsDownloading] = React.useState(false);

  const { toast } = useToast();
  const appContext = React.useContext(AppContext);
  const currentUser = appContext?.currentUser;
  const isOwnPost = post.author.id === currentUser?.id;
  
  const postUrl = typeof window !== 'undefined' ? `${window.location.origin}/post/${post.id}` : '';
  const likeCount = post.likedBy?.length ?? 0;

  const observer = React.useRef<IntersectionObserver>();

  React.useEffect(() => {
    observer.current = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!videoRef.current) {
            // Video element might have been unmounted
            return;
          }
          if (entry.isIntersecting) {
            videoRef.current?.play();
            setIsPlaying(true);
          } else {
            videoRef.current?.pause();
            setIsPlaying(false);
          }
        });
      },
      { threshold: 0.5 } // Play when 50% of the video is visible
    );

    if (videoRef.current) {
      observer.current.observe(videoRef.current);
    }

    return () => {
      if (videoRef.current) {
        observer.current?.unobserve(videoRef.current);
      }
    };
  }, []);

  const handleVideoTap = () => {
    if (isPlaying) {
      videoRef.current?.pause();
    } else {
      videoRef.current?.play();
    }
    setIsPlaying(!isPlaying);
    setShowControls(true);
    setTimeout(() => setShowControls(false), 800);
  };
  
  const handleLike = () => {
    // In a real app, this would call a service.
    // For now, we just toggle the state locally.
    setIsLiked(!isLiked);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(postUrl);
    toast({ title: 'Link copied to clipboard!' });
  };
  
  const handleDownload = () => {
    setShowDownloadDialog(true);
  };

  const handleConfirmDownload = () => {
    setShowDownloadDialog(false);
    setIsDownloading(true);
    // Simulate watching an ad
    setTimeout(() => {
      toast({
        title: "Ad finished!",
        description: "Your download is starting...",
      });
      // Simulate download process
      setTimeout(() => {
        setIsDownloading(false);
        if (!post.video) return;

        // In a real app, this would trigger a server-side process
        // to watermark and then provide a download link.
        // For simulation, we'll just download the original video.
        const link = document.createElement('a');
        link.href = post.video;
        const watermarkedFilename = `VIMore_${post.author.username}_${post.id}.mp4`;
        link.setAttribute('download', watermarkedFilename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        toast({
          title: "Download Complete!",
          description: `Video saved as ${watermarkedFilename}`,
        });

      }, 1500);
    }, 3000); // 3-second "ad"
  };

  const renderContent = (content: string) => {
    const isLongPost = content.length > CONTENT_LENGTH_THRESHOLD;
    const textToRender = isExpanded || !isLongPost
        ? content
        : `${content.substring(0, CONTENT_LENGTH_THRESHOLD)}...`;
    
    const regex = /([#@][\w_]+)/g;
    const parts = textToRender.split(regex);

    return (
        <p className="text-sm text-white drop-shadow-sm">
            {parts.map((part, index) => {
                if (part.match(regex)) {
                    const isHashtag = part.startsWith('#');
                    const url = isHashtag ? `/search?q=${part.substring(1)}` : `/profile/${part.substring(1)}`;
                    return (
                        <Link key={index} href={url} className="font-bold hover:underline">
                            {part}
                        </Link>
                    );
                }
                return part;
            })}
             {isLongPost && (
                <button 
                    onClick={() => setIsExpanded(!isExpanded)} 
                    className="font-bold ml-1"
                >
                    {isExpanded ? 'less' : 'more'}
                </button>
            )}
        </p>
    );
};

  const soundInfo = post.song
    ? `${post.song.artist.name} - ${post.song.title}`
    : `${post.author.name} - Original Sound`;
    
  const SoundLinkWrapper = ({ children }: { children: React.ReactNode }) => {
    if (post.song) {
      return <Link href={`/sounds/${post.song.id}`}>{children}</Link>;
    }
    return <>{children}</>;
  };

  const canGift = post.author.followers > 1000;

  return currentUser ? (
    <>
    <div className="relative h-full w-full bg-black flex items-center justify-center" onClick={handleVideoTap}>
      <video
        ref={videoRef}
        src={post.video}
        loop
        playsInline
        className="w-full h-full object-contain"
      />

      <AnimatePresence>
        {showControls && (
          <motion.div
            initial={{ opacity: 0, scale: 1.5 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.5 }}
            transition={{ duration: 0.2 }}
            className="absolute"
          >
            {isPlaying ? (
              <Play className="h-20 w-20 text-white/50" />
            ) : (
              <Pause className="h-20 w-20 text-white/50" />
            )}
          </motion.div>
        )}
      </AnimatePresence>

      <div 
        className="absolute bottom-0 left-0 right-0 z-10 text-white p-4 bg-gradient-to-t from-black/50 to-transparent"
        onClick={(e) => e.stopPropagation()} // Prevent video tap when interacting with UI
      >
        <div className="flex justify-between items-end">
            {/* Left side: user info & caption */}
            <div className="flex-1 space-y-2 pr-12">
                <Link href={`/profile/${post.author.username}`} className="flex items-center gap-3">
                    <UserAvatar user={post.author} className="h-12 w-12 border-2 border-white" />
                    <div>
                        <p className="font-bold text-lg">{post.author.name}</p>
                        <p className="text-sm text-white/90">@{post.author.username}</p>
                    </div>
                </Link>
                {renderContent(post.content)}
                <SoundLinkWrapper>
                  <div className="flex items-center gap-2">
                      <Music className="h-4 w-4"/>
                      <p className="text-sm font-medium w-48 truncate">{soundInfo}</p>
                  </div>
                </SoundLinkWrapper>
            </div>

            {/* Right side: Action buttons */}
            <div className="flex flex-col items-center space-y-4">
                <ActionButton icon={Heart} label={formatNumber(likeCount + (isLiked ? 1 : 0))} onClick={handleLike} isLiked={isLiked} />
                <CommentsSheet post={post} currentUser={currentUser}>
                    <div role="button" className="w-full">
                        <ActionButton icon={MessageCircle} label={formatNumber(post.comments.length)} />
                    </div>
                </CommentsSheet>
                {canGift && (
                    <GiftingDialog currentUser={currentUser} creator={post.author}>
                        <div role="button" className="w-full">
                            <ActionButton icon={Gift} label="Gift" />
                        </div>
                    </GiftingDialog>
                )}
                <ActionButton icon={Download} label="Save" onClick={handleDownload} />
                <ShareDialog post={post} postUrl={postUrl}>
                     <div role="button" className="w-full">
                        <ActionButton icon={Share2} label={formatNumber(post.shares)} />
                    </div>
                </ShareDialog>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-12 w-12 text-white">
                      <MoreHorizontal />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    {isOwnPost && (
                        <BoostPostDialog post={post} user={currentUser} contentType="video" onBoost={() => toast({title: "Your video is now being boosted!"})}>
                           <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                                <TrendingUp className="mr-2 h-4 w-4" />
                                Boost Video
                           </DropdownMenuItem>
                        </BoostPostDialog>
                    )}
                    <DropdownMenuItem onSelect={() => toast({ title: "Video reported" })}>
                      <Flag className="mr-2 h-4 w-4" />
                      Report
                    </DropdownMenuItem>
                    <DropdownMenuItem onSelect={() => toast({ title: "We won't recommend videos like this to you anymore" })}>
                      <ThumbsDown className="mr-2 h-4 w-4" />
                      Not Interested
                    </DropdownMenuItem>
                    <DropdownMenuItem onSelect={handleCopyLink}>
                      <LinkIcon className="mr-2 h-4 w-4" />
                      Copy Link
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
            </div>
        </div>
      </div>
    </div>
    
    <Dialog open={showDownloadDialog} onOpenChange={setShowDownloadDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Download Video</DialogTitle>
            <DialogDescription>
              Watch a short ad to complete your download. The video will be saved to your device.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDownloadDialog(false)}>Cancel</Button>
            <Button onClick={handleConfirmDownload}>Watch Ad & Download</Button>
          </DialogFooter>
        </DialogContent>
    </Dialog>

    {isDownloading && (
      <div className="fixed inset-0 bg-black/80 z-50 flex flex-col items-center justify-center text-white">
        <Loader2 className="h-12 w-12 animate-spin mb-4" />
        <p className="text-lg font-semibold">Preparing your download...</p>
        <p className="text-sm text-muted-foreground">Please wait while we prepare the video.</p>
      </div>
    )}
    </>
  ) : null;
}


function ActionButton({ icon: Icon, label, isLiked, ...props }: { icon: React.ElementType, label: string, isLiked?: boolean } & React.ComponentProps<typeof Button>) {
  return (
    <Button variant="ghost" className="flex flex-col items-center h-auto text-white p-0 gap-1" {...props}>
      <Icon className={cn("h-8 w-8 drop-shadow-md", isLiked && "text-red-500 fill-current")} />
      <span className="text-xs font-bold drop-shadow-md">{label}</span>
    </Button>
  );
}
