
'use client';

import * as React from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import {
  Compass,
  BarChart2,
  Search,
  Rss,
  Library,
  ArrowLeft,
  UploadCloud,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { MiniPlayer } from './music/mini-player';
import { useMusicPlayer } from './music/music-player-provider';

const musicNavItems = [
  { href: '/music/discover', label: 'Discover', icon: Compass },
  { href: '/music/charts', label: 'Charts', icon: BarChart2 },
  { href: '/music/upload', label: 'Upload', icon: UploadCloud },
  { href: '/music/feed', label: 'Feed', icon: Rss },
  { href: '/music/library', label: 'My Library', icon: Library },
];

export function MusicShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { currentSong } = useMusicPlayer();

  return (
    <div className="h-screen w-screen flex flex-col bg-background">
      <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b bg-background px-4">
        <Link href="/" passHref>
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-6 w-6" />
          </Button>
        </Link>
        <h1 className="text-xl font-bold">Music</h1>
        <div className="ml-auto flex items-center gap-2">
            <Link href="/music/search">
                <Button variant="ghost" size="icon">
                    <Search className="h-6 w-6" />
                </Button>
            </Link>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto pb-36">{children}</main>
      
      {currentSong && <MiniPlayer />}

      <nav className="fixed bottom-0 left-0 right-0 z-30 border-t bg-background/95 backdrop-blur-sm">
        <div className="grid h-16 grid-cols-5 items-center p-2">
          {musicNavItems.map((item) => {
            const isActive = pathname.startsWith(item.href);
            return (
              <Link href={item.href} key={item.href}>
                <Button
                  variant="ghost"
                  className={cn(
                    'flex h-full w-full flex-col items-center justify-center gap-1',
                    isActive ? 'text-primary' : 'text-muted-foreground'
                  )}
                >
                  <item.icon className="h-6 w-6" />
                  <span className="text-xs">{item.label}</span>
                </Button>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
