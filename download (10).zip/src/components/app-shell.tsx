

'use client';

import * as React from 'react';
import Link from 'next/link';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import {
  Home,
  User,
  MessageCircle,
  Plus,
  Search,
  Menu,
  Users,
  Music,
  Settings,
  LogOut,
  Video,
  Wallet,
  Bell,
  LayoutDashboard,
  Shield,
  Download,
  FileText,
  Type,
  Loader2,
} from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { UserAvatar } from './user-avatar';
import { type Conversation, type User as UserType } from '@/lib/data';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { CreatePostForm } from './create-post-form';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetClose } from './ui/sheet';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { useMusicPlayer } from './music/music-player-provider';
import { MiniPlayer } from './music/mini-player';
import { Separator } from './ui/separator';
import { AdBanner } from './ad-banner';
import { VIMoreLogo } from './icons/logo';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { useToast } from '@/hooks/use-toast';
import { account } from '@/lib/appwrite';
import { getUser, createUserDocument } from '@/services/userService';
import { getNotifications } from '@/services/notificationService';
import { SplashScreen } from './splash-screen';
import { AnimatePresence } from 'framer-motion';

export const AppContext = React.createContext<{
    currentUser: UserType | null;
    conversations: Conversation[];
    updateConversation: (updatedConvo: Conversation) => void;
    createConversation: (newConvo: Conversation) => void;
    setCurrentUser: (user: UserType | null) => void;
    isFreeMode: boolean;
    toggleFreeMode: () => void;
} | null>(null);


export function AppShell({ children }: { children: React.ReactNode }) {
  const isMobile = useIsMobile();
  const pathname = usePathname();
  const router = useRouter();
  const searchParams = useSearchParams();
  const { currentSong } = useMusicPlayer();
  const { toast } = useToast();
  
  const [currentUser, setCurrentUser] = React.useState<UserType | null>(null);
  const [conversations, setConversations] = React.useState<Conversation[]>([]);
  const [isFreeMode, setIsFreeMode] = React.useState(false);

  const [authIsLoading, setAuthIsLoading] = React.useState(true);
  const [splashScreenFinished, setSplashScreenFinished] = React.useState(false);


  const publicPages = ['/login', '/signup', '/forgot-password', '/reset-password', '/verify-action'];
  const isPublicPage = publicPages.some(page => pathname.startsWith(page));

  // This effect handles redirection based on auth state.
  React.useEffect(() => {
    const checkSession = async () => {
      try {
        const session = await account.get();
        let userProfile = await getUser(session.$id);
        
        if (!userProfile) {
            // This is likely a new user from OAuth. Create their profile.
            userProfile = await createUserDocument(session, { name: session.name });
        }

        setCurrentUser(userProfile);

        // Redirect to complete profile if needed
        if (userProfile && !userProfile.dob && pathname !== '/signup/complete-profile') {
            router.push('/signup/complete-profile');
        }

      } catch (error) {
        setCurrentUser(null);
      } finally {
        setAuthIsLoading(false);
      }
    };
    checkSession();
  }, [pathname, router]);

  React.useEffect(() => {
    if (authIsLoading) return; // Don't redirect while checking auth status

    // If there's no user and we are on a protected page, redirect to login.
    if (!currentUser && !isPublicPage) {
      router.push('/login');
    }
    
    // If a user is "logged in" and they are on a public page, redirect them home.
    if (currentUser && isPublicPage) {
      router.push('/');
    }
  }, [currentUser, isPublicPage, authIsLoading, router, pathname]);


  const isChatView = isMobile && pathname === '/messages' && searchParams.has('conversationId');
  const noNavOnPages = ['/call', '/stories', '/create', '/reels', '/search', '/settings', '/admin', '/login', '/signup', '/signup/complete-profile', '/forgot-password', '/reset-password', '/verify-action'];
  const isMusicPage = pathname.startsWith('/music');
  
  const showNav = !noNavOnPages.some((p) => pathname.startsWith(p)) && !isChatView;
  
  const showBottomAd = ['/friends', '/buy-currency', '/dashboard'].some(p => pathname.startsWith(p));


  const [isCreatePostOpen, setIsCreatePostOpen] = React.useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  
  const [installPromptEvent, setInstallPromptEvent] = React.useState<Event | null>(null);

  React.useEffect(() => {
    const handleBeforeInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPromptEvent(event);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = () => {
    if (installPromptEvent && 'prompt' in installPromptEvent) {
      (installPromptEvent as any).prompt();
    }
  };

  const handleLogout = async () => {
    await account.deleteSession('current');
    setCurrentUser(null);
    toast({ title: "Logged out successfully" });
    router.push('/login');
    if (isMobileMenuOpen) setIsMobileMenuOpen(false);
  };


  // --- Notification State ---
  const [notifications, setNotifications] = React.useState({
    messages: 0,
    notifications: 0,
  });

  React.useEffect(() => {
    if (!currentUser) return;
    
    const fetchNotifs = async () => {
        try {
            const userNotifications = await getNotifications(currentUser.id);
            const unreadCount = userNotifications.filter(n => !n.read).length;
            setNotifications(prev => ({ ...prev, notifications: unreadCount }));

            // Simulate unread messages
            const unreadMessages = Math.floor(Math.random() * 3);
            setNotifications(prev => ({...prev, messages: unreadMessages}));
        } catch (error) {
            console.error("Failed to fetch notifications count", error);
        }
    }
    
    fetchNotifs();
    const interval = setInterval(fetchNotifs, 30000); // Poll every 30 seconds
    
    return () => clearInterval(interval);

  }, [currentUser]);


  const clearNotification = (section: keyof typeof notifications) => {
    setNotifications(prev => ({ ...prev, [section]: 0 }));
  };
  // --- End Notification State ---

  const handleUpdateConversation = (updatedConvo: Conversation) => {
    setConversations(prev => 
      prev.map(c => (c.id === updatedConvo.id ? updatedConvo : c))
    );
  };
  
  const handleCreateConversation = (newConvo: Conversation) => {
    if (newConvo.type === 'direct') {
        const existingConvo = conversations.find(c => 
            c.type === 'direct' &&
            c.participants.length === 2 &&
            c.participants.every(p => newConvo.participants.some(np => np.id === p.id))
        );
        if (existingConvo) {
            router.push(`/messages?conversationId=${existingConvo.id}`);
            return;
        }
    }
    setConversations(prev => [newConvo, ...prev]);
    router.push(`/messages?conversationId=${newConvo.id}`);
  }

  const toggleFreeMode = () => setIsFreeMode(prev => !prev);


  const CreatePostButton = (
    <Button variant="ghost" size="icon" className="rounded-full">
      <Plus className="h-6 w-6" />
    </Button>
  );
  
  const appContextValue = {
      currentUser,
      conversations,
      updateConversation: handleUpdateConversation,
      createConversation: handleCreateConversation,
      setCurrentUser: setCurrentUser,
      isFreeMode,
      toggleFreeMode,
  };
  
  const showSplashScreen = authIsLoading || (!isPublicPage && !currentUser);
  
  if (!splashScreenFinished && showSplashScreen) {
      return (
        <SplashScreen
          isFinished={!showSplashScreen}
          onExitComplete={() => setSplashScreenFinished(true)}
        />
      );
  }

  if (isPublicPage) {
    return <AppContext.Provider value={appContextValue}><main>{children}</main></AppContext.Provider>;
  }
  
  // This should not be reachable if the logic is correct, but as a safeguard:
  if (!currentUser) {
     return (
         <div className="flex h-screen w-full items-center justify-center bg-background">
            <p>Redirecting to login...</p>
         </div>
      )
  }

  if (isMusicPage) {
    return <AppContext.Provider value={appContextValue}><main>{children}</main></AppContext.Provider>;
  }

  if (isMobile) {
    if (!showNav) {
      return <AppContext.Provider value={appContextValue}><main>{children}</main></AppContext.Provider>;
    }
    return (
      <AppContext.Provider value={appContextValue}>
      <div>
        <header className="fixed top-0 left-0 right-0 z-10 border-b bg-background/95 backdrop-blur-sm">
          <div className="flex h-14 items-center justify-between p-2">
            <Link href="/" className="flex items-center gap-2">
              <VIMoreLogo className="h-8 w-8" />
              <h1 className="font-headline text-2xl font-bold tracking-tighter text-primary">VIMore</h1>
            </Link>
            <div className="flex items-center gap-1">
               <Sheet open={isCreatePostOpen} onOpenChange={setIsCreatePostOpen}>
                <SheetTrigger asChild>
                   <Button variant="ghost" size="icon" className="rounded-full">
                    <Plus className="h-6 w-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="bottom" className="h-[90vh] rounded-t-2xl p-0">
                  <CreatePostForm user={currentUser!} onPostCreated={() => setIsCreatePostOpen(false)} isSheet onAction={() => setIsCreatePostOpen(false)} />
                </SheetContent>
              </Sheet>
              <Link href="/search">
                  <Button variant="ghost" size="icon" className="rounded-full">
                    <Search className="h-6 w-6" />
                  </Button>
              </Link>
              <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
                <SheetTrigger asChild>
                   <Button variant="ghost" size="icon" className="rounded-full">
                    <Menu className="h-6 w-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="p-0">
                    <SheetHeader className="p-4 border-b">
                      <SheetTitle>Menu</SheetTitle>
                    </SheetHeader>
                    <div className="flex flex-col h-full">
                        <header className="p-4">
                            <Link href={`/profile/${currentUser.username}`} className="group" onClick={() => setIsMobileMenuOpen(false)}>
                                <UserAvatar user={currentUser} className="h-14 w-14" />
                                <p className="mt-2 text-lg font-bold group-hover:underline">{currentUser.name}</p>
                                <p className="text-sm text-muted-foreground">@{currentUser.username}</p>
                            </Link>
                        </header>
                        <Separator />
                        <div className="p-4">
                            <div className="flex items-center justify-between">
                                <Label htmlFor="free-mode-mobile" className="flex items-center gap-3 text-base">
                                    <Type /> Free Mode
                                </Label>
                                <Switch id="free-mode-mobile" checked={isFreeMode} onCheckedChange={toggleFreeMode} />
                            </div>
                        </div>
                        <Separator />
                        <nav className="flex-1 p-2 overflow-y-auto">
                            {installPromptEvent && (
                                <Button variant="ghost" className="w-full justify-start text-base p-6 gap-3" onClick={handleInstallClick}>
                                    <Download /> Install App
                                </Button>
                            )}
                            <Link href={`/profile/${currentUser.username}`} onClick={() => setIsMobileMenuOpen(false)}>
                                <Button variant="ghost" className="w-full justify-start text-base p-6 gap-3">
                                    <User /> Profile
                                </Button>
                            </Link>
                            <Link href="/dashboard" onClick={() => setIsMobileMenuOpen(false)}>
                                <Button variant="ghost" className="w-full justify-start text-base p-6 gap-3">
                                    <LayoutDashboard /> Dashboard
                                </Button>
                            </Link>
                             <Link href="/admin" onClick={() => setIsMobileMenuOpen(false)}>
                                <Button variant="ghost" className="w-full justify-start text-base p-6 gap-3">
                                    <Shield /> Admin
                                </Button>
                            </Link>
                             <Link href="/features" onClick={() => setIsMobileMenuOpen(false)}>
                                <Button variant="ghost" className="w-full justify-start text-base p-6 gap-3">
                                    <FileText /> How It Works
                                </Button>
                            </Link>
                             <Link href="/reels" onClick={() => setIsMobileMenuOpen(false)}>
                                <Button variant="ghost" className="w-full justify-start text-base p-6 gap-3">
                                    <Video /> Reels
                                </Button>
                            </Link>
                            <Link href="/friends" onClick={() => setIsMobileMenuOpen(false)}>
                                <Button variant="ghost" className="w-full justify-start text-base p-6 gap-3">
                                    <Users /> Friends
                                </Button>
                            </Link>
                             <Link href="/messages" onClick={() => setIsMobileMenuOpen(false)}>
                                <Button variant="ghost" className="w-full justify-start text-base p-6 gap-3">
                                    <MessageCircle /> Messages
                                </Button>
                            </Link>
                            <Link href="/buy-currency" onClick={() => setIsMobileMenuOpen(false)}>
                                <Button variant="ghost" className="w-full justify-start text-base p-6 gap-3">
                                    <Wallet /> Buy Currency
                                </Button>
                            </Link>
                        </nav>
                        <Separator />
                        <footer className="p-2 shrink-0">
                            <Link href="/settings" onClick={() => setIsMobileMenuOpen(false)}>
                                <Button variant="ghost" className="w-full justify-start text-base p-6 gap-3">
                                    <Settings /> Settings
                                </Button>
                             </Link>
                             <Button variant="ghost" className="w-full justify-start text-base p-6 gap-3 text-red-500 hover:text-red-500" onClick={handleLogout}>
                                <LogOut /> Log out
                            </Button>
                            <p className="text-center text-xs text-muted-foreground pt-4">
                                From Media Tech Liberia
                            </p>
                        </footer>
                    </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </header>
        
        {currentSong && <MiniPlayer variant="top" />}

        <nav className="fixed bottom-0 left-0 right-0 z-10 border-t bg-background/95 backdrop-blur-sm">
          {showBottomAd && <AdBanner className="h-12 rounded-none border-b" />}
          <div className="grid h-16 grid-cols-6 items-center p-2">
            {mobileNavItems.map((item) => {
              const isActive = pathname === item.href;
              const notifCount = notifications[item.key as keyof typeof notifications] || 0;
              return (
                 <Link href={item.href} key={item.href} onClick={() => clearNotification(item.key as keyof typeof notifications)} aria-label={item.label}>
                    <div
                      className={cn(
                        'flex-1 flex-col h-full w-full flex items-center justify-center relative gap-1',
                        isActive ? 'text-primary' : 'text-muted-foreground'
                      )}
                    >
                      <NotificationBadge count={notifCount} />
                      <item.icon className="h-6 w-6" />
                    </div>
                </Link>
              )
            })}
             <div className="flex justify-center flex-col items-center gap-1 text-muted-foreground h-full">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button aria-label="Profile">
                       <UserAvatar user={currentUser} className="h-8 w-8"/>
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuItem asChild>
                      <Link href={`/profile/${currentUser.username}`}>Profile</Link>
                    </DropdownMenuItem>
                     <DropdownMenuItem asChild>
                        <Link href="/settings">Settings</Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout}>Log out</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
          </div>
        </nav>

        <main className={cn("pt-14 pb-20", currentSong && "pt-32")}>{children}</main>
      </div>
      </AppContext.Provider>
    );
  }

  return (
    <AppContext.Provider value={appContextValue}>
    <div className="flex min-h-screen w-full">
      <aside className="sticky top-0 flex h-screen w-64 flex-col border-r bg-background">
        <div className="flex h-full flex-col p-4">
          <header className="mb-8 flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <VIMoreLogo className="h-8 w-8" />
              <h1 className="font-headline text-2xl font-bold tracking-tighter text-primary">VIMore</h1>
            </Link>
          </header>
          <nav className="flex-1 space-y-2">
            {desktopNavItems.map((item) => (
              <DesktopNavItem key={item.href} {...item} notifications={notifications} />
            ))}
             <Link href={`/profile/${currentUser.username}`}>
                <Button
                    variant={pathname === `/profile/${currentUser.username}` ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-3 px-4 py-6 text-base"
                >
                    <User className="h-5 w-5" />
                    <span>Profile</span>
                </Button>
            </Link>
             <Link href="/buy-currency">
                <Button
                    variant={pathname === '/buy-currency' ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-3 px-4 py-6 text-base"
                >
                    <Wallet className="h-5 w-5" />
                    <span>Buy Currency</span>
                </Button>
            </Link>
             <Dialog open={isCreatePostOpen} onOpenChange={setIsCreatePostOpen}>
              <DialogTrigger asChild>
                <Button className="mt-4 w-full">Create Post</Button>
              </DialogTrigger>
              <DialogContent className="p-0">
                  <CreatePostForm user={currentUser} onPostCreated={() => setIsCreatePostOpen(false)} onAction={() => setIsCreatePostOpen(false)} />
              </DialogContent>
            </Dialog>
          </nav>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
               <button className="mt-auto group w-full text-left">
                <UserAvatar user={currentUser} />
                <p className="mt-2 text-sm font-semibold group-hover:underline">{currentUser.name}</p>
                <p className="text-xs text-muted-foreground">@{currentUser.username}</p>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56 mb-2">
                <DropdownMenuItem onSelect={e => e.preventDefault()}>
                    <div className="flex items-center justify-between w-full">
                        <Label htmlFor="free-mode-desktop" className="flex items-center gap-2 cursor-pointer">
                            <Type className="h-4 w-4" /> Free Mode
                        </Label>
                        <Switch id="free-mode-desktop" checked={isFreeMode} onCheckedChange={toggleFreeMode} />
                    </div>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                {installPromptEvent && (
                    <DropdownMenuItem onClick={handleInstallClick}>
                        <Download className="mr-2 h-4 w-4" />
                        <span>Install App</span>
                    </DropdownMenuItem>
                )}
                <DropdownMenuItem asChild>
                    <Link href="/admin">
                        <Shield className="mr-2 h-4 w-4" />
                        <span>Admin</span>
                    </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                    <Link href="/settings">
                        <Settings className="mr-2 h-4 w-4" />
                        <span>Settings</span>
                    </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </aside>
      <main className="flex-1">
        {currentSong && <MiniPlayer variant="top" />}
        <div className={cn(currentSong && "pt-24")}>
            {children}
        </div>
        {showBottomAd && (
            <div className="fixed bottom-0 right-0 z-20 p-4" style={{width: 'calc(100% - 16rem)'}}>
                <AdBanner />
            </div>
        )}
      </main>
    </div>
    </AppContext.Provider>
  );
}

const mobileNavItems = [
  { href: '/', label: 'Home', icon: Home, key: 'home' },
  { href: '/music', label: 'Music', icon: Music, key: 'music' },
  { href: '/reels', label: 'Reels', icon: Video, key: 'reels' },
  { href: '/messages', label: 'Messages', icon: MessageCircle, key: 'messages' },
  { href: '/notifications', label: 'Notifications', icon: Bell, key: 'notifications' },
];

const desktopNavItems = [
  { href: '/', label: 'Home', icon: Home, key: 'home' },
  { href: '/reels', label: 'Reels', icon: Video, key: 'reels' },
  { href: '/friends', label: 'Friends', icon: Users, key: 'friends' },
  { href: '/messages', label: 'Messages', icon: MessageCircle, key: 'messages' },
  { href: '/notifications', label: 'Notifications', icon: Bell, key: 'notifications' },
  { href: '/music', label: 'Music', icon: Music, key: 'music' },
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, key: 'dashboard' },
];

function DesktopNavItem({ href, label, icon: Icon, notifications }: { href: string; label: string; icon: React.ElementType, notifications: { messages: number, notifications: number } }) {
  const pathname = usePathname();
  const isActive = pathname === '/' ? href === '/' : pathname.startsWith(href);
  const notifKey = href.substring(1) as keyof typeof notifications;
  const notifCount = (notifKey && notifications[notifKey]) ? notifications[notifKey] : 0;

  return (
    <Link href={href}>
      <Button
        variant={isActive ? 'secondary' : 'ghost'}
        className="w-full justify-start gap-3 px-4 py-6 text-base relative"
      >
        <Icon className="h-5 w-5" />
        <span>{label}</span>
        {notifCount > 0 && <NotificationBadge count={notifCount} className="absolute right-4 top-1/2 -translate-y-1/2 !-translate-x-0 !-translate-y-0" />}
      </Button>
    </Link>
  );
}

function NotificationBadge({ count, className }: { count: number, className?: string }) {
  if (count === 0) return null;
  
  const displayCount = count > 9 ? '9+' : count;

  return (
    <div className={cn("absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs font-bold text-white", className)}>
      {displayCount}
    </div>
  );
}
