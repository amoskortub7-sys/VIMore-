import { cn } from "@/lib/utils";

export function VIMoreLogo({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 100"
      xmlns="http://www.w3.org/2000/svg"
      className={cn("h-full w-full fill-primary", className)}
    >
      <path d="M10 10 L40 70 L50 50 L60 70 L90 10 L75 10 L50 40 L25 10 Z" />
    </svg>
  );
}
