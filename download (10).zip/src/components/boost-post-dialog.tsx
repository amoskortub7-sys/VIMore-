
'use client';

import * as React from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
  DialogDescription,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { User, Post } from '@/lib/data';
import { Diamond, TrendingUp, Lightbulb, UserCheck, Maximize, Loader2, ArrowLeft, Sparkles, Play, Music } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { formatNumber } from '@/lib/utils';
import Link from 'next/link';
import { Input } from './ui/input';
import { Card, CardContent } from './ui/card';
import { cn } from '@/lib/utils';
import { Slider } from './ui/slider';


interface BoostPostDialogProps {
  children: React.ReactNode;
  user: User;
  post: Post;
  contentType?: 'post' | 'music' | 'video';
  onBoost: () => void;
}

type BoostGoal = 'reach' | 'engagement' | 'followers' | 'streams' | 'sound-usage' | 'views';

type AiPlan = {
  goal: BoostGoal;
  targetAudience: string;
  duration: number;
  estimatedReach: string;
  predictedOutcome: string;
  cost: number;
}

const goalsConfig: Record<Required<BoostPostDialogProps>['contentType'], { value: BoostGoal; label: string; icon: React.ElementType }[]> = {
    post: [
        { value: 'reach', label: 'Reach', icon: Maximize },
        { value: 'engagement', label: 'Engagement', icon: Lightbulb },
        { value: 'followers', label: 'Followers', icon: UserCheck },
    ],
    music: [
        { value: 'streams', label: 'Streams', icon: Play },
        { value: 'sound-usage', label: 'Sound Usage', icon: Music },
        { value: 'followers', label: 'Artist Followers', icon: UserCheck },
    ],
    video: [
        { value: 'views', label: 'Views', icon: Play },
        { value: 'engagement', label: 'Engagement', icon: Lightbulb },
        { value: 'followers', label: 'Followers', icon: UserCheck },
    ],
};


export function BoostPostDialog({ children, user, post, contentType = 'post', onBoost }: BoostPostDialogProps) {
  const { toast } = useToast();
  const [step, setStep] = React.useState(1);
  
  const availableGoals = goalsConfig[contentType];
  const [goal, setGoal] = React.useState<BoostGoal>(availableGoals[0].value);
  
  const [budget, setBudget] = React.useState<number>(10);
  const [duration, setDuration] = React.useState<number>(7);
  const [isGenerating, setIsGenerating] = React.useState(false);
  const [aiPlan, setAiPlan] = React.useState<AiPlan | null>(null);
  
  const [localUser, setLocalUser] = React.useState(user);

  const estimatedReach = React.useMemo(() => {
    const baseReach = contentType === 'music' ? 5000 : 8000;
    const maxReach = contentType === 'music' ? 100000 : 140000;
    
    // Budget influence (5-50)
    const budgetFactor = (budget - 5) / (50 - 5); // Normalized 0-1
    
    // Duration influence (4-20)
    const durationFactor = (duration - 4) / (20 - 4); // Normalized 0-1
    
    // Give budget more weight
    const totalFactor = budgetFactor * 0.7 + durationFactor * 0.3;
    
    const reach = baseReach + totalFactor * (maxReach - baseReach);
    
    return Math.round(reach / 100) * 100; // Round to nearest 100
  }, [budget, duration, contentType]);


  const handleGeneratePlan = () => {
    if (budget < 5) {
        toast({ variant: 'destructive', title: 'Minimum budget is 5 💎' });
        return;
    }
    setIsGenerating(true);
    // Simulate AI analysis and plan generation
    setTimeout(() => {
        let targetAudience = '';
        let predictedOutcome = '';
        
        switch (goal) {
            case 'engagement':
                targetAudience = "Users who frequently like and comment on similar content.";
                predictedOutcome = `~${formatNumber(budget * 20)} new engagements`;
                break;
            case 'followers':
                 targetAudience = "People who follow creators with similar content to yours.";
                predictedOutcome = `~${formatNumber(budget * 2)} new followers`;
                break;
             case 'streams':
                targetAudience = "Listeners of similar genres and artists.";
                predictedOutcome = `~${formatNumber(budget * 100)} new streams`;
                break;
            case 'sound-usage':
                targetAudience = "Creators who use trending and similar sounds.";
                predictedOutcome = `~${formatNumber(budget * 5)} new videos using your sound`;
                break;
            case 'views':
                targetAudience = "A broad audience interested in your video's topics.";
                predictedOutcome = `Up to ${formatNumber(estimatedReach)} video views`;
                break;
            case 'reach':
            default:
                targetAudience = "A broad audience interested in your post's topics.";
                predictedOutcome = `Up to ${formatNumber(estimatedReach)} people reached`;
                break;
        }

        setAiPlan({
            goal,
            targetAudience,
            duration,
            estimatedReach: formatNumber(estimatedReach),
            predictedOutcome,
            cost: budget
        });

        setIsGenerating(false);
        setStep(2);
    }, 1500);
  }

  const handleLaunchBoost = () => {
    if (!aiPlan) return;

    if (localUser.diamonds < aiPlan.cost) {
      toast({
        variant: 'destructive',
        title: 'Insufficient Diamonds',
        description: `You need ${aiPlan.cost} 💎 to boost this post.`,
        action: <Link href="/buy-currency"><Button variant="secondary">Buy</Button></Link>
      });
      return;
    }
    
    setLocalUser(prev => ({...prev, diamonds: prev.diamonds - aiPlan.cost}));

    toast({
      title: 'Post Boosted!',
      description: `Your post is now being shown to a wider audience for ${aiPlan.duration} days.`,
    });
    onBoost();
    setStep(1); // Reset for next time
    setAiPlan(null);
  }
  
  const resetAndClose = () => {
    setStep(1);
    setAiPlan(null);
    setIsGenerating(false);
  }

  return (
    <Dialog onOpenChange={(open) => !open && resetAndClose()}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>
             {step === 2 && (
                <button onClick={() => setStep(1)} className="flex items-center gap-2 -ml-4 mb-2">
                    <ArrowLeft className="h-4 w-4" /> Back
                </button>
             )}
             {step === 1 ? 'Boost ' + contentType.charAt(0).toUpperCase() + contentType.slice(1) : 'AI-Generated Boost Plan'}
          </DialogTitle>
          <DialogDescription>
             {step === 1 
                ? "Let our AI create the optimal boost strategy for your content."
                : "Our AI has analyzed your content and audience to create this plan. Review and launch your boost."
             }
          </DialogDescription>
        </DialogHeader>

        {step === 1 && (
            <div className="space-y-6 py-4">
                <div>
                    <Label className="font-semibold">1. Choose your goal</Label>
                    <div className="mt-2 grid grid-cols-3 gap-2">
                       {availableGoals.map(g => (
                         <GoalButton key={g.value} icon={g.icon} label={g.label} value={g.value} selected={goal} onSelect={setGoal}/>
                       ))}
                    </div>
                </div>
                 <div>
                    <Label htmlFor="budget" className="font-semibold flex justify-between">
                        <span>2. Set your budget</span>
                        <span className="font-bold text-primary">{budget} 💎</span>
                    </Label>
                    <Slider id="budget" value={[budget]} onValueChange={(val) => setBudget(val[0])} min={5} max={50} step={1} className="mt-2" />
                    <p className="text-xs text-muted-foreground mt-1">Your current balance: {formatNumber(localUser.diamonds)} 💎</p>
                </div>
                 <div>
                    <Label htmlFor="duration" className="font-semibold flex justify-between">
                        <span>3. Set the duration</span>
                        <span className="font-bold text-primary">{duration} days</span>
                    </Label>
                    <Slider id="duration" value={[duration]} onValueChange={(val) => setDuration(val[0])} min={4} max={20} step={1} className="mt-2" />
                </div>
                <div className="text-center bg-secondary p-3 rounded-lg">
                    <p className="text-sm text-muted-foreground">Estimated Reach / Views</p>
                    <p className="text-3xl font-bold">{formatNumber(estimatedReach)}</p>
                </div>
                <Button onClick={handleGeneratePlan} className="w-full" disabled={isGenerating}>
                    {isGenerating ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Sparkles className="mr-2 h-4 w-4"/>}
                    {isGenerating ? 'Analyzing...' : 'Generate AI Boost Strategy'}
                </Button>
            </div>
        )}
        
        {step === 2 && aiPlan && (
            <div className="space-y-4 py-4">
                <Card className="bg-secondary">
                    <CardContent className="p-4 grid grid-cols-2 gap-4 text-center">
                        <div>
                            <p className="text-sm text-muted-foreground">Est. Reach/Views</p>
                            <p className="text-2xl font-bold flex items-center justify-center gap-1"><TrendingUp className="h-5 w-5"/>{aiPlan.estimatedReach}</p>
                        </div>
                         <div>
                            <p className="text-sm text-muted-foreground">Predicted Outcome</p>
                            <p className="text-xl font-bold flex items-center justify-center gap-1">{aiPlan.predictedOutcome}</p>
                        </div>
                    </CardContent>
                </Card>
                <div className="text-sm space-y-2">
                    <p><strong>Goal:</strong> <span className="capitalize">{aiPlan.goal.replace('-', ' ')}</span></p>
                    <p><strong>Target Audience:</strong> {aiPlan.targetAudience}</p>
                    <p><strong>Duration:</strong> {aiPlan.duration} days</p>
                </div>
                <DialogFooter>
                    <DialogClose asChild>
                         <Button onClick={handleLaunchBoost} className="w-full">
                           Launch Boost for {aiPlan.cost} 💎
                        </Button>
                    </DialogClose>
                </DialogFooter>
            </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function GoalButton({ icon: Icon, label, value, selected, onSelect }: { icon: React.ElementType, label: string, value: BoostGoal, selected: BoostGoal, onSelect: (value: BoostGoal) => void }) {
    const isSelected = selected === value;
    return (
        <button
            onClick={() => onSelect(value)}
            className={cn(
                "p-2 rounded-lg border flex flex-col items-center justify-center text-center gap-1 transition-colors",
                isSelected ? "bg-primary text-primary-foreground border-primary" : "bg-card hover:bg-accent"
            )}
        >
            <Icon className="h-6 w-6"/>
            <span className="text-xs font-semibold">{label}</span>
        </button>
    )
}
