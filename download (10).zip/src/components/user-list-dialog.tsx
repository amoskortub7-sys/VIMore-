'use client';

import * as React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { MessageCircle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { UserAvatar } from '@/components/user-avatar';
import { User, mockConversations } from '@/lib/data';
import { useToast } from '@/hooks/use-toast';
import { VerifiedBadge } from './verified-badge';
import { AppContext } from './app-shell';
import { Skeleton } from './ui/skeleton';
import { getFollowing, toggleFollow } from '@/services/userService';

export function UserListDialog({ title, users, children }: { title: string, users: User[], children: React.ReactNode }) {
    if (users.length === 0) {
        return <div>{children}</div>;
    }
    
    return (
        <Dialog>
            <DialogTrigger asChild>
                {children}
            </DialogTrigger>
            <DialogContent className="max-w-md">
                <DialogHeader>
                    <DialogTitle>{title}</DialogTitle>
                </DialogHeader>
                <UserList users={users} />
            </DialogContent>
        </Dialog>
    )
}

function UserList({ users }: { users: User[] }) {
    const router = useRouter();
    const { toast } = useToast();
    const appContext = React.useContext(AppContext);

    const [friends, setFriends] = React.useState<User[]>([]); // "Friends" means who the current user is following
    const [isLoading, setIsLoading] = React.useState(true);

    const currentUser = appContext?.currentUser;

    React.useEffect(() => {
        const fetchRelations = async () => {
            if (!currentUser) return;
            setIsLoading(true);
            try {
                const userFollowing = await getFollowing(currentUser.id);
                setFriends(userFollowing);
            } catch (error) {
                console.error("Failed to fetch following list", error);
            } finally {
                setIsLoading(false);
            }
        }
        fetchRelations();
    }, [currentUser]);


    const handleMessage = (user: User) => {
        if (!currentUser) return;
        const conversation = mockConversations.find(c => c.participants.some(p => p.id === user.id) && c.participants.some(p => p.id === currentUser.id));
        if (conversation) {
            router.push(`/messages?conversationId=${conversation.id}`);
        }
    };
    
    const handleFollowToggle = async (targetUser: User, isFollowing: boolean) => {
        if (!currentUser) return;

        const oldFriends = [...friends];
        if (isFollowing) {
            setFriends(prev => prev.filter(f => f.id !== targetUser.id));
            toast({ title: `Unfollowed ${targetUser.name}` });
        } else {
            setFriends(prev => [...prev, targetUser]);
            toast({ title: `You are now following ${targetUser.name}` });
        }
        
        try {
            await toggleFollow(currentUser.id, targetUser.id, isFollowing);
        } catch (error) {
            setFriends(oldFriends);
            toast({ variant: 'destructive', title: 'Action failed. Please try again.' });
        }
    };
    
    const getButtonAction = (user: User) => {
        if (!currentUser || user.id === currentUser.id) return null;

        const isFriend = friends.some(f => f.id === user.id);

        if (isFriend) {
            return (
                <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline" onClick={() => handleFollowToggle(user, true)}>Following</Button>
                    <Button size="sm" variant="ghost" className="px-2" onClick={() => handleMessage(user)}>
                        <MessageCircle className="h-5 w-5 text-muted-foreground" />
                    </Button>
                </div>
            );
        }
        
        return <Button size="sm" onClick={() => handleFollowToggle(user, false)}>Follow</Button>;
    };

     if (isLoading || !currentUser) {
        return (
            <div className="h-96 p-4 space-y-4">
                {Array.from({length: 5}).map((_, i) => (
                    <div key={i} className="flex items-center gap-4">
                        <Skeleton className="h-10 w-10 rounded-full" />
                        <div className="flex-1 space-y-2">
                            <Skeleton className="h-4 w-2/3" />
                            <Skeleton className="h-3 w-1/3" />
                        </div>
                    </div>
                ))}
            </div>
        );
    }

    return (
        <ScrollArea className="h-96">
            <div className="flex flex-col gap-4 p-4">
                {users.map(user => (
                    <div key={user.id} className="flex items-center gap-4">
                        <Link href={`/profile/${user.username}`}>
                            <UserAvatar user={user} />
                        </Link>
                        <div className="flex-1">
                            <Link href={`/profile/${user.username}`} className="hover:underline">
                                <p className="font-semibold inline-flex items-center">
                                  {user.name}
                                  <VerifiedBadge user={user} />
                                </p>
                            </Link>
                            <p className="text-sm text-muted-foreground">@{user.username}</p>
                        </div>
                        {getButtonAction(user)}
                    </div>
                ))}
            </div>
        </ScrollArea>
    );
}
