
'use client';

import { Check } from 'lucide-react';
import type { User } from '@/lib/data';

export function VerifiedBadge({ user }: { user: User }) {
  const isVerified = user.isSuperAdmin || !!user.adminRole || !!user.isVerified;

  if (!isVerified) {
    return null;
  }
  
  return (
    <span className="inline-block h-4 w-4 ml-1 rounded-full bg-purple-500 flex-shrink-0">
      <Check className="h-4 w-4 text-white p-0.5" />
    </span>
  );
}
