
"use client";

import Link from 'next/link';
import Image from 'next/image';
import { PlusCircle } from 'lucide-react';
import type { Story } from '@/lib/data';
import { UserAvatar } from './user-avatar';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import * as React from 'react';
import { AppContext } from './app-shell';

export function Stories() {
  const appContext = React.useContext(AppContext);

  if (!appContext) {
    return null;
  }
  
  const { isFreeMode, currentUser } = appContext;

  if (isFreeMode || !currentUser) {
    return null;
  }

  // In a real app, you would fetch stories from a service.
  // For now, we use an empty array as the mock data has been removed.
  const stories: Story[] = [];

  return (
    <section>
        <ScrollArea className="w-full whitespace-nowrap">
            <div className="flex gap-2 p-2">
                {/* Add your own story */}
                 <Link href="/create/video">
                   <Card className="relative h-48 w-28 shrink-0 overflow-hidden group">
                        <Image
                            src={currentUser.avatar.imageUrl}
                            alt="Your story"
                            fill
                            className="object-cover transition-transform group-hover:scale-105"
                            data-ai-hint={currentUser.avatar.imageHint}
                        />
                        <div className="absolute inset-0 bg-black/20"></div>
                        <CardContent className="absolute bottom-0 flex h-full flex-col justify-end p-2 text-white">
                             <div className="flex-grow flex items-center justify-center">
                                <div className="rounded-full bg-primary text-primary-foreground p-1">
                                    <PlusCircle className="h-6 w-6" />
                                </div>
                            </div>
                            <p className="w-full truncate text-center text-xs font-semibold">Create Story</p>
                        </CardContent>
                    </Card>
                </Link>

                {/* Other users' stories */}
                {stories.map((story) => (
                    <Link key={story.id} href={`/stories/${story.user.username}`}>
                        <Card className="relative h-48 w-28 shrink-0 overflow-hidden group">
                            <Image
                                src={story.pages[0].image.imageUrl}
                                alt={`Story by ${story.user.name}`}
                                fill
                                className="object-cover transition-transform group-hover:scale-105"
                                data-ai-hint={story.pages[0].image.imageHint}
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                            <CardContent className="absolute inset-0 flex flex-col p-2 text-white">
                                <UserAvatar
                                    user={story.user}
                                    className={cn("h-9 w-9 border-2", story.user.id === 'user-1' ? 'border-blue-500' : 'border-primary')}
                                />
                                <div className="mt-auto">
                                  <p className="w-full truncate text-xs font-semibold">{story.user.name}</p>
                                </div>
                            </CardContent>
                        </Card>
                    </Link>
                ))}
            </div>
            <ScrollBar orientation="horizontal" />
        </ScrollArea>
    </section>
  );
}
