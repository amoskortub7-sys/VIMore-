

'use client';

import * as React from 'react';
import { Play, Pause } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export function AdVideoPost() {
  const videoRef = React.useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = React.useState(false);
  const [showControls, setShowControls] = React.useState(false);

  const observer = React.useRef<IntersectionObserver>();

  React.useEffect(() => {
    observer.current = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            videoRef.current?.play();
            setIsPlaying(true);
          } else {
            videoRef.current?.pause();
            setIsPlaying(false);
          }
        });
      },
      { threshold: 0.5 }
    );

    if (videoRef.current) {
      observer.current.observe(videoRef.current);
    }

    return () => {
      if (videoRef.current) {
        observer.current?.unobserve(videoRef.current);
      }
    };
  }, []);

  const handleVideoTap = () => {
    if (isPlaying) {
      videoRef.current?.pause();
    } else {
      videoRef.current?.play();
    }
    setIsPlaying(!isPlaying);
    setShowControls(true);
    setTimeout(() => setShowControls(false), 800);
  };

  return (
    <div className="relative h-full w-full bg-black flex items-center justify-center" onClick={handleVideoTap}>
      <video
        ref={videoRef}
        src="https://storage.googleapis.com/static.a-studio.dev/videos/ad-placeholder.mp4"
        loop
        playsInline
        muted // Ads are often muted by default
        className="w-full h-full object-contain"
      />

      <AnimatePresence>
        {showControls && (
          <motion.div
            initial={{ opacity: 0, scale: 1.5 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.5 }}
            transition={{ duration: 0.2 }}
            className="absolute"
          >
            {isPlaying ? (
              <Play className="h-20 w-20 text-white/50" />
            ) : (
              <Pause className="h-20 w-20 text-white/50" />
            )}
          </motion.div>
        )}
      </AnimatePresence>

      <div 
        className="absolute bottom-0 left-0 right-0 z-10 text-white p-4 bg-gradient-to-t from-black/50 to-transparent"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2">
            <span className="text-xs font-bold bg-white/20 px-2 py-0.5 rounded-sm">Ad</span>
            <p className="text-sm font-semibold">Example Product Name</p>
        </div>
        <p className="text-sm text-white/80 mt-1">A short, catchy description of the product or service being advertised.</p>
        <a href="#" className="text-sm font-bold mt-2 inline-block bg-primary text-primary-foreground px-4 py-2 rounded-md">
            Learn More
        </a>
      </div>
    </div>
  );
}
