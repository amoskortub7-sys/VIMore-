
'use client';

import { Info } from 'lucide-react';
import { cn } from '@/lib/utils';

export function AdBanner({ className }: { className?: string }) {
  return (
    <div className={cn("flex h-14 items-center justify-center rounded-lg bg-secondary text-secondary-foreground", className)}>
      <div className="flex items-center gap-2 text-sm">
        <Info className="h-4 w-4" />
        <p>Advertisement - Your ad could be here!</p>
      </div>
    </div>
  );
}
