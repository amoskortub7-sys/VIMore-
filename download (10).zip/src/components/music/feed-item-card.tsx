'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Album, Music, Play, UserCheck, UserPlus } from 'lucide-react';
import type { MusicFeedItem, Album as AlbumType, Playlist, User } from '@/lib/data';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { UserAvatar } from '../user-avatar';
import { Button } from '../ui/button';
import { useMusicPlayer } from './music-player-provider';
import { PlaylistCard } from './playlist-card';
import { AlbumCard } from './album-card';
import { useToast } from '@/hooks/use-toast';
import { VerifiedBadge } from '../verified-badge';
import React from 'react';
import { AppContext } from '../app-shell';

interface FeedItemCardProps {
    item: MusicFeedItem;
    followedUsers: User[];
    onFollowToggle: (user: User) => void;
}

export function FeedItemCard({ item, followedUsers, onFollowToggle }: FeedItemCardProps) {
  if (item.type === 'new-album') {
    return <NewAlbumCard item={item} followedUsers={followedUsers} onFollowToggle={onFollowToggle} />;
  }

  if (item.type === 'new-playlist') {
    return <NewPlaylistCard item={item} followedUsers={followedUsers} onFollowToggle={onFollowToggle} />;
  }

  return null;
}

interface FeedItemHeaderProps {
    user: User; 
    timestamp: string; 
    children: React.ReactNode;
    followedUsers: User[];
    onFollowToggle: (user: User) => void;
}

function FeedItemHeader({ user, timestamp, children, followedUsers, onFollowToggle }: FeedItemHeaderProps) {
    const { toast } = useToast();
    const isFollowing = followedUsers.some(u => u.id === user.id);
    const appContext = React.useContext(AppContext);
    const currentUser = appContext?.currentUser;

    const handleFollowClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        onFollowToggle(user);
        toast({
            title: isFollowing ? `Unfollowed ${user.name}` : `Followed ${user.name}`,
        });
    }

    if (!currentUser) return null;

    return (
        <CardHeader className="flex-row items-center gap-4 space-y-0">
            <Link href={`/profile/${user.username}`}>
                <UserAvatar user={user} className="h-12 w-12" />
            </Link>
            <div>
                <p className="text-muted-foreground">
                    <Link href={`/profile/${user.username}`} className="font-bold text-foreground hover:underline inline-flex items-center">
                      {user.name}
                      <VerifiedBadge user={user} />
                    </Link>
                    {' '}
                    {children}
                </p>
                <p className="text-xs text-muted-foreground">{timestamp}</p>
            </div>
            {user.id !== currentUser.id && (
                <Button variant="outline" size="sm" className="ml-auto shrink-0" onClick={handleFollowClick}>
                    {isFollowing ? (
                        <>
                            <UserCheck className="mr-2 h-4 w-4" />
                            Following
                        </>
                    ) : (
                        <>
                            <UserPlus className="mr-2 h-4 w-4" />
                            Follow
                        </>
                    )}
                </Button>
            )}
        </CardHeader>
    )
}

interface ItemCardProps {
    item: MusicFeedItem;
    followedUsers: User[];
    onFollowToggle: (user: User) => void;
}


function NewAlbumCard({ item, followedUsers, onFollowToggle }: ItemCardProps) {
  const { playSong } = useMusicPlayer();
  if (item.type !== 'new-album') return null;
  const { user, album, timestamp } = item;
  
  const handlePlayAlbum = () => {
    if (album.songs.length > 0) {
      playSong(album.songs[0], album.songs);
    }
  };

  return (
    <Card>
      <FeedItemHeader user={user} timestamp={timestamp} followedUsers={followedUsers} onFollowToggle={onFollowToggle}>
        released a new album
      </FeedItemHeader>
      <CardContent>
        <div className="flex flex-col sm:flex-row gap-6">
            <AlbumCard album={album} className="w-full sm:w-48 sm:shrink-0" width={200} height={200}/>
            <div className="flex-1">
                <div className="flex flex-col">
                    {album.songs.slice(0, 5).map((song, index) => (
                        <div key={song.id} className="flex items-center gap-4 p-2 -ml-2 rounded-md hover:bg-accent group">
                            <div className="w-6 text-center text-muted-foreground font-mono text-sm">{index + 1}</div>
                            <div className="flex-1">
                                <p className="font-semibold truncate">{song.title}</p>
                            </div>
                            <div className="text-sm text-muted-foreground font-mono">{song.duration}</div>
                            <Button variant="ghost" size="icon" className="w-8 h-8 opacity-0 group-hover:opacity-100" onClick={() => playSong(song, album.songs)}>
                                <Play className="w-4 h-4"/>
                            </Button>
                        </div>
                    ))}
                    {album.songs.length > 5 && (
                         <div className="flex items-center gap-4 p-2 text-muted-foreground text-sm">
                             <div className="w-6 text-center font-mono">...</div>
                             <div>{album.songs.length - 5} more tracks</div>
                         </div>
                    )}
                </div>
            </div>
        </div>
      </CardContent>
    </Card>
  );
}

function NewPlaylistCard({ item, followedUsers, onFollowToggle }: ItemCardProps) {
  const { playSong } = useMusicPlayer();
  if (item.type !== 'new-playlist') return null;
  const { user, playlist, timestamp } = item;

  return (
    <Card>
        <FeedItemHeader user={user} timestamp={timestamp} followedUsers={followedUsers} onFollowToggle={onFollowToggle}>
            created a new playlist
        </FeedItemHeader>
        <CardContent>
             <div className="flex flex-col sm:flex-row gap-6">
                <PlaylistCard playlist={playlist} className="w-full sm:w-48 sm:shrink-0 aspect-[1/1]" />
                <div className="flex-1">
                    <div className="flex flex-col">
                        {playlist.songs.slice(0, 5).map((song) => (
                            <div key={song.id} className="flex items-center gap-4 p-2 -ml-2 rounded-md hover:bg-accent group">
                                <Music className="w-5 h-5 text-muted-foreground" />
                                <div className="flex-1 overflow-hidden">
                                    <p className="font-semibold truncate">{song.title}</p>
                                    <p className="text-sm text-muted-foreground truncate">{song.artist.name}</p>
                                </div>
                                <Button variant="ghost" size="icon" className="w-8 h-8 opacity-0 group-hover:opacity-100" onClick={() => playSong(song, playlist.songs)}>
                                    <Play className="w-4 h-4"/>
                                </Button>
                            </div>
                        ))}
                         {playlist.songs.length > 5 && (
                            <div className="flex items-center gap-4 p-2 text-muted-foreground text-sm">
                                <div className="w-5 text-center">...</div>
                                <div>{playlist.songs.length - 5} more tracks</div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </CardContent>
    </Card>
  );
}
