

'use client';

import * as React from 'react';
import Image from 'next/image';
import { notFound, useRouter } from 'next/navigation';
import { PlayCircle, Shuffle, Gift, Download, Heart, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { SongListItem } from '@/components/music/song-list-item';
import { useMusicPlayer } from '@/components/music/music-player-provider';
import { GiftingDialog } from '@/components/gifting-dialog';
import { SupportDialog } from '@/components/support-dialog';
import { VerifiedBadge } from '@/components/verified-badge';
import { getPlaylistById } from '@/services/musicService';
import { getUser } from '@/services/userService';
import type { Playlist, User } from '@/lib/data';
import { AppContext } from '@/components/app-shell';
import { canUserBeTipped } from '@/lib/monetization-rules';


export default function PlaylistPage({ params }: { params: { playlistId: string } }) {
  const { playSong, downloadPlaylist } = useMusicPlayer();
  const { playlistId } = params;
  
  const [playlist, setPlaylist] = React.useState<Playlist | null>(null);
  const [creator, setCreator] = React.useState<User | null>(null);
  const [isLoading, setIsLoading] = React.useState(true);
  
  const appContext = React.useContext(AppContext);
  const currentUser = appContext?.currentUser;

  React.useEffect(() => {
    const fetchPlaylist = async () => {
        setIsLoading(true);
        const fetchedPlaylist = await getPlaylistById(playlistId);
        if (fetchedPlaylist) {
            setPlaylist(fetchedPlaylist);
            if(fetchedPlaylist.createdBy) {
                const fetchedCreator = await getUser(fetchedPlaylist.createdBy);
                setCreator(fetchedCreator);
            }
        } else {
            notFound();
        }
        setIsLoading(false);
    };
    fetchPlaylist();
  }, [playlistId]);


  if (isLoading || !playlist || !currentUser) {
    return <div className="flex h-screen items-center justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>;
  }
  
  const handlePlayPlaylist = () => {
    if (playlist.songs.length > 0) {
      playSong(playlist.songs[0], playlist.songs);
    }
  };

  const handleDownloadPlaylist = () => {
    if (playlist.songs.length > 0) {
      downloadPlaylist(playlist.songs);
    }
  }
  
  const isOwnPlaylist = creator?.id === currentUser.id;
  const canBeTipped = creator ? canUserBeTipped(creator) : false;

  return (
    <div className="container mx-auto max-w-5xl py-4 sm:py-6">
        <div className="flex flex-col sm:flex-row items-center gap-6 sm:gap-8">
            <div className="relative w-48 h-48 sm:w-56 sm:h-56 shrink-0">
                <Image
                    src={playlist.cover.imageUrl}
                    alt={playlist.title}
                    fill
                    className="rounded-lg object-cover shadow-lg"
                />
            </div>
            <div className="text-center sm:text-left">
                <p className="text-sm uppercase text-muted-foreground font-bold">Playlist</p>
                <h1 className="font-headline text-4xl sm:text-5xl md:text-6xl font-extrabold mt-2 break-words">{playlist.title}</h1>
                <p className="text-lg text-muted-foreground mt-4">{playlist.description}</p>
                {creator && (
                    <p className="text-sm text-muted-foreground mt-2 inline-flex items-center">
                        Created by {creator.name}
                        <VerifiedBadge user={creator} />
                    </p>
                )}
            </div>
        </div>

        <div className="flex flex-wrap items-center gap-4 my-8">
            <Button size="lg" className="rounded-full px-6 gap-2" onClick={handlePlayPlaylist}>
                <PlayCircle className="h-6 w-6"/>
                Play
            </Button>
             <Button size="lg" variant="secondary" className="rounded-full px-6 gap-2">
                <Shuffle className="h-6 w-6"/>
                Shuffle
            </Button>
            <Button size="lg" variant="secondary" className="rounded-full px-6 gap-2" onClick={handleDownloadPlaylist}>
                <Download className="h-6 w-6"/>
                Download
            </Button>
             {creator && !isOwnPlaylist && (
                <GiftingDialog currentUser={currentUser} creator={creator}>
                    <Button size="lg" variant="secondary" className="rounded-full px-6 gap-2">
                        <Gift className="h-6 w-6"/>
                        Gift
                    </Button>
                </GiftingDialog>
            )}
            {canBeTipped && !isOwnPlaylist && (
                <SupportDialog currentUser={currentUser} creator={creator}>
                    <Button size="lg" variant="secondary" className="rounded-full px-6 gap-2 bg-amber-400/20 text-amber-600 hover:bg-amber-400/30">
                        <Heart className="h-6 w-6"/>
                        Support
                    </Button>
                </SupportDialog>
            )}
        </div>

        <div className="flex flex-col">
            {playlist.songs.map((song, index) => (
                <SongListItem key={song.id} song={song} playlist={playlist.songs} index={index} />
            ))}
        </div>
    </div>
  );
}
