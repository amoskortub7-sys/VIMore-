
'use client';

import Image from 'next/image';
import Link from 'next/link';
import { cn } from '@/lib/utils';
import { Album } from '@/lib/data';
import { PlayCircle } from 'lucide-react';
import React from 'react';

interface AlbumCardProps {
  album: Album;
  className?: string;
  width?: number;
  height?: number;
}

export function AlbumCard({ album, className, width, height }: AlbumCardProps) {

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    // We stop propagation to prevent parent Link components from navigating
    // if the user intends to click a button inside the card.
    if ((e.target as HTMLElement).closest('button')) {
      e.preventDefault();
    }
  };

  return (
    <div className={cn("space-y-3 shrink-0", className)}>
      <Link href={`/music/album/${album.id}`} onClick={handleClick}>
        <div className="overflow-hidden rounded-md group relative">
          <Image
            src={album.cover.imageUrl}
            alt={album.title}
            width={width}
            height={height}
            className="h-auto w-auto object-cover transition-all group-hover:scale-105"
            data-ai-hint={album.cover.imageHint}
          />
          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <PlayCircle className="w-12 h-12 text-white/80" />
          </div>
        </div>
      </Link>
      <div className="space-y-1 text-sm">
        <Link href={`/music/album/${album.id}`} className="hover:underline" onClick={handleClick}>
            <h3 className="font-medium leading-none truncate">{album.title}</h3>
        </Link>
        <p className="text-xs text-muted-foreground truncate">{album.artist.name}</p>
      </div>
    </div>
  );
}
