
'use client';

import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import type { Song } from '@/lib/data';
import { NowPlaying } from './now-playing';
import { InterstitialAd } from './interstitial-ad';
import { useToast } from '@/hooks/use-toast';
import { AppContext } from '../app-shell';
import { updateUser } from '@/services/userService';

type RepeatMode = 'off' | 'playlist' | 'song';

type InterstitialRequest = {
  adCount: number;
  onComplete: () => void;
} | null;

interface MusicPlayerState {
  currentSong: Song | null;
  playlist: Song[];
  isPlaying: boolean;
  isFullScreen: boolean;
  isShuffled: boolean;
  repeatMode: RepeatMode;
  likedSongs: Set<string>;
  downloadedSongs: Set<string>;
  trackProgress: number;
  interstitialRequest: InterstitialRequest;
}

interface MusicPlayerContextType extends MusicPlayerState {
  playSong: (song: Song, playlist?: Song[]) => void;
  togglePlay: () => void;
  playNext: () => void;
  playPrev: () => void;
  toggleShuffle: () => void;
  toggleRepeat: () => void;
  toggleLike: (songId: string) => void;
  isLiked: (songId: string) => boolean;
  isDownloaded: (songId: string) => boolean;
  setPlayerState: (state: Partial<MusicPlayerState>) => void;
  seek: (progress: number) => void;
  stopAndClearPlayer: () => void;
  downloadSong: (song: Song) => void;
  downloadPlaylist: (songs: Song[]) => void;
}

const MusicPlayerContext = createContext<MusicPlayerContextType | undefined>(undefined);

const initialState: MusicPlayerState = {
  currentSong: null,
  playlist: [],
  isPlaying: false,
  isFullScreen: false,
  isShuffled: false,
  repeatMode: 'off',
  likedSongs: new Set(),
  downloadedSongs: new Set(),
  trackProgress: 0,
  interstitialRequest: null,
};


export const MusicPlayerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<MusicPlayerState>(initialState);
  const { toast } = useToast();
  const appContext = useContext(AppContext);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const originalPlaylistRef = useRef<Song[]>([]);

  const setPlayerState = (newState: Partial<MusicPlayerState>) => {
    setState(prevState => ({ ...prevState, ...newState }));
  };
  
  useEffect(() => {
    if (typeof window !== "undefined" && !audioRef.current) {
      audioRef.current = new Audio();
    }
  }, []);
  
  useEffect(() => {
    // Load liked songs from user object on mount
    if (appContext?.currentUser?.likedSongIds) {
      setPlayerState({ likedSongs: new Set(appContext.currentUser.likedSongIds) });
    }
  }, [appContext?.currentUser?.likedSongIds]);
  
  useEffect(() => {
    if (state.isPlaying && audioRef.current && state.currentSong) {
        if(audioRef.current.src !== state.currentSong.src) {
             audioRef.current.src = state.currentSong.src;
        }
        audioRef.current.play().catch(e => console.error("Error playing audio:", e));
    } else if (audioRef.current) {
        audioRef.current.pause();
    }
  }, [state.isPlaying, state.currentSong]);

  const playSong = useCallback((song: Song, playlist?: Song[]) => {
    const newPlaylist = playlist || [song];
    originalPlaylistRef.current = newPlaylist;

    setPlayerState({ 
        currentSong: song,
        playlist: state.isShuffled ? shuffleArray([...newPlaylist]) : newPlaylist,
        isPlaying: true,
    });
  }, [state.isShuffled]);

  const playNext = useCallback(() => {
    if (!state.currentSong || state.playlist.length === 0) return;
    const currentIndex = state.playlist.findIndex(s => s.id === state.currentSong?.id);
    let nextIndex = (currentIndex + 1);
    if (nextIndex >= state.playlist.length) {
      if (state.repeatMode === 'playlist') {
        nextIndex = 0;
      } else {
        setPlayerState({ isPlaying: false });
        return;
      }
    }
    playSong(state.playlist[nextIndex], originalPlaylistRef.current);
  }, [state.currentSong, state.playlist, playSong, state.repeatMode]);


  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTimeUpdate = () => {
      if (audio.duration) {
        setPlayerState({ trackProgress: (audio.currentTime / audio.duration) * 100 });
      }
    };

    const handleEnded = () => {
        if (state.repeatMode === 'song') {
            audio.currentTime = 0;
            audio.play();
        } else {
            playNext();
        }
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('ended', handleEnded);
    };
  }, [state.currentSong, state.playlist, state.repeatMode, playNext]);


  const togglePlay = () => {
    if (!state.currentSong) return;
    setPlayerState({ isPlaying: !state.isPlaying });
  };
  
  const playPrev = () => {
    if (!state.currentSong || state.playlist.length === 0) return;
     if (audioRef.current && audioRef.current.currentTime > 3) {
      audioRef.current.currentTime = 0;
      return;
    }
    const currentIndex = state.playlist.findIndex(s => s.id === state.currentSong?.id);
    const prevIndex = (currentIndex - 1 + state.playlist.length) % state.playlist.length;
    playSong(state.playlist[prevIndex], originalPlaylistRef.current);
  };
  
  const seek = (progress: number) => {
    if (audioRef.current && state.currentSong) {
        const newTime = (progress / 100) * audioRef.current.duration;
        if (!isNaN(newTime)) {
            audioRef.current.currentTime = newTime;
        }
    }
  };

  const shuffleArray = (array: Song[]) => {
    let currentIndex = array.length, randomIndex;
    while (currentIndex !== 0) {
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex--;
      [array[currentIndex], array[randomIndex]] = [
        array[randomIndex], array[currentIndex]];
    }
    return array;
  }

  const toggleShuffle = () => {
    const isShuffled = !state.isShuffled;
    setPlayerState({
        isShuffled,
        playlist: isShuffled
            ? shuffleArray([...originalPlaylistRef.current])
            : originalPlaylistRef.current,
    });
  };

  const toggleRepeat = () => {
    const modes: RepeatMode[] = ['off', 'playlist', 'song'];
    const currentModeIndex = modes.indexOf(state.repeatMode);
    const nextModeIndex = (currentModeIndex + 1) % modes.length;
    setPlayerState({ repeatMode: modes[nextModeIndex] });
  };

  const toggleLike = async (songId: string) => {
    const { currentUser, setCurrentUser } = appContext || {};
    if (!currentUser || !setCurrentUser) {
        toast({ variant: 'destructive', title: 'You must be logged in to like songs.' });
        return;
    }

    const newLikedSongs = new Set(state.likedSongs);
    const oldLikedSongs = new Set(state.likedSongs);

    if (newLikedSongs.has(songId)) {
        newLikedSongs.delete(songId);
    } else {
        newLikedSongs.add(songId);
    }
    
    // Optimistic UI update
    setPlayerState({ likedSongs: newLikedSongs });

    try {
        const likedSongIds = Array.from(newLikedSongs);
        await updateUser(currentUser.id, { likedSongIds });
        setCurrentUser({ ...currentUser, likedSongIds });
    } catch (error) {
        console.error("Failed to update liked songs:", error);
        // Revert on failure
        setPlayerState({ likedSongs: oldLikedSongs });
        toast({ variant: 'destructive', title: 'Could not save like.' });
    }
  };
  
  const isLiked = (songId: string) => state.likedSongs.has(songId);
  const isDownloaded = (songId: string) => state.downloadedSongs.has(songId);
  
  const stopAndClearPlayer = () => {
    if(audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = '';
    }
    // Keep liked and downloaded songs
    setPlayerState({
      ...initialState,
      likedSongs: state.likedSongs,
      downloadedSongs: state.downloadedSongs,
    });
  }

  const cacheUrls = (urls: string[]) => {
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'CACHE_URLS',
        payload: urls,
      });
    }
  };

  const handleAdClose = () => {
    if (state.interstitialRequest) {
      state.interstitialRequest.onComplete();
    }
    setPlayerState({ interstitialRequest: null });
  };

  const downloadSong = (song: Song) => {
    setPlayerState({
      interstitialRequest: {
        adCount: 1,
        onComplete: () => {
          cacheUrls([song.src, song.album.cover.imageUrl]);
          setPlayerState({ downloadedSongs: new Set(state.downloadedSongs).add(song.id) });
          toast({ title: "Download started!", description: "The song will be available offline shortly." });
        }
      }
    });
  };
  
  const downloadPlaylist = (songs: Song[]) => {
     setPlayerState({
      interstitialRequest: {
        adCount: 2,
        onComplete: () => {
          const urlsToCache = songs.flatMap(song => [song.src, song.album.cover.imageUrl]);
          cacheUrls(urlsToCache);
          const newDownloadedSongs = new Set(state.downloadedSongs);
          songs.forEach(song => newDownloadedSongs.add(song.id));
          setPlayerState({ downloadedSongs: newDownloadedSongs });
          toast({ title: "Album download started!", description: "Songs will be available offline shortly." });
        }
      }
    });
  };


  return (
    <MusicPlayerContext.Provider value={{ ...state, playSong, togglePlay, playNext, playPrev, toggleShuffle, toggleRepeat, toggleLike, isLiked, setPlayerState, seek, stopAndClearPlayer, downloadSong, downloadPlaylist, isDownloaded }}>
      {children}
      {state.isFullScreen && <NowPlaying />}
      {state.interstitialRequest && <InterstitialAd onClose={handleAdClose} adCount={state.interstitialRequest.adCount} />}
    </MusicPlayerContext.Provider>
  );
};

export const useMusicPlayer = (): MusicPlayerContextType => {
  const context = useContext(MusicPlayerContext);
  if (context === undefined) {
    throw new Error('useMusicPlayer must be used within a MusicPlayerProvider');
  }
  return context;
};
