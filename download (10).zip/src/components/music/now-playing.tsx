
'use client';

import Image from 'next/image';
import {
  ChevronDown,
  MoreVertical,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Shuffle,
  Repeat,
  Heart,
  Mic,
  ListMusic,
  Repeat1,
  Download,
  Wallet,
} from 'lucide-react';
import { useMusicPlayer } from './music-player-provider';
import { Slider } from '@/components/ui/slider';
import { formatTime, cn } from '@/lib/utils';
import { useMemo, useContext } from 'react';
import { motion, useAnimation } from 'framer-motion';
import { SupportDialog } from '../support-dialog';
import { AppContext } from '../app-shell';
import React from 'react';

const DRAG_THRESHOLD = 100;

export function NowPlaying() {
  const {
    currentSong,
    isPlaying,
    isShuffled,
    repeatMode,
    isLiked,
    togglePlay,
    playNext,
    playPrev,
    toggleShuffle,
    toggleRepeat,
    toggleLike,
    trackProgress,
    setPlayerState,
    seek,
    downloadSong,
    isDownloaded,
  } = useMusicPlayer();
  
  const controls = useAnimation();
  const appContext = useContext(AppContext);
  const currentUser = appContext?.currentUser;

  const duration = useMemo(() => {
    if (!currentSong) return 0;
    const [minutes, seconds] = currentSong.duration.split(':').map(Number);
    return minutes * 60 + seconds;
  }, [currentSong]);

  const currentTime = (trackProgress / 100) * duration;

  if (!currentSong || !currentUser) return null;

  const closeFullScreen = () => {
    setPlayerState({ isFullScreen: false });
  };
  
  const handleLike = () => {
    toggleLike(currentSong.id);
  }

  const onDragEnd = (event: any, info: any) => {
    if (info.offset.y > DRAG_THRESHOLD || info.velocity.y > 500) {
      closeFullScreen();
    } else {
      controls.start({ y: 0 });
    }
  };

  const handleDownload = () => {
    downloadSong(currentSong);
  }
  
  const canBeTipped = currentSong.artist.followers >= 10000;
  const isOwnSong = currentSong.artist.id === currentUser.id;

  return (
    <motion.div 
        className="fixed inset-0 z-50 bg-background flex flex-col cursor-grab active:cursor-grabbing"
        drag="y"
        dragConstraints={{ top: 0, bottom: 0 }}
        dragElastic={{ top: 0, bottom: 0.5 }}
        onDragEnd={onDragEnd}
        animate={controls}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
    >
        {/* Header */}
        <header className="flex items-center justify-between p-4 flex-shrink-0">
            <button onClick={closeFullScreen}>
                <ChevronDown className="h-6 w-6" />
            </button>
            <div className="text-center">
                <p className="text-sm text-muted-foreground">Playing from Album</p>
                <p className="font-semibold">{currentSong.album.title}</p>
            </div>
            <button>
                <MoreVertical className="h-6 w-6" />
            </button>
        </header>

        {/* Album Art */}
        <div className="flex-1 flex items-center justify-center px-8 min-h-0">
            <Image
                src={currentSong.album.cover.imageUrl}
                alt={currentSong.album.title}
                width={500}
                height={500}
                className="rounded-lg shadow-2xl aspect-square w-full h-auto max-h-full max-w-full object-cover"
            />
        </div>

        {/* Song Info & Actions */}
        <div className="px-6 pt-4 flex-shrink-0">
            <div className="flex items-center justify-between">
                <div className="flex-1 overflow-hidden">
                    <h2 className="text-2xl font-bold truncate">{currentSong.title}</h2>
                    <p className="text-muted-foreground truncate">{currentSong.artist.name}</p>
                </div>
                 <button className="p-2" onClick={handleLike}>
                    <Heart className={cn("h-6 w-6", isLiked(currentSong.id) && "fill-red-500 text-red-500")} />
                </button>
            </div>
        </div>

        {/* Progress Bar */}
         <div className="px-6 pt-4 flex-shrink-0">
            <Slider
                value={[trackProgress]}
                onValueChange={(value) => seek(value[0])}
                max={100}
                step={0.1}
            />
            <div className="flex justify-between text-xs text-muted-foreground mt-2">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
            </div>
        </div>

        {/* Playback Controls */}
        <div className="flex items-center justify-evenly p-4 flex-shrink-0">
             <button className={cn("p-2 rounded-full hover:bg-accent", isShuffled ? 'text-primary' : 'text-muted-foreground')} onClick={toggleShuffle}>
                <Shuffle className="h-6 w-6" />
            </button>
            <button onClick={playPrev} className="p-4 rounded-full hover:bg-accent">
                <SkipBack className="h-8 w-8" />
            </button>
            <button onClick={togglePlay} className="bg-primary text-primary-foreground rounded-full p-6 shadow-lg">
                {isPlaying ? <Pause className="h-10 w-10" /> : <Play className="h-10 w-10" />}
            </button>
             <button onClick={playNext} className="p-4 rounded-full hover:bg-accent">
                <SkipForward className="h-8 w-8" />
            </button>
             <button className={cn("p-2 rounded-full hover:bg-accent", repeatMode !== 'off' ? 'text-primary' : 'text-muted-foreground')} onClick={toggleRepeat}>
                {repeatMode === 'song' ? <Repeat1 className="h-6 w-6" /> : <Repeat className="h-6 w-6" />}
            </button>
        </div>
        
        {/* Footer actions */}
         <div className="flex items-center justify-between p-4 mb-4 flex-shrink-0">
            <button className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
                <Mic className="h-5 w-5"/> Lyrics
            </button>
             {canBeTipped && !isOwnSong && (
                <SupportDialog currentUser={currentUser} creator={currentSong.artist}>
                    <button className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
                        <Wallet className="h-5 w-5"/> Support
                    </button>
                </SupportDialog>
            )}
            <button onClick={handleDownload} disabled={isDownloaded(currentSong.id)} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground disabled:text-primary disabled:cursor-not-allowed">
                <Download className="h-5 w-5"/> {isDownloaded(currentSong.id) ? 'Downloaded' : 'Download'}
            </button>
            <button className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
                <ListMusic className="h-5 w-5"/> Queue
            </button>
        </div>
    </motion.div>
  );
}
