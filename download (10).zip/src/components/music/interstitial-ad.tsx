
'use client';

import * as React from 'react';
import { X } from 'lucide-react';
import { Button } from '../ui/button';
import { motion, AnimatePresence } from 'framer-motion';

const AD_DURATION = 15; // in seconds

interface InterstitialAdProps {
  adCount: number;
  onClose: () => void;
}

export function InterstitialAd({ adCount, onClose }: InterstitialAdProps) {
  const [currentAd, setCurrentAd] = React.useState(1);
  const [countdown, setCountdown] = React.useState(AD_DURATION);

  React.useEffect(() => {
    let timer: NodeJS.Timeout;
    if (countdown > 0) {
      timer = setTimeout(() => setCountdown(countdown - 1), 1000);
    } else {
      if (currentAd < adCount) {
        setCurrentAd(currentAd + 1);
        setCountdown(AD_DURATION);
      }
    }
    return () => clearTimeout(timer);
  }, [countdown, currentAd, adCount]);
  
  const showCloseButton = countdown === 0 && currentAd === adCount;

  return (
    <AnimatePresence>
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-black"
      >
        <div className="absolute top-4 right-4 z-10">
          {showCloseButton ? (
            <Button variant="ghost" size="icon" className="text-white bg-black/50 hover:bg-black/70" onClick={onClose}>
              <X className="h-6 w-6" />
            </Button>
          ) : (
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-black/50 text-white font-bold">
              {countdown}
            </div>
          )}
        </div>

        <AnimatePresence mode="wait">
            <motion.div
                key={currentAd}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.5 }}
                className="w-full h-full"
            >
                <video
                    src="https://storage.googleapis.com/static.a-studio.dev/videos/ad-placeholder.mp4"
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover"
                />
            </motion.div>
        </AnimatePresence>

        <div className="absolute bottom-4 left-4 text-white/70 text-xs">
          <p>Advertisement {currentAd} of {adCount}</p>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
