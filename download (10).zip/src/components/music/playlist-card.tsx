
'use client';

import Image from 'next/image';
import Link from 'next/link';
import { cn } from '@/lib/utils';
import { Playlist } from '@/lib/data';
import { PlayCircle } from 'lucide-react';
import React from 'react';

interface PlaylistCardProps {
  playlist: Playlist;
  className?: string;
}

export function PlaylistCard({ playlist, className }: PlaylistCardProps) {
  
  return (
    <Link href={`/music/playlist/${playlist.id}`}>
      <div className={cn("relative overflow-hidden rounded-lg group", className)}>
        <Image
          src={playlist.cover.imageUrl}
          alt={playlist.title}
          fill
          className="object-cover transition-transform group-hover:scale-105"
          data-ai-hint={playlist.cover.imageHint}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
        <div className="absolute inset-0 p-4 flex flex-col justify-end text-white">
          <h3 className="text-lg font-bold truncate">{playlist.title}</h3>
          <p className="text-xs text-white/80 truncate">{playlist.description}</p>
        </div>
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <PlayCircle className="w-12 h-12 text-white/80" />
          </div>
      </div>
    </Link>
  );
}
