'use client';

import Image from 'next/image';
import { MoreHorizontal, Play, Download, Check } from 'lucide-react';
import { useMusicPlayer } from './music-player-provider';
import type { Song } from '@/lib/data';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { VerifiedBadge } from '../verified-badge';

interface SongListItemProps {
  song: Song;
  playlist?: Song[];
  index: number;
}

export function SongListItem({ song, playlist, index }: SongListItemProps) {
  const { playSong, currentSong, isPlaying, downloadSong, isDownloaded } = useMusicPlayer();
  const isActive = currentSong?.id === song.id;
  const { toast } = useToast();

  const handlePlay = () => {
    playSong(song, playlist);
  };
  
  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    if(isDownloaded(song.id)) {
        toast({ title: 'Already downloaded', description: 'This song is already in your library for offline listening.' });
        return;
    }
    downloadSong(song);
  }

  return (
    <div className="flex items-center gap-4 p-2 rounded-md hover:bg-accent group">
      <div className="w-6 text-center text-muted-foreground font-mono text-sm">
        {isActive && isPlaying ? (
            <Play className="h-4 w-4 text-primary animate-pulse" />
        ) : (
            <span className="group-hover:hidden">{index + 1}</span>
        )}
        <button onClick={handlePlay} className="hidden group-hover:block">
            <Play className="h-4 w-4" />
        </button>
      </div>
      <div className="flex-1 overflow-hidden">
        <p className={cn("font-semibold truncate", isActive && "text-primary")}>
          {song.title}
        </p>
        <p className="text-sm text-muted-foreground truncate inline-flex items-center">
            {song.artist.name}
            <VerifiedBadge user={song.artist} />
        </p>
      </div>
      <div className="text-sm text-muted-foreground font-mono">{song.duration}</div>
      <div className="flex items-center">
        <button onClick={handleDownload} className={cn("p-2 text-muted-foreground hover:text-foreground", isDownloaded(song.id) && "text-primary")}>
            {isDownloaded(song.id) ? <Check className="h-5 w-5" /> : <Download className="h-5 w-5" />}
        </button>
        <button className="p-2 text-muted-foreground hover:text-foreground">
            <MoreHorizontal className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
}
