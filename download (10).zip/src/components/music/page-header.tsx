
export function PageHeader({ title, description }: { title: string, description: string }) {
    return (
        <header className="mb-6">
            <h1 className="font-headline text-4xl font-bold">{title}</h1>
            <p className="mt-2 text-lg text-muted-foreground">{description}</p>
        </header>
    )
}
