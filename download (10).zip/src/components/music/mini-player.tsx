
'use client';

import Image from 'next/image';
import {
  Play,
  Pause,
  SkipForward,
  Heart,
  X,
} from 'lucide-react';
import { useMusicPlayer } from './music-player-provider';
import { Progress } from '../ui/progress';
import { cn } from '@/lib/utils';
import { useIsMobile } from '@/hooks/use-mobile';
import { motion, useAnimation } from 'framer-motion';

const DRAG_THRESHOLD = 50;

interface MiniPlayerProps {
    variant?: 'top' | 'bottom';
}

export function MiniPlayer({ variant = 'bottom' }: MiniPlayerProps) {
  const {
    currentSong,
    isPlaying,
    isLiked,
    togglePlay,
    playNext,
    toggleLike,
    trackProgress,
    setPlayerState,
    stopAndClearPlayer,
  } = useMusicPlayer();
  
  const isMobile = useIsMobile();
  const controls = useAnimation();

  if (!currentSong) return null;

  const openFullScreenPlayer = () => {
    setPlayerState({ isFullScreen: true });
  };
  
  const handleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleLike(currentSong.id);
  }

  const onDragEnd = (event: any, info: any) => {
    const shouldOpen = info.velocity.y < -500 || info.point.y < -DRAG_THRESHOLD;
    if (shouldOpen) {
        openFullScreenPlayer();
    } else {
        controls.start({ y: 0 });
    }
  };

  const isTopVariant = variant === 'top' && isMobile;

  return (
    <motion.div
      className={cn(
        "fixed left-0 right-0 z-40 bg-background/95 backdrop-blur-sm cursor-grab active:cursor-grabbing",
        isTopVariant 
          ? "top-14 border-b h-20"
          : "bottom-16 border-t h-20 md:bottom-0 md:h-24", 
        !isMobile && "left-0"
      )}
      drag="y"
      dragConstraints={{ top: 0, bottom: 0 }}
      dragElastic={{ top: 0.8, bottom: 0 }}
      onDragEnd={onDragEnd}
      animate={controls}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      onClick={(e) => {
        // Only open full screen on non-button clicks
        if (e.target === e.currentTarget || (e.target as HTMLElement).closest('.player-content')) {
            openFullScreenPlayer();
        }
      }}
    >
      <div className="absolute top-1 left-1/2 -translate-x-1/2 w-8 h-1 bg-muted-foreground/50 rounded-full" />
      <div className="relative h-full">
        <div className="flex items-center h-full p-2 sm:p-4 gap-3">
          <div className="player-content flex items-center gap-3 flex-1 overflow-hidden">
             <Image
                src={currentSong.album.cover.imageUrl}
                alt={currentSong.album.title}
                width={isMobile ? 56 : 64}
                height={isMobile ? 56 : 64}
                className="rounded-md shrink-0"
              />
              <div className="flex-1 overflow-hidden">
                <p className="font-semibold truncate">{currentSong.title}</p>
                <p className="text-sm text-muted-foreground truncate">{currentSong.artist.name}</p>
              </div>
          </div>
          <div className="flex items-center gap-1 sm:gap-2 pr-2">
            <button onClick={handleLike} className="p-2 rounded-full hover:bg-accent">
                <Heart className={cn("h-6 w-6", isLiked(currentSong.id) && "fill-red-500 text-red-500")} />
            </button>
             <button onClick={(e) => {e.stopPropagation(); togglePlay();}} className="p-2 rounded-full hover:bg-accent">
                {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
            </button>
             <button onClick={(e) => {e.stopPropagation(); playNext();}} className="p-2 rounded-full hover:bg-accent hidden sm:block">
                <SkipForward className="h-6 w-6" />
            </button>
            <button onClick={(e) => {e.stopPropagation(); stopAndClearPlayer();}} className="p-2 rounded-full hover:bg-accent">
                <X className="h-6 w-6" />
            </button>
          </div>
        </div>
        <Progress value={trackProgress} className="absolute bottom-0 h-1 rounded-none"/>
      </div>
    </motion.div>
  );
}
