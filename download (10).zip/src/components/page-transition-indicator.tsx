
'use client';

import { usePathname, useSearchParams } from 'next/navigation';
import NProgress from 'nprogress';
import { useEffect } from 'react';

export function PageTransitionIndicator() {
  const pathname = usePathname();
  const searchParams = useSearchParams();

  useEffect(() => {
    NProgress.done();
  }, [pathname, searchParams]);

  useEffect(() => {
    // This effect should run only once to set up the global link listener.
    // The implementation of `patch` and `unpatch` ensures they are added and removed correctly.
    const handleAnchorClick = (event: MouseEvent) => {
      try {
        const targetUrl = (event.currentTarget as HTMLAnchorElement).href;
        const currentUrl = window.location.href;
        if (targetUrl !== currentUrl) {
          NProgress.start();
        }
      } catch (err) {
        // Fallback for when the href is not a valid URL
        NProgress.start();
      }
    };

    const handleMutation: MutationCallback = () => {
      const anchorElements = document.querySelectorAll('a');
      anchorElements.forEach((anchor) => {
        if (anchor.target === '_blank') return;
        
        // Use a data attribute to track if the listener is already attached
        if (!anchor.dataset.nprogressListener) {
          anchor.addEventListener('click', handleAnchorClick);
          anchor.dataset.nprogressListener = 'true';
        }
      });
    };

    const mutationObserver = new MutationObserver(handleMutation);
    
    // Defer the observation to prevent hydration errors
    const timeoutId = setTimeout(() => {
        mutationObserver.observe(document, { childList: true, subtree: true });
        // Initial pass
        handleMutation([]);
    }, 0);


    return () => {
        clearTimeout(timeoutId);
        mutationObserver.disconnect();
        // Clean up listeners on unmount
        document.querySelectorAll('a[data-nprogress-listener]').forEach(anchor => {
            anchor.removeEventListener('click', handleAnchorClick);
            delete anchor.dataset.nprogressListener;
        });
    };
  }, []);

  return null;
}
