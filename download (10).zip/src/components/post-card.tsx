

'use client';

import Image from 'next/image';
import Link from 'next/link';
import * as React from 'react';
import { Heart, MessageCircle, MoreHorizontal, Share2, Pin, Lock, Unlock, Gift, BarChart3, AlertTriangle, ShieldX, TrendingUp, Megaphone, Bookmark, Image as ImageIcon, Video, FileText, Loader2 } from 'lucide-react';
import type { Post, Poll, LinkPreview, ImagePlaceholder, User, PostReaction } from '@/lib/data';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardFooter } from '@/components/ui/card';
import { UserAvatar } from './user-avatar';
import { cn, formatNumber } from '@/lib/utils';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { Separator } from './ui/separator';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useToast } from '@/hooks/use-toast';
import { ImageLightbox } from './image-lightbox';
import { ShareDialog } from './share-dialog';
import { ReactionsDialog } from './reactions-dialog';
import { CommentsSheet } from './comments-sheet';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
import { isSuperAdmin, isUserVerified } from '@/lib/data';
import { GiftingDialog } from './gifting-dialog';
import { PostAnalyticsDialog } from './post-analytics-dialog';
import { BoostPostDialog } from './boost-post-dialog';
import { VerifiedBadge } from './verified-badge';
import { AppContext } from './app-shell';
import { updatePost } from '@/services/postService';
import { summarizePost } from '@/ai/flows/summarize-post';
import { Alert, AlertDescription } from './ui/alert';
import { LinkPreviewCard } from './link-preview-card';
import { canUserReceiveGifts } from '@/lib/monetization-rules';

const CONTENT_LENGTH_THRESHOLD = 250;

const renderContent = (content: string, isExpanded: boolean, onSummarize: () => void) => {
    const isLongPost = content.length > CONTENT_LENGTH_THRESHOLD;
    const textToRender = isExpanded || !isLongPost
        ? content
        : `${content.substring(0, CONTENT_LENGTH_THRESHOLD)}...`;
    
    const regex = /([#@][\w_]+)/g;
    const parts = textToRender.split(regex);

    return (
         <p className="mb-4 whitespace-pre-wrap">
            {parts.map((part, index) => {
                if (part.match(regex)) {
                    const isHashtag = part.startsWith('#');
                    const url = isHashtag ? `/search?q=${part.substring(1)}` : `/profile/${part.substring(1)}`;
                    return (
                        <Link key={index} href={url} className="text-primary hover:underline">
                            {part}
                        </Link>
                    );
                }
                return part;
            })}
             {isLongPost && !isExpanded && (
                <button 
                    onClick={() => onSummarize()} 
                    className="text-primary font-semibold ml-1 hover:underline"
                >
                    Summarize...
                </button>
            )}
        </p>
    );
};

const reactionOptions: { type: PostReaction['type']; emoji: string }[] = [
  { type: 'like', emoji: '❤️' },
  { type: 'funny', emoji: '😂' },
  { type: 'wow', emoji: '😮' },
  { type: 'sad', emoji: '😢' },
  { type: 'angry', emoji: '😠' },
];

export function PostCard({ post: initialPost, onBoostPost }: { post: Post, onBoostPost: () => void; }) {
  const [post, setPost] = React.useState(initialPost);
  const [isExpanded, setIsExpanded] = React.useState(false);
  const appContext = React.useContext(AppContext);
  const currentUser = appContext?.currentUser;

  const [summary, setSummary] = React.useState<string | null>(null);
  const [isSummarizing, setIsSummarizing] = React.useState(false);
  
  // Real-time listener is removed, component now manages its own state from initial props
  React.useEffect(() => {
    setPost(initialPost);
  }, [initialPost]);

  const [userReaction, setUserReaction] = React.useState<PostReaction['type'] | null>(() => {
    if (!currentUser) return null;
    const reaction = (post.reactions || []).find(r => r.user.id === currentUser.id);
    return reaction ? reaction.type : null;
  });


  const [lightboxImages, setLightboxImages] = React.useState<string[]>([]);
  const [lightboxStartIndex, setLightboxStartIndex] = React.useState(0);
  const [isLightboxOpen, setIsLightboxOpen] = React.useState(false);

  const [isUnlocked, setIsUnlocked] = React.useState(false);
  const [showUnlockDialog, setShowUnlockDialog] = React.useState(false);
  
  const longPressTimer = React.useRef<NodeJS.Timeout>();
  const isLongPress = React.useRef(false);
  const [isPopoverOpen, setIsPopoverOpen] = React.useState(false);
  
  const { toast } = useToast();
  
  if (!currentUser || !appContext) {
    return null; // Or a loading/error state
  }
  const { isFreeMode } = appContext;

  const isOwnPost = post.author.id === currentUser.id;
  const isLocked = post.unlockPrice && !isUnlocked && !isOwnPost;
  const hasBackground = post.background && post.background !== 'bg-white';
  const postUrl = typeof window !== 'undefined' ? `${window.location.origin}/post/${post.id}` : '';
  
  const [isSaved, setIsSaved] = React.useState(() => currentUser.savedPostIds?.includes(post.id) ?? false);

  const handleReaction = async (type: PostReaction['type']) => {
    const existingReaction = (post.reactions || []).find(r => r.user.id === currentUser.id);
    let newReactions: PostReaction[];

    // Optimistically update UI
    if (existingReaction && existingReaction.type === type) {
      newReactions = (post.reactions || []).filter(r => r.user.id !== currentUser.id);
      setUserReaction(null);
    } else {
      const otherReactions = (post.reactions || []).filter(r => r.user.id !== currentUser.id);
      newReactions = [...otherReactions, { user: currentUser, type }];
      setUserReaction(type);
    }
    
    const oldPostState = post;
    setPost(prevPost => ({ ...prevPost, reactions: newReactions }));

    try {
      await updatePost(post.id, { reactions: newReactions });
    } catch (error) {
      // Revert UI on error
      setPost(oldPostState);
      setUserReaction(existingReaction ? existingReaction.type : null);
      toast({
        variant: 'destructive',
        title: 'Could not save reaction.',
      });
    }

    setIsPopoverOpen(false);
  };
  
  const handleLikeClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isLongPress.current) {
        isLongPress.current = false;
        return;
    }
    handleReaction('like');
  };
  
  const handleLongPress = React.useCallback(() => {
    isLongPress.current = true;
    setIsPopoverOpen(true);
  }, []);

  const handlePointerDown = () => {
    isLongPress.current = false;
    longPressTimer.current = setTimeout(handleLongPress, 1000);
  };

  const handlePointerUp = () => {
    clearTimeout(longPressTimer.current);
  };

  const handleUnlock = () => {
    if (!post.unlockPrice) return;

    if (currentUser.gold >= post.unlockPrice) {
      const newBalance = currentUser.gold - post.unlockPrice;
      // In a real app, this would be a backend call
      appContext.setCurrentUser({ ...currentUser, gold: newBalance });
      // In a real app, creator balance would be updated via a cloud function for security
      
      setIsUnlocked(true);
      setShowUnlockDialog(false);
      toast({ title: 'Post Unlocked!', description: `${post.unlockPrice} 🪙 has been deducted from your balance.` });
    } else {
      toast({
        variant: 'destructive',
        title: 'Insufficient Gold',
        description: `You need ${post.unlockPrice} 🪙 to unlock this post.`,
        action: <Link href="/buy-currency"><Button variant="secondary">Buy Gold</Button></Link>
      });
      setShowUnlockDialog(false);
    }
  };

  const openLightbox = (images: ImagePlaceholder[], startIndex: number) => {
    setLightboxImages(images.map(img => img.imageUrl));
    setLightboxStartIndex(startIndex);
    setIsLightboxOpen(true);
  };
  const closeLightbox = () => setIsLightboxOpen(false);
  
  const postType = post.postType || 'standard';
  
  const reactions = post.reactions || [];
  
  const handleSavePost = () => {
    const wasSaved = isSaved;
    setIsSaved(!wasSaved);

    if (wasSaved) {
        currentUser.savedPostIds = currentUser.savedPostIds?.filter(id => id !== post.id);
        toast({ title: "Post removed from saved." });
    } else {
        currentUser.savedPostIds = [...(currentUser.savedPostIds || []), post.id];
        toast({ title: "Post saved!" });
    }
  }

  const handleSummarize = async () => {
      if (summary) {
          setIsExpanded(true);
          return;
      }
      setIsSummarizing(true);
      try {
          const result = await summarizePost({ postContent: post.content });
          setSummary(result.summary);
      } catch (error) {
          toast({ variant: 'destructive', title: 'Could not summarize post.' });
      } finally {
          setIsSummarizing(false);
      }
  };


  return (
    <>
      <ImageLightbox 
        isOpen={isLightboxOpen}
        images={lightboxImages}
        startIndex={lightboxStartIndex}
        onClose={closeLightbox}
        likeCount={reactions.filter(r => r.type === 'like').length}
        commentCount={post.comments.length}
        isLiked={userReaction === 'like'}
        onLike={() => handleReaction('like')}
        post={post}
        postUrl={postUrl}
      />
       <Dialog open={showUnlockDialog} onOpenChange={setShowUnlockDialog}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Unlock This Post</DialogTitle>
                    <DialogDescription>
                        This post is locked. To view the content, you need to unlock it for <strong>{post.unlockPrice} 🪙</strong>.
                        This amount will be deducted from your Gold balance.
                    </DialogDescription>
                </DialogHeader>
                <div className="text-sm text-muted-foreground">Your current balance: <span className="font-bold">{currentUser.gold} 🪙</span></div>
                <DialogFooter>
                    <Button variant="ghost" onClick={() => setShowUnlockDialog(false)}>Cancel</Button>
                    <Button onClick={handleUnlock}>Confirm & Unlock</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>

       <Card className={cn(
        "rounded-none border-x-0 border-t-0 shadow-none sm:rounded-xl sm:border relative",
        postType !== 'standard' && 'bg-transparent border-0 sm:border-0 sm:bg-card sm:border sm:rounded-xl',
      )}>
        {postType === 'profile_update' && post.images?.[0] ? (
             <div className="p-4">
                <CardHeader className="flex-row items-center gap-3 p-0 mb-4">
                    <Link href={`/profile/${post.author.username}`}>
                        <UserAvatar user={post.author} />
                    </Link>
                    <div className="flex-1">
                        <Link href={`/profile/${post.author.username}`} className="hover:underline">
                            <p className="font-semibold inline-flex items-center">
                                {post.author.name}
                                <VerifiedBadge user={post.author} />
                            </p>
                        </Link>
                        <p className="text-sm text-muted-foreground">updated their profile picture.</p>
                    </div>
                </CardHeader>

                <div className="-mx-4 sm:mx-0 sm:rounded-lg overflow-hidden border-y sm:border">
                     <div className="relative aspect-square w-full">
                        <Image
                            src={post.images[0].imageUrl}
                            alt="New profile picture"
                            fill
                            className="object-cover"
                            data-ai-hint={post.images[0].imageHint}
                        />
                    </div>
                </div>
                 <PostFooter post={post} reactions={reactions} onReaction={handleReaction} userReaction={userReaction} onLikeClick={handleLikeClick} onPointerDown={handlePointerDown} onPointerUp={handlePointerUp} postUrl={postUrl} isOwnPost={isOwnPost} onBoost={onBoostPost} onSave={handleSavePost} isSaved={isSaved} isPopoverOpen={isPopoverOpen} setIsPopoverOpen={setIsPopoverOpen} />
            </div>
        ) : postType === 'cover_update' && post.images?.[0] ? (
             <div className="p-4">
                <div className="flex items-center gap-3 text-sm text-muted-foreground mb-4">
                    <UserAvatar user={post.author}/>
                    <p>
                        <Link href={`/profile/${post.author.username}`} className="font-bold text-foreground hover:underline inline-flex items-center">
                            {post.author.name}
                            <VerifiedBadge user={post.author} />
                        </Link>
                        {' '}updated their cover photo.
                    </p>
                </div>
                <div className="relative aspect-video w-full rounded-lg overflow-hidden border">
                    {!isFreeMode ? (
                        <Image
                            src={post.images[0].imageUrl}
                            alt="New cover photo"
                            fill
                            className="object-cover"
                            data-ai-hint={post.images[0].imageHint}
                        />
                    ) : (
                         <div className="w-full h-full bg-muted flex items-center justify-center">
                            <ImageIcon className="w-16 h-16 text-muted-foreground"/>
                        </div>
                    )}
                </div>
                 <PostFooter post={post} reactions={reactions} onReaction={handleReaction} userReaction={userReaction} onLikeClick={handleLikeClick} onPointerDown={handlePointerDown} onPointerUp={handlePointerUp} postUrl={postUrl} isOwnPost={isOwnPost} onBoost={onBoostPost} onSave={handleSavePost} isSaved={isSaved} isPopoverOpen={isPopoverOpen} setIsPopoverOpen={setIsPopoverOpen} />
            </div>
        ) : hasBackground ? (
            <div
              className={cn(
                  'relative w-full flex flex-col justify-between p-4 sm:rounded-lg overflow-hidden min-h-[350px]',
                  post.background?.startsWith('bg-gradient') ? post.background : '',
              )}
              style={{ backgroundImage: post.background?.startsWith('https') ? `url(${post.background})` : undefined, backgroundSize: 'cover', backgroundPosition: 'center' }}
            >
              <div className="absolute inset-0 bg-black/20" />
              <header className="relative flex-row items-center gap-3 flex z-10">
                  <Link href={`/profile/${post.author.username}`}>
                      <UserAvatar user={post.author} />
                  </Link>
                  <div className="flex-1">
                    <Link href={`/profile/${post.author.username}`} className="hover:underline">
                      <p className={cn("font-semibold inline-flex items-center text-white/90")}>
                          {post.author.name}
                          <VerifiedBadge user={post.author} />
                          {post.coAuthors && post.coAuthors.length > 0 && (
                              <span className={cn("ml-1 font-normal text-white/70")}>
                                  with {post.coAuthors.map(author => author.name).join(', ')}
                              </span>
                          )}
                      </p>
                    </Link>
                    <p className={cn("text-xs text-white/70")}>{post.createdAt}</p>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className={cn("h-9 w-9 text-white/90 hover:bg-white/20 hover:text-white")}>
                          <MoreHorizontal className="h-5 w-5" />
                      </Button>
                    </DropdownMenuTrigger>
                     <DropdownMenuContent>
                        {isOwnPost ? (
                            <BoostPostDialog post={post} onBoost={onBoostPost} user={currentUser}>
                                <DropdownMenuItem onSelect={(e) => e.preventDefault()}>Boost Post</DropdownMenuItem>
                            </BoostPostDialog>
                        ) : (
                            <>
                                <DropdownMenuItem>Follow {post.author.name}</DropdownMenuItem>
                                <DropdownMenuItem>Mute post</DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem><ShieldX className="mr-2 h-4 w-4" /> Block user</DropdownMenuItem>
                                <DropdownMenuItem><AlertTriangle className="mr-2 h-4 w-4" /> Report post</DropdownMenuItem>
                            </>
                        )}
                    </DropdownMenuContent>
                  </DropdownMenu>
              </header>
              <div className="relative flex-1 flex items-center justify-center">
                <p className={cn("text-center text-2xl font-bold p-6 text-white drop-shadow-md")}>{post.content}</p>
              </div>
               <div className="relative z-10">
                <PostFooter post={post} reactions={reactions} onReaction={handleReaction} userReaction={userReaction} onLikeClick={handleLikeClick} onPointerDown={handlePointerDown} onPointerUp={handlePointerUp} postUrl={postUrl} isOwnPost={isOwnPost} isBackgroundPost onBoost={onBoostPost} onSave={handleSavePost} isSaved={isSaved} isPopoverOpen={isPopoverOpen} setIsPopoverOpen={setIsPopoverOpen} />
               </div>
            </div>
        ) : (
          <>
            <CardHeader className="flex-row items-center gap-3 p-4">
              <Link href={`/profile/${post.author.username}`}>
                  <UserAvatar user={post.author} />
              </Link>
              <div className="flex-1">
                <Link href={`/profile/${post.author.username}`} className="hover:underline">
                    <p className="font-semibold inline-flex items-center">
                      {post.author.name}
                      <VerifiedBadge user={post.author} />
                      {post.coAuthors && post.coAuthors.length > 0 && (
                          <span className="ml-1 font-normal text-muted-foreground">
                              with {post.coAuthors.map(author => author.name).join(', ')}
                          </span>
                      )}
                    </p>
                </Link>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <p>{post.createdAt}</p>
                  {post.isPinned && <Pin className="w-3 h-3" />}
                  {isOwnPost && post.isBoosted && <span className="text-primary font-bold flex items-center gap-1"><TrendingUp className="h-3 w-3"/>Boosted</span>}
                  {post.isSponsored && <Badge variant="secondary" className="gap-1 text-purple-600 border-purple-200"><Megaphone className="h-3 w-3"/>Sponsored</Badge>}
                </div>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-9 w-9">
                      <MoreHorizontal className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                    {isOwnPost ? (
                        <BoostPostDialog post={post} onBoost={onBoostPost} user={currentUser}>
                            <DropdownMenuItem onSelect={(e) => e.preventDefault()}>Boost Post</DropdownMenuItem>
                        </BoostPostDialog>
                    ) : (
                        <>
                            <DropdownMenuItem>Follow {post.author.name}</DropdownMenuItem>
                            <DropdownMenuItem>Mute post</DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem><ShieldX className="mr-2 h-4 w-4" /> Block user</DropdownMenuItem>
                            <DropdownMenuItem><AlertTriangle className="mr-2 h-4 w-4" /> Report post</DropdownMenuItem>
                        </>
                    )}
                </DropdownMenuContent>
              </DropdownMenu>
            </CardHeader>
            
            <CardContent className="px-4 pb-2 pt-0">
               {renderContent(post.content, isExpanded, handleSummarize)}

              {isSummarizing && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground my-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>AI is summarizing...</span>
                </div>
              )}

              {summary && !isExpanded && (
                  <Alert className="my-2">
                      <FileText className="h-4 w-4" />
                      <AlertDescription>
                          {summary}
                          <button onClick={() => setIsExpanded(true)} className="font-bold hover:underline ml-1">Read full post</button>
                      </AlertDescription>
                  </Alert>
              )}

              {post.video && (
                  <div className="relative -mx-4 sm:mx-0 sm:rounded-lg overflow-hidden border-y sm:border">
                      {isFreeMode ? (
                          <div className="aspect-video w-full bg-muted flex flex-col items-center justify-center text-center p-4">
                              <Video className="w-12 h-12 text-muted-foreground mb-2"/>
                              <p className="font-semibold">Turn off Free mode to see video</p>
                          </div>
                      ) : (
                          <video src={post.video} className="w-full" controls playsInline />
                      )}
                  </div>
              )}

              {post.images && post.images.length > 0 && (
                <div className="-mx-4 sm:mx-0 sm:rounded-lg overflow-hidden border-y sm:border">
                  {isFreeMode ? (
                      <div className="aspect-video w-full bg-muted flex flex-col items-center justify-center text-center p-4">
                          <ImageIcon className="w-12 h-12 text-muted-foreground mb-2"/>
                           <p className="font-semibold">Turn off Free mode to see photo</p>
                      </div>
                  ) : (
                    <ImageGrid images={post.images} onImageClick={(index) => openLightbox(post.images || [], index)} />
                  )}
                </div>
              )}

              {post.poll && (
                  <PollDisplay poll={post.poll} postId={post.id} />
              )}
              
              {post.linkPreview && (
                  isFreeMode ? (
                      <a href={post.linkPreview.url} target="_blank" rel="noopener noreferrer" className="mt-4 block rounded-lg border p-4 hover:bg-accent">
                          <p className="font-semibold">{post.linkPreview.title}</p>
                          <p className="text-sm text-primary hover:underline">{post.linkPreview.url}</p>
                      </a>
                  ) : (
                    <LinkPreviewCard preview={post.linkPreview} />
                  )
              )}
            </CardContent>

            <PostFooter post={post} reactions={reactions} onReaction={handleReaction} userReaction={userReaction} onLikeClick={handleLikeClick} onPointerDown={handlePointerDown} onPointerUp={handlePointerUp} postUrl={postUrl} isOwnPost={isOwnPost} onBoost={onBoostPost} onSave={handleSavePost} isSaved={isSaved} isPopoverOpen={isPopoverOpen} setIsPopoverOpen={setIsPopoverOpen} />
          </>
        )}
        {isLocked && !isFreeMode && (
            <div className="absolute inset-0 bg-background/80 backdrop-blur-md flex flex-col items-center justify-center text-center p-8">
                <Lock className="h-16 w-16 text-muted-foreground mb-4"/>
                <h3 className="text-xl font-bold">This post is locked</h3>
                <p className="text-muted-foreground">Unlock this post to view its content.</p>
                <Button className="mt-6" onClick={() => setShowUnlockDialog(true)}>
                    <Unlock className="mr-2 h-4 w-4"/>
                    Unlock for {post.unlockPrice} 🪙
                </Button>
            </div>
        )}
      </Card>
    </>
  );
}

function PostFooter({ post, reactions, onReaction, userReaction, onLikeClick, onPointerDown, onPointerUp, postUrl, isOwnPost, isBackgroundPost, onBoost, onSave, isSaved, isPopoverOpen, setIsPopoverOpen }: { post: Post, reactions: PostReaction[], onReaction: (type: PostReaction['type']) => void; userReaction: PostReaction['type'] | null, onLikeClick: (e: React.MouseEvent) => void; onPointerDown: () => void; onPointerUp: () => void; postUrl: string, isOwnPost: boolean, isBackgroundPost?: boolean, onBoost: () => void; onSave: () => void, isSaved: boolean; isPopoverOpen: boolean; setIsPopoverOpen: (open: boolean) => void; }) {
    const appContext = React.useContext(AppContext);
    if (!appContext) return null;
    const { currentUser } = appContext;
    
    const canGift = canUserReceiveGifts(post.author) && !isOwnPost;
    
    let gridCols = 'grid-cols-4';
    if (canGift && isOwnPost) gridCols = 'grid-cols-5';
    if (canGift && !isOwnPost) gridCols = 'grid-cols-5';
    if (!canGift && isOwnPost) gridCols = 'grid-cols-4';
    if (!canGift && !isOwnPost) gridCols = 'grid-cols-4';


    const getEmojiForReaction = (type: PostReaction['type']) => {
        return reactionOptions.find(r => r.type === type)?.emoji || '❤️';
    }

    const mainReaction = userReaction ? getEmojiForReaction(userReaction) : '❤️';
    const mainReactionComponent = userReaction ? <span className="text-lg">{mainReaction}</span> : <Heart className={cn("h-5 w-5", userReaction === 'like' && "fill-current text-red-500")} />;

    return (
        <CardFooter className="flex-col items-start gap-2 p-4 pt-2">
            <div className={cn("flex w-full items-center justify-between text-sm", isBackgroundPost ? "text-white/80" : "text-muted-foreground")}>
                <div className="flex items-center gap-1">
                    <ReactionsDialog post={post} reactions={reactions}>
                          <button className="flex items-center gap-1 hover:underline">
                              {reactions.length > 0 && (
                                <div className={cn("flex items-center -space-x-1")}>
                                    {[...new Set(reactions.map(r => r.type))].slice(0,3).map(type => (
                                        <div key={type} className={cn("p-0.5 rounded-full text-sm", isBackgroundPost ? 'bg-black/50' : 'bg-background')}>
                                            {getEmojiForReaction(type)}
                                        </div>
                                    ))}
                                </div>
                              )}
                              <span>{formatNumber(reactions.length)}</span>
                          </button>
                    </ReactionsDialog>
                </div>
                 <div className="flex items-center gap-4">
                    <CommentsSheet post={post} currentUser={currentUser!}>
                      <button className="hover:underline">{formatNumber(post.comments.length)} comments</button>
                    </CommentsSheet>
                    <ShareDialog post={post} postUrl={postUrl}>
                      <button className="hover:underline">{formatNumber(post.shares)} shares</button>
                    </ShareDialog>
                </div>
            </div>
            <Separator className={cn(isBackgroundPost ? "bg-white/20" : "")}/>
            <div className={cn("grid w-full", gridCols)}>
                  <Popover open={isPopoverOpen} onOpenChange={setIsPopoverOpen}>
                    <PopoverTrigger asChild>
                        <div 
                          className="w-full"
                          onPointerDown={onPointerDown} 
                          onPointerUp={onPointerUp} 
                          onContextMenu={(e) => e.preventDefault()}
                        >
                            <ActionButton onClick={onLikeClick} className={cn(userReaction && `text-primary`)}>
                               {mainReactionComponent}
                            </ActionButton>
                        </div>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-1 rounded-full">
                        <div className="flex gap-1">
                            {reactionOptions.map(r => (
                                <button key={r.type} onClick={() => onReaction(r.type)} className="text-2xl p-2 rounded-full hover:bg-accent transition-transform hover:scale-125">
                                    {r.emoji}
                                </button>
                            ))}
                        </div>
                    </PopoverContent>
                  </Popover>
                  <CommentsSheet post={post} currentUser={currentUser!}>
                    <div role="button" className="w-full">
                       <ActionButton icon={MessageCircle} />
                    </div>
                  </CommentsSheet>
                  {canGift && !isOwnPost && (
                     <GiftingDialog currentUser={currentUser!} creator={post.author}>
                        <div role="button" className="w-full">
                           <ActionButton icon={Gift} />
                        </div>
                    </GiftingDialog>
                  )}
                  {isOwnPost && (
                    <BoostPostDialog post={post} onBoost={onBoost} user={currentUser!}>
                        <div role="button" className="w-full">
                           <ActionButton icon={TrendingUp} />
                        </div>
                    </BoostPostDialog>
                  )}
                  <ShareDialog post={post} postUrl={postUrl}>
                    <div role="button" className="w-full">
                      <ActionButton icon={Share2} />
                    </div>
                  </ShareDialog>
                  <ActionButton icon={Bookmark} onClick={onSave} isSaved={isSaved} />
              </div>
        </CardFooter>
    );
}

function ImageGrid({ images, onImageClick }: { images: ImagePlaceholder[]; onImageClick: (index: number) => void; }) {
  const count = images.length;

  const renderImage = (image: ImagePlaceholder, index: number, className?: string) => (
    <button key={image.id} className={cn("relative w-full h-full", className)} onClick={() => onImageClick(index)}>
      <Image
        src={image.imageUrl}
        alt={image.description}
        fill
        className="object-cover hover:opacity-90 transition-opacity"
        data-ai-hint={image.imageHint}
      />
    </button>
  );

  if (count === 1) {
    return renderImage(images[0], 0, "aspect-video");
  }

  if (count === 2) {
    return (
      <div className="grid grid-cols-2 gap-0.5" style={{aspectRatio: '16/9'}}>
        {images.map((img, i) => renderImage(img, i))}
      </div>
    );
  }

  if (count === 3) {
    return (
       <div className="grid grid-rows-2 grid-cols-2 gap-0.5" style={{aspectRatio: '4/3'}}>
        {renderImage(images[0], 0, "row-span-2 col-span-1")}
        {renderImage(images[1], 1, "col-span-1 row-span-1")}
        {renderImage(images[2], 2, "col-span-1 row-span-1")}
      </div>
    );
  }

  if (count === 4) {
    return (
      <div className="grid grid-cols-2 grid-rows-2 gap-0.5" style={{aspectRatio: '1/1'}}>
        {images.slice(0, 4).map((img, i) => renderImage(img, i))}
      </div>
    );
  }

  // Layout for 5+ images
  if (count >= 5) {
      return (
        <div className="grid grid-cols-2 grid-rows-2 gap-0.5" style={{ aspectRatio: '1/1' }}>
            {renderImage(images[0], 0)}
            {renderImage(images[1], 1)}
            {renderImage(images[2], 2)}
            <div className="relative">
                {renderImage(images[3], 3)}
                <button className="absolute inset-0 bg-black/50 flex items-center justify-center text-white text-2xl font-bold cursor-pointer" onClick={() => onImageClick(3)}>
                    +{count - 4}
                </button>
            </div>
        </div>
      )
  }

  return null;
}


function PollDisplay({ poll, postId }: { poll: Poll; postId: string }) {
  const [selectedOption, setSelectedOption] = React.useState<string | null>(null);
  const [voted, setVoted] = React.useState(false);
  const totalVotes = poll.totalVotes + (voted ? 1 : 0);

  const handleVote = () => {
    if (selectedOption) {
      setVoted(true);
    }
  };

  const handleOptionChange = (value: string) => {
    setSelectedOption(value);
  };

  return (
    <div className="mt-4 rounded-lg border p-4">
      <h3 className="font-semibold">{poll.question}</h3>
      <RadioGroup
        value={selectedOption || undefined}
        onValueChange={handleOptionChange}
        className="mt-3 space-y-2"
        disabled={voted}
      >
        {poll.options.map((option, index) => {
          const isSelected = selectedOption === option.text;
          const voteCount = option.votes + (voted && isSelected ? 1 : 0);
          const percentage = totalVotes > 0 ? Math.round((voteCount / totalVotes) * 100) : 0;
          
          return (
            <div key={index}>
              {voted ? (
                <div className="flex items-center justify-between text-sm">
                  <p className={cn(isSelected && 'font-bold')}>{option.text}</p>
                  <p className={cn(isSelected && 'font-bold')}>{percentage}%</p>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value={option.text} id={`poll-option-${postId}-${index}`} />
                  <Label htmlFor={`poll-option-${postId}-${index}`} className="flex-1 cursor-pointer">{option.text}</Label>
                </div>
              )}
              {voted && (
                <div className="relative mt-1 h-2 rounded-full bg-secondary">
                  <div
                    className="absolute h-2 rounded-full bg-primary"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              )}
            </div>
          );
        })}
      </RadioGroup>
      <div className="mt-4 text-xs text-muted-foreground">
        <p>{totalVotes} votes</p>
      </div>
       {!voted && (
        <Button onClick={handleVote} className="mt-3 w-full" disabled={!selectedOption}>
          Vote
        </Button>
      )}
       {voted && (
        <Button variant="outline" onClick={() => {setVoted(false); setSelectedOption(null);}} className="mt-3 w-full" >
          Change Vote
        </Button>
      )}
    </div>
  );
}


function ActionButton({ icon: Icon, isSaved, children, ...props }: { icon?: React.ElementType, children?: React.ReactNode, isSaved?: boolean } & React.ComponentProps<typeof Button>) {
  const isToggled = isSaved !== undefined ? isSaved : false;
  return (
    <Button 
      variant="ghost" 
      className={cn(
        "w-full text-muted-foreground hover:text-foreground",
        (props.className || '').includes('text-primary') && 'text-primary font-bold',
         isToggled && "text-primary font-bold"
      )}
      {...props}
    >
      {Icon && <Icon className={cn("h-5 w-5", isToggled && "fill-current")} />}
      {children}
    </Button>
  );
}
