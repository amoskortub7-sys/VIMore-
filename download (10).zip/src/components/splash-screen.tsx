'use client';

import { VIMoreLogo } from './icons/logo';
import { motion, AnimatePresence } from 'framer-motion';
import * as React from 'react';

interface SplashScreenProps {
  isFinished: boolean;
  onExitComplete?: () => void;
}

export function SplashScreen({ isFinished, onExitComplete }: SplashScreenProps) {
  const containerVariants = {
    initial: { opacity: 1 },
    exit: { opacity: 0, transition: { duration: 0.5, delay: 0.8 } },
  };

  const contentVariants = {
    initial: { opacity: 0 },
    animate: { 
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.1,
      }
    },
    exit: {
      scale: 10,
      opacity: 0,
      transition: { duration: 0.8, ease: 'easeIn' },
    },
  };
  
  const childVariants = {
    initial: { y: 20, opacity: 0 },
    animate: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5, ease: "easeOut" },
    },
  };

  const dotContainerVariants = {
    initial: {},
    animate: {
      transition: {
        staggerChildren: 0.15,
      },
    },
  };

  const dotVariants = {
    initial: {
      backgroundColor: 'hsl(var(--muted-foreground) / 0.5)',
      scale: 0.8,
    },
    animate: {
      backgroundColor: 'hsl(var(--primary))',
      scale: 1,
      transition: { duration: 0.3 },
    },
  };
  
  const footerVariants = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0, transition: { duration: 0.5, delay: 0.5 } },
    exit: { opacity: 0, y: 20, transition: { duration: 0.3 } },
  };

  return (
    <AnimatePresence onExitComplete={onExitComplete}>
      {!isFinished && (
        <motion.div
          key="splash"
          variants={containerVariants}
          initial="initial"
          exit="exit"
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-background"
        >
          <motion.div
            variants={contentVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            className="flex flex-col items-center justify-center gap-4"
          >
            <motion.div variants={childVariants}>
              <VIMoreLogo className="h-24 w-24" />
            </motion.div>

            <motion.div variants={childVariants}>
              <h1 className="font-headline text-5xl font-bold tracking-tighter text-primary">
                VIMore
              </h1>
            </motion.div>

            <motion.div
              className="flex gap-2"
              variants={dotContainerVariants}
            >
              {Array.from({ length: 5 }).map((_, i) => (
                <motion.div
                  key={i}
                  className="h-2.5 w-2.5 rounded-full"
                  variants={dotVariants}
                />
              ))}
            </motion.div>
          </motion.div>
          
          <motion.div 
            className="absolute bottom-10 text-sm text-muted-foreground"
            variants={footerVariants}
            initial="initial"
            animate="animate"
            exit="exit"
          >
            <p>From Media Tech Liberia</p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
