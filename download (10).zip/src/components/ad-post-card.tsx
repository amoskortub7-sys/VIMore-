
'use client';

import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Button } from './ui/button';
import { UserAvatar } from './user-avatar';
import { MoreHorizontal } from 'lucide-react';
import Image from 'next/image';

export function AdPostCard() {
  return (
    <Card className="rounded-none border-x-0 border-t-0 shadow-none sm:rounded-xl sm:border">
      <CardHeader className="flex-row items-center gap-3 p-4">
        <UserAvatar user={{
            id: 'ad-user',
            name: 'Sponsored Content',
            username: 'sponsored',
            avatar: { id: 'ad-avatar', imageUrl: 'https://picsum.photos/seed/ad-avatar/40/40', description: 'Ad Avatar', imageHint: 'advertisement logo' },
            coverPhoto: { id: 'ad-cover', imageUrl: '', description: '', imageHint: '' },
            bio: '',
            role: 'user',
            followers: 0,
            following: 0,
            gold: 0,
            diamonds: 0,
            createdAt: new Date(),
        }} className="h-10 w-10" />
        <div className="flex-1">
          <p className="font-semibold">Sponsored Content</p>
          <p className="text-xs text-muted-foreground">Promoted</p>
        </div>
        <Button variant="ghost" size="icon" className="h-9 w-9">
          <MoreHorizontal className="h-5 w-5" />
        </Button>
      </CardHeader>
      <CardContent className="px-4 pb-2 pt-0">
        <p className="mb-4">
          This is a sample ad. Your product or service could be featured here, reaching thousands of engaged users.
        </p>
        <div className="relative -mx-4 sm:mx-0 sm:rounded-lg overflow-hidden border-y sm:border">
          <Image
            src="https://picsum.photos/seed/ad-image/600/400"
            alt="Advertisement Image"
            width={600}
            height={400}
            className="w-full object-cover"
          />
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-2">
        <Button className="w-full" asChild>
            <a href="#" target="_blank" rel="noopener noreferrer">Learn More</a>
        </Button>
      </CardFooter>
    </Card>
  );
}
