import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent, CardHeader, CardFooter } from '@/components/ui/card';

export function PostCardSkeleton() {
  return (
    <Card className="rounded-none border-x-0 border-t-0 shadow-none sm:rounded-xl sm:border">
      <CardHeader className="flex-row items-center gap-3 p-4">
        <Skeleton className="h-10 w-10 rounded-full" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-3 w-24" />
        </div>
        <Skeleton className="h-9 w-9" />
      </CardHeader>
      <CardContent className="px-4 pb-2 pt-0 space-y-2">
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-5/6" />
      </CardContent>
      <CardContent className="px-4 pb-2 pt-2">
        <Skeleton className="aspect-video w-full" />
      </CardContent>
      <CardFooter className="flex-col items-start gap-2 p-4 pt-2">
        <div className="flex w-full items-center justify-between">
            <Skeleton className="h-5 w-16" />
            <Skeleton className="h-5 w-32" />
        </div>
        <Skeleton className="h-px w-full" />
        <div className="grid w-full grid-cols-3">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
        </div>
      </CardFooter>
    </Card>
  );
}
