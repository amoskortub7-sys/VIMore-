
'use client';

import * as React from 'react';
import Link from 'next/link';
import { Diamond, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
  DialogDescription,
} from '@/components/ui/dialog';
import { User } from '@/lib/data';
import { useToast } from '@/hooks/use-toast';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { purchaseVerification } from '@/ai/flows/purchase-verification';
import { AppContext } from './app-shell';

export function GetVerifiedDialog({ children }: { children: React.ReactNode }) {
  const { toast } = useToast();
  const appContext = React.useContext(AppContext);
  const [isOpen, setIsOpen] = React.useState(false);
  const [isPurchasing, setIsPurchasing] = React.useState(false);

  if (!appContext || !appContext.currentUser) {
    return <>{children}</>;
  }
  
  const { currentUser, setCurrentUser } = appContext;

  const isAlreadyVerified = !!currentUser.isVerified;
  const cost = currentUser.lastVerified ? 5 : 2;

  const handlePurchase = async () => {
    setIsPurchasing(true);
    try {
      const result = await purchaseVerification({ userId: currentUser.id });
      if (result.success) {
        // Update local user state
        setCurrentUser({ 
            ...currentUser, 
            diamonds: result.newBalance!, 
            isVerified: true, 
            lastVerified: new Date() 
        });
        toast({
          title: 'Verification Successful!',
          description: `You are now verified for one month. ${cost} 💎 has been deducted.`,
        });
        setIsOpen(false);
      } else {
        toast({
          variant: 'destructive',
          title: 'Verification Failed',
          description: result.message,
          action: result.message?.includes('Insufficient') ? <Link href="/buy-currency"><Button variant="secondary">Buy</Button></Link> : undefined
        });
      }
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error', description: 'Could not complete purchase.' });
    } finally {
      setIsPurchasing(false);
    }
  };
  
  if (isAlreadyVerified) {
    return (
        <Dialog>
            <DialogTrigger asChild>{children}</DialogTrigger>
            <DialogContent>
                 <DialogHeader>
                    <DialogTitle>You Are Verified</DialogTitle>
                    <DialogDescription>
                        Your verification badge is active. Your next renewal will be in approximately one month for 5 💎.
                    </DialogDescription>
                </DialogHeader>
            </DialogContent>
        </Dialog>
    )
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Get Verified</DialogTitle>
          <DialogDescription>
            Get the purple badge and show your authenticity to the community.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
            <div className="p-4 rounded-lg border bg-secondary">
                <p className="font-bold text-lg">First-Time Verification</p>
                <p className="text-sm text-muted-foreground">Get your first month for a special price.</p>
                <p className="text-3xl font-bold mt-2">2 💎</p>
            </div>
             <div className="p-4 rounded-lg border">
                <p className="font-bold text-lg">Monthly Renewal</p>
                <p className="text-sm text-muted-foreground">After your first month, verification renews automatically.</p>
                <p className="text-3xl font-bold mt-2">5 💎</p>
            </div>
             <Separator />
             <div className="text-sm text-muted-foreground">
                Your current balance: <span className="font-bold">{currentUser.diamonds} 💎</span>
            </div>
        </div>
        <DialogFooter>
          <DialogClose asChild><Button variant="ghost" disabled={isPurchasing}>Cancel</Button></DialogClose>
          <Button onClick={handlePurchase} disabled={isPurchasing}>
            {isPurchasing && <Loader2 className="mr-2 h-4 w-4 animate-spin"/>}
            Agree & Purchase
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
