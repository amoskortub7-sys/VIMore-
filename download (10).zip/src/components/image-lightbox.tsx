
'use client';

import * as React from 'react';
import Image from 'next/image';
import { AnimatePresence, motion } from 'framer-motion';
import { X, Heart, MessageCircle, Share2, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from './ui/button';
import { cn } from '@/lib/utils';
import { formatNumber } from '@/lib/utils';
import { ShareDialog } from './share-dialog';
import { Post } from '@/lib/data';

interface ImageLightboxProps {
  isOpen: boolean;
  onClose: () => void;
  images: string[];
  startIndex?: number;
  imageHints?: string[];
  
  // Post-related props
  post?: Post;
  likeCount?: number;
  commentCount?: number;
  isLiked?: boolean;
  onLike?: () => void;
  onComment?: () => void;
  postUrl?: string;
}

export function ImageLightbox({ 
    isOpen, 
    onClose, 
    images, 
    startIndex = 0, 
    imageHints,
    post,
    likeCount,
    commentCount,
    isLiked,
    onLike,
    onComment,
    postUrl,
}: ImageLightboxProps) {
  const [currentIndex, setCurrentIndex] = React.useState(startIndex);

  React.useEffect(() => {
    if (isOpen) {
      setCurrentIndex(startIndex);
    }
  }, [isOpen, startIndex]);

  React.useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleEsc);
    return () => {
      window.removeEventListener('keydown', handleEsc);
    };
  }, [onClose]);
  
  if (!isOpen || !images || images.length === 0) {
    return null;
  }

  const currentImageUrl = images[currentIndex];
  const currentImageHint = imageHints?.[currentIndex];

  const goToPrevious = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex(prevIndex => (prevIndex > 0 ? prevIndex - 1 : prevIndex));
  };

  const goToNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex(prevIndex => (prevIndex < images.length - 1 ? prevIndex + 1 : prevIndex));
  };

  return (
    <AnimatePresence>
        {isOpen && (
            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm"
                onClick={onClose}
            >
                {/* Header */}
                <header className="absolute top-0 left-0 right-0 z-20 flex justify-end p-4">
                    <Button variant="ghost" size="icon" className="rounded-full text-white hover:bg-white/20 hover:text-white" onClick={onClose}>
                        <X className="h-6 w-6" />
                    </Button>
                </header>

                {/* Navigation */}
                {images.length > 1 && (
                    <>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="absolute left-4 top-1/2 -translate-y-1/2 z-20 h-12 w-12 rounded-full text-white hover:bg-white/20 hover:text-white disabled:hidden"
                            onClick={goToPrevious}
                            disabled={currentIndex === 0}
                        >
                            <ChevronLeft className="h-8 w-8" />
                        </Button>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="absolute right-4 top-1/2 -translate-y-1/2 z-20 h-12 w-12 rounded-full text-white hover:bg-white/20 hover:text-white disabled:hidden"
                            onClick={goToNext}
                            disabled={currentIndex === images.length - 1}
                        >
                            <ChevronRight className="h-8 w-8" />
                        </Button>
                    </>
                )}


                {/* Image */}
                <motion.div 
                    key={currentImageUrl}
                    className="relative w-[90vw] h-[80vh]"
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.95, opacity: 0 }}
                    transition={{ type: 'spring', damping: 20, stiffness: 200, duration: 0.1 }}
                    onClick={(e) => e.stopPropagation()} // Prevent closing when clicking on image
                >
                    <Image
                        src={currentImageUrl}
                        alt="Lightbox view"
                        fill
                        className="object-contain"
                        data-ai-hint={currentImageHint}
                    />
                </motion.div>


                {/* Footer Actions */}
                 <footer className="absolute bottom-0 left-0 right-0 z-20 flex justify-center p-6" onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center gap-4 rounded-full bg-black/50 p-3 backdrop-blur-sm text-white">
                        <Button variant="ghost" className={cn("rounded-full gap-2", isLiked && "text-red-500")} onClick={onLike}>
                            <Heart className={cn("h-6 w-6", isLiked && "fill-current")} />
                            <span>{likeCount !== undefined ? formatNumber(likeCount) : 'Like'}</span>
                        </Button>
                         <Button variant="ghost" className="rounded-full gap-2" onClick={onComment}>
                            <MessageCircle className="h-6 w-6"/>
                            <span>{commentCount !== undefined ? formatNumber(commentCount) : 'Comment'}</span>
                        </Button>
                        {postUrl && (
                            <ShareDialog post={post} postUrl={postUrl}>
                                <Button variant="ghost" className="rounded-full gap-2">
                                    <Share2 className="h-6 w-6"/>
                                    <span>Share</span>
                                </Button>
                            </ShareDialog>
                        )}
                    </div>
                </footer>
            </motion.div>
        )}
    </AnimatePresence>
  );
}
