

// This file is now primarily for type definitions.
// The actual config values will be fetched from Firestore.

type PaymentMethod = 'USD' | 'LD';

export interface CurrencyPackage {
  id: string;
  name: string;
  amount: number;
  prices: { currency: PaymentMethod; value: number; display: string }[];
  isVIP?: boolean;
  bonus?: string;
}

export let goldPackages: CurrencyPackage[] = [];
export let diamondPackages: CurrencyPackage[] = [];
export let conversionRates = {
  diamond: { USD: 0.5, LD: 100 },
  gold: { USD: 0.01, LD: 1.9 },
};
export const PLATFORM_FEE = 0.10; // 10%
