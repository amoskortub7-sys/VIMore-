
export type MobileMoneyAccount = {
  name: string;
  number: string;
};

export type PaymentDetails = {
  orange: MobileMoneyAccount;
  mtn: MobileMoneyAccount;
};

// This file is now primarily for type definitions.
// The data will be fetched from Firestore.
export let paymentDetails: PaymentDetails = {
  orange: {
    name: "",
    number: "",
  },
  mtn: {
    name: "",
    number: "",
  },
};
