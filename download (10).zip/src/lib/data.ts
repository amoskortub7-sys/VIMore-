
import type { ImagePlaceholder } from './placeholder-images';
import { PlaceHolderImages } from './placeholder-images';
import { Award, Users2, VideoIcon, MessageCircle, Repeat, Heart, Calendar, Crown, Star, Zap, Video, Users, ReceiptText, Bell } from 'lucide-react';

export const getImage = (id: string): ImagePlaceholder =>
  PlaceHolderImages.find((img) => img.id === id) ?? PlaceHolderImages[0];

export type User = {
  id: string;
  name: string;
  username: string;
  avatar: ImagePlaceholder;
  coverPhoto: ImagePlaceholder;
  bio: string;
  role: 'user' | 'artist';
  adminRole?: 'financial' | 'moderator';
  isSuperAdmin?: boolean;
  isVerified?: boolean;
  lastVerified?: Date;
  isOnline?: boolean;
  pronouns?: string;
  work?: string;
  education?: string;
  homeTown?: string;
  website?: string;
  relationshipStatus?: string;
  followers: number;
  following: number;
  followerIds?: string[];
  followingIds?: string[];
  highlights?: StoryHighlight[];
  gold: number;
  diamonds: number;
  subscriptions?: string[]; // Array of creator IDs
  savedPostIds?: string[];
  savedAlbumIds?: string[];
  savedPlaylistIds?: string[];
  creatorBalance?: { gold: number; diamonds: number; };
  createdAt: Date;
  // For tipping eligibility
  totalPlays?: number;
  totalDownloads?: number;
  // New fields
  dob?: Date;
  gender?: 'Male' | 'Female' | 'Other' | 'Prefer not to say';
  region?: string;
  interests?: string[];
  monthlyListeners?: number;
  savedAccounts?: SavedAccount[];
  blockedUserIds?: string[];
  likedSongIds?: string[];
};

export type Transaction = {
    id: string;
    userId: string;
    date: Date;
    package?: string; // For purchases
    currency?: 'gold' | 'diamond';
    amount?: number;
    price?: string;
    transactionCode?: string;
    status: 'Completed' | 'Pending' | 'Rejected';
    // For in-app transactions (gifts, tips, subs)
    type?: 'gift' | 'tip' | 'subscription' | 'unlock';
    fromUserId?: string;
    toUserId?: string;
    cost?: number; // Cost in gold or diamonds
};

export type SupportTicket = {
    id: string;
    user: User;
    subject: string;
    message: string;
    timestamp: Date;
    status: 'open' | 'in_progress' | 'resolved';
    response?: string;
    resolvedAt?: Date;
}

export type Earning = {
  id: string;
  type: 'gift' | 'unlock' | 'subscription' | 'tip';
  from: User;
  amount: number;
  currency: 'gold' | 'diamond';
  post?: Post;
  timestamp: Date;
};

export type Song = {
  id: string;
  title: string;
  artist: User; // Changed from Artist to User to access full user data
  album: Omit<Album, 'songs'>;
  duration: string; // "m:ss"
  src: string; // audio file source
  isUsableAsSound?: boolean;
  streams: number;
  downloads: number;
};

export type Album = {
  id: string;
  title: string;
  artist: User; // Changed from Artist to User
  cover: ImagePlaceholder;
  songs: Song[];
  streams: number;
};

export type Playlist = {
  id:string;
  title: string;
  description: string;
  cover: ImagePlaceholder;
  createdBy: string; // User ID
  songs: Song[];
};

export type StoryHighlight = {
  id: string;
  title: string;
  cover: ImagePlaceholder;
  pages: StoryPage[];
};

export type StoryPage = {
  id: string;
  image: ImagePlaceholder;
  video?: string;
  duration: number; // in seconds
};

export type Story = {
  id:string;
  user: User;
  pages: StoryPage[];
  createdAt: string;
}

export type Poll = {
  question: string;
  options: { text: string; votes: number }[];
  totalVotes: number;
}

export type LinkPreview = {
  url: string;
  title: string;
  description: string;
  image: ImagePlaceholder;
}

export type Comment = {
  id: string;
  author: User;
  content: string;
  createdAt: string;
};

export type PostReaction = {
  user: User;
  type: 'like' | 'angry' | 'sad' | 'funny' | 'wow';
}

export type Post = {
  id: string;
  postType?: 'standard' | 'profile_update' | 'cover_update';
  author: User;
  coAuthors?: User[];
  content: string;
  images?: ImagePlaceholder[];
  video?: string;
  song?: Song;
  poll?: Poll;
  background?: string;
  linkPreview?: LinkPreview;
  reactions?: PostReaction[];
  comments: Comment[];
  shares: number;
  createdAt: string;
  isPinned?: boolean;
  isBoosted?: boolean;
  isSponsored?: boolean;
  unlockPrice?: number; // In Gold
  // Add a flexible likedBy field for optimistic updates
  likedBy?: { userId: string, type: PostReaction['type'] }[];
};

export type MessageReaction = {
  userId: string;
  emoji: string;
};

export type VoiceMemo = {
  src: string;
  duration: number; // in seconds
};

export type Message = {
  id: string;
  sender: User;
  content: string;
  image?: ImagePlaceholder;
  voiceMemo?: VoiceMemo;
  poll?: Poll;
  timestamp: Date;
  status: 'sent' | 'delivered' | 'read';
  reactions: MessageReaction[];
};

export type ConversationTheme = {
  name: string;
  displayName: string;
  color: {
    primary: string;
    primaryForeground: string;
  };
  previewImage: string;
  backgroundImage?: string;
};

export type Conversation = {
  id: string;
  type: 'direct' | 'group';
  name?: string; // Group name
  avatar?: ImagePlaceholder; // Group avatar
  participants: User[];
  adminIds?: string[]; // For group chats
  messages: Message[];
  unreadCount: number;
  isPinned?: boolean;
  isMuted?: boolean;
  theme?: ConversationTheme;
  pinnedMessageId?: string | null;
  nicknames?: { [userId: string]: string };
};

type NewAlbumFeedItem = {
  id: string;
  type: 'new-album';
  user: User;
  album: Album;
  timestamp: string;
};

type NewPlaylistFeedItem = {
  id: string;
  type: 'new-playlist';
  user: User;
  playlist: Playlist;
  timestamp: string;
};

export type MusicFeedItem = NewAlbumFeedItem | NewPlaylistFeedItem;

export type CreatorAnalyticsData = {
    date: string;
    views: number;
    threeSecondViews: number;
    interactions: number;
    followerChange: number;
};

export type GuideArticleContent = {
    id: string;
    title: string;
    icon: React.ElementType;
    content: string;
}

export type TrendingItem = {
    id: string;
    type: 'sound' | 'hashtag';
    title: string;
    postsCount: number;
    url: string;
}

export type Challenge = {
  id: string;
  text: string;
  isCompleted: boolean;
};

export type Badge = {
  id: string;
  title: string;
  description: string;
  icon: React.ElementType;
  progress: number;
};

export type Gift = {
  id: string;
  name: string;
  icon: string; // Emoji
  price: number;
  currency: 'gold' | 'diamond';
}

export type PurchaseRequest = {
  id: string;
  user: User;
  transaction: Transaction;
  screenshot: string;
  timestamp: Date;
  status: 'pending' | 'approved' | 'rejected';
};

export type PayoutRequest = {
    id: string;
    user: User;
    amount: number;
    currency: 'USD' | 'LD';
    platformCurrency: 'gold' | 'diamond';
    provider: 'orange' | 'mtn';
    accountName: string;
    accountNumber: string;
    timestamp: Date;
    status: 'pending' | 'completed' | 'rejected' | 'processing' | 'cancelled';
};

export type MobileMoneyAccount = {
  name: string;
  number: string;
};

export type SavedAccount = {
    id: string;
    provider: 'orange' | 'mtn';
    name: string;
    accountNumber: string;
}

export type CurrencyPackage = {
  id: string;
  name: string;
  amount: number;
  prices: { currency: 'USD' | 'LD'; value: number; display: string }[];
  isVIP?: boolean;
  bonus?: string;
};

export type ConversionRates = {
    diamond: { USD: number, LD: number };
    gold: { USD: number, LD: number };
};



// --- Notification Types ---

type BaseNotification = {
  id: string;
  userId: string;
  timestamp: Date;
  read: boolean;
};

export type WelcomeNotification = BaseNotification & {
  type: 'welcome';
  title: string;
  body: string;
};

export type LikeNotification = BaseNotification & {
  type: 'like';
  user: User;
  post: Post;
};

export type CommentNotification = BaseNotification & {
  type: 'comment';
  user: User;
  post: Post;
  comment: string;
};

export type FollowNotification = BaseNotification & {
  type: 'follow';
  user: User;
};

export type MentionNotification = BaseNotification & {
  type: 'mention';
  user: User;
  post: Post;
};

export type NewReleaseNotification = BaseNotification & {
  type: 'new_release';
  artist: User; // Changed from Artist
  album: Album;
};

export type AppNotification =
  | WelcomeNotification
  | LikeNotification
  | CommentNotification
  | FollowNotification
  | MentionNotification
  | NewReleaseNotification;
  
// --- End Notification Types ---


export let allMockThemes: ConversationTheme[] = [
  { name: 'default', displayName: 'Default', color: { primary: 'hsl(var(--primary))', primaryForeground: 'hsl(var(--primary-foreground))' }, previewImage: 'https://picsum.photos/seed/default-theme/400/400' },
  { name: 'love', displayName: 'Love ❤️', color: { primary: '#e91e63', primaryForeground: '#ffffff' }, previewImage: 'https://picsum.photos/seed/love-theme/400/400' },
  { name: 'family', displayName: 'Family 👨‍👩‍👧‍👦', color: { primary: '#4caf50', primaryForeground: '#ffffff' }, previewImage: 'https://picsum.photos/seed/family-theme/400/400' },
  { name: 'best-friends', displayName: 'Best Friends 🤞', color: { primary: '#ff9800', primaryForeground: '#ffffff' }, previewImage: 'https://picsum.photos/seed/friends-theme/400/400' },
  { name: 'football', displayName: 'Football ⚽️', color: { primary: '#009688', primaryForeground: '#ffffff' }, previewImage: 'https://picsum.photos/seed/football-theme/400/400' },
  { name: 'city', displayName: 'City 🏙️', color: { primary: '#2196f3', primaryForeground: '#ffffff' }, previewImage: 'https://picsum.photos/seed/city-theme/400/400' },
  { name: 'royal', displayName: 'Royal 👑', color: { primary: '#673ab7', primaryForeground: '#ffffff' }, previewImage: 'https://picsum.photos/seed/royal-theme/400/400' },
  { name: 'basketball', displayName: 'Basketball 🏀', color: { primary: '#ff5722', primaryForeground: '#ffffff' }, previewImage: 'https://picsum.photos/seed/basketball-theme/400/400' },
];
