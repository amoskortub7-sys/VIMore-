
import type { User } from './data';

// Follower count requirements for various monetization features.
export const SUBSCRIPTION_ELIGIBILITY_FOLLOWERS = 50000;
export const CONTENT_LOCK_ELIGIBILITY_FOLLOWERS = 10000;
export const TIPPING_ELIGIBILITY_FOLLOWERS = 10000;
export const GIFTING_ELIGIBILITY_FOLLOWERS = 10000; // Standardized to match tipping

/**
 * Checks if a user is eligible to have subscribers.
 * @param user The user to check.
 * @returns True if the user has more than 50,000 followers.
 */
export function canUserReceiveSubscriptions(user: User): boolean {
  return user.followers > SUBSCRIPTION_ELIGIBILITY_FOLLOWERS;
}

/**
 * Checks if a user is eligible to lock their posts.
 * @param user The user to check.
 * @returns True if the user has more than 10,000 followers.
 */
export function canUserLockContent(user: User): boolean {
  return user.followers > CONTENT_LOCK_ELIGIBILITY_FOLLOWERS;
}

/**
 * Checks if a user is eligible to receive tips (via the "Support" button).
 * @param user The user to check.
 * @returns True if the user has 10,000 or more followers.
 */
export function canUserBeTipped(user: User): boolean {
  return user.followers >= TIPPING_ELIGIBILITY_FOLLOWERS;
}

/**
 * Checks if a user is eligible to receive gifts on their posts.
 * @param user The user to check.
 * @returns True if the user has 10,000 or more followers.
 */
export function canUserReceiveGifts(user: User): boolean {
  return user.followers >= GIFTING_ELIGIBILITY_FOLLOWERS;
}
