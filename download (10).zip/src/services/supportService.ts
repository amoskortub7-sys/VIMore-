'use server';

import { databases, ID } from '@/lib/appwrite';
import { Query } from 'appwrite';
import type { SupportTicket, User } from '@/lib/data';
import { getUser } from './userService';

const DATABASE_ID = process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID!;
const SUPPORT_TICKETS_COLLECTION_ID = process.env.NEXT_PUBLIC_APPWRITE_SUPPORT_TICKETS_COLLECTION_ID!;

const fromAppwrite = async (doc: any): Promise<SupportTicket> => {
    const { $id, $createdAt, ...data } = doc;
    const user = await getUser(data.user.id) as User; // User must exist for a ticket
    return {
        id: $id,
        ...data,
        user,
        timestamp: new Date($createdAt),
        resolvedAt: data.resolvedAt ? new Date(data.resolvedAt) : undefined,
    } as SupportTicket;
};


export async function getSupportTickets(status: 'open' | 'in_progress' | 'resolved' | 'all' = 'all'): Promise<SupportTicket[]> {
  const queries = status !== 'all' ? [Query.equal('status', status)] : [Query.orderDesc('$createdAt')];
  const response = await databases.listDocuments(DATABASE_ID, SUPPORT_TICKETS_COLLECTION_ID, queries);
  return Promise.all(response.documents.map(doc => fromAppwrite(doc)));
}

export async function createSupportTicket(ticket: Omit<SupportTicket, 'id' | 'timestamp' | 'status'>): Promise<string> {
    const ticketData = {
        ...ticket,
        user: { id: ticket.user.id, name: ticket.user.name, username: ticket.user.username }, // Snapshot user info
        status: 'open'
    };
    const doc = await databases.createDocument(DATABASE_ID, SUPPORT_TICKETS_COLLECTION_ID, ID.unique(), ticketData);
    return doc.$id;
}

export async function resolveSupportTicket(id: string, response: string): Promise<void> {
    await databases.updateDocument(DATABASE_ID, SUPPORT_TICKETS_COLLECTION_ID, id, {
        status: 'resolved',
        response: response,
        resolvedAt: new Date().toISOString()
    });
}
