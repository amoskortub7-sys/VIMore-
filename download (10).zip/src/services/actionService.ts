
// This file is now obsolete as the project has been migrated to Appwrite.
// The email verification and password reset flows are now handled directly
// in the components using the Appwrite SDK.
