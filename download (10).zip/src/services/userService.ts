
'use server';

import { databases, ID } from '@/lib/appwrite';
import { Query } from 'appwrite';
import type { User } from '@/lib/data';
import { uploadFile } from './storageService';
import { getImage } from '@/lib/data';

const DATABASE_ID = process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID!;
const USERS_COLLECTION_ID = process.env.NEXT_PUBLIC_APPWRITE_USERS_COLLECTION_ID!;

// Helper to convert Appwrite doc to User type
const fromAppwrite = (doc: any): User => {
    // Appwrite stores document ID as $id
    const { $id, $createdAt, $updatedAt, ...data } = doc;
    return {
        id: $id,
        ...data,
        createdAt: new Date($createdAt),
        // Handle other date fields if they exist
        lastVerified: data.lastVerified ? new Date(data.lastVerified) : undefined,
        dob: data.dob ? new Date(data.dob) : undefined,
    } as User;
}

export async function getUsers(): Promise<User[]> {
  try {
    const response = await databases.listDocuments(DATABASE_ID, USERS_COLLECTION_ID);
    return response.documents.map(doc => fromAppwrite(doc));
  } catch (error) {
    console.error("Failed to get users:", error);
    return [];
  }
}

export async function getUser(identifier: string, findBy: 'id' | 'username' = 'id'): Promise<User | null> {
    if (!identifier) return null;
    try {
        if (findBy === 'id') {
            const doc = await databases.getDocument(DATABASE_ID, USERS_COLLECTION_ID, identifier);
            return fromAppwrite(doc);
        } else {
            const response = await databases.listDocuments(DATABASE_ID, USERS_COLLECTION_ID, [
                Query.equal('username', identifier)
            ]);
            if (response.documents.length > 0) {
                return fromAppwrite(response.documents[0]);
            }
        }
    } catch (error) {
        // Appwrite throws an error if the document is not found, so we catch it and return null.
        console.warn(`Could not find user with ${findBy}: ${identifier}`, error);
        return null;
    }
    return null;
}

export async function createUserDocument(user: any, additionalData: Partial<User> = {}): Promise<User | null> {
    const userId = user.$id;
    try {
        const existingUser = await getUser(userId);
        if (existingUser) {
            return existingUser;
        }

        // Check if a super admin already exists
        const superAdminQuery = await databases.listDocuments(DATABASE_ID, USERS_COLLECTION_ID, [
            Query.equal('isSuperAdmin', true),
            Query.limit(1)
        ]);
        const isFirstUser = superAdminQuery.total === 0;

        const username = additionalData.username || user.name.toLowerCase().replace(/ /g, '') || `user${Date.now()}`;
        
        const userData = {
            name: additionalData.name || user.name || 'New User',
            username: username,
            email: user.email,
            emailVerified: user.emailVerification,
            followers: 0,
            following: 0,
            bio: `Welcome to my VIMore profile!`,
            avatar: user.photoURL ? { id: 'user-avatar', imageUrl: user.photoURL, description: 'User avatar', imageHint: 'profile picture' } : getImage('profile1'),
            coverPhoto: getImage('cover1'),
            role: 'user',
            gold: 100,
            diamonds: 5,
            savedPostIds: [],
            savedAlbumIds: [],
            savedPlaylistIds: [],
            likedSongIds: [],
            blockedUserIds: [],
            ...additionalData,
            isSuperAdmin: isFirstUser, // Set the flag for the first user
            isVerified: isFirstUser, // Also verify the super admin
        };
        
        // In Appwrite, we use the user's auth ID as the document ID
        await databases.createDocument(DATABASE_ID, USERS_COLLECTION_ID, userId, userData);

        const newUserDoc = await databases.getDocument(DATABASE_ID, USERS_COLLECTION_ID, userId);
        return fromAppwrite(newUserDoc);

    } catch (error) {
        console.error("Failed to create user document:", error);
        return null;
    }
}


export async function getFollowers(userId: string): Promise<User[]> {
    const user = await getUser(userId);
    if (!user || !user.followerIds || user.followerIds.length === 0) {
        return [];
    }
    const response = await databases.listDocuments(
        DATABASE_ID,
        USERS_COLLECTION_ID,
        [Query.equal('$id', user.followerIds)]
    );
    return response.documents.map(doc => fromAppwrite(doc));
}

export async function getFollowing(userId: string): Promise<User[]> {
    const user = await getUser(userId);
    if (!user || !user.followingIds || user.followingIds.length === 0) {
        return [];
    }
    const response = await databases.listDocuments(
        DATABASE_ID,
        USERS_COLLECTION_ID,
        [Query.equal('$id', user.followingIds)]
    );
    return response.documents.map(doc => fromAppwrite(doc));
}

export async function updateUser(
    userId: string, 
    data: Partial<User>, 
    avatarFile?: File | null, 
    coverFile?: File | null
): Promise<void> {
    const dataToUpdate: Record<string, any> = { ...data };

    if (avatarFile) {
        const avatarUrl = await uploadFile(avatarFile);
        dataToUpdate.avatar = { ...(data.avatar || { id: '', imageUrl: '', description: '', imageHint: '' }), imageUrl: avatarUrl };
    }

    if (coverFile) {
        const coverUrl = await uploadFile(coverFile);
        dataToUpdate.coverPhoto = { ...(data.coverPhoto || { id: '', imageUrl: '', description: '', imageHint: '' }), imageUrl: coverUrl };
    }
    
    // Remove fields that can't be updated directly or are handled by Appwrite
    delete dataToUpdate.id;
    delete dataToUpdate.createdAt;

    await databases.updateDocument(DATABASE_ID, USERS_COLLECTION_ID, userId, dataToUpdate);
}

export async function deleteUserAccount(userId: string): Promise<void> {
    await databases.deleteDocument(DATABASE_ID, USERS_COLLECTION_ID, userId);
    // In a real app, you would also need to delete the user from Appwrite Auth, likely via a server function.
}


export async function toggleFollow(currentUserId: string, targetUserId: string, isCurrentlyFollowing: boolean): Promise<void> {
    if (!currentUserId) throw new Error("Not authenticated");

    const currentUserDoc = await databases.getDocument(DATABASE_ID, USERS_COLLECTION_ID, currentUserId);
    const targetUserDoc = await databases.getDocument(DATABASE_ID, USERS_COLLECTION_ID, targetUserId);

    if (!currentUserDoc || !targetUserDoc) {
        throw new Error("User not found");
    }

    // Prepare arrays, defaulting to empty if they don't exist
    const currentUserFollowingIds: string[] = currentUserDoc.followingIds || [];
    const targetUserFollowerIds: string[] = targetUserDoc.followerIds || [];

    if (isCurrentlyFollowing) {
        // --- Unfollow logic ---
        const updatedFollowingIds = currentUserFollowingIds.filter(id => id !== targetUserId);
        const updatedFollowerIds = targetUserFollowerIds.filter(id => id !== currentUserId);

        await Promise.all([
            databases.updateDocument(DATABASE_ID, USERS_COLLECTION_ID, currentUserId, {
                followingIds: updatedFollowingIds,
                following: updatedFollowingIds.length,
            }),
            databases.updateDocument(DATABASE_ID, USERS_COLLECTION_ID, targetUserId, {
                followerIds: updatedFollowerIds,
                followers: updatedFollowerIds.length,
            })
        ]);
    } else {
        // --- Follow logic ---
        const updatedFollowingIds = [...currentUserFollowingIds, targetUserId];
        const updatedFollowerIds = [...targetUserFollowerIds, currentUserId];

        await Promise.all([
            databases.updateDocument(DATABASE_ID, USERS_COLLECTION_ID, currentUserId, {
                followingIds: updatedFollowingIds,
                following: updatedFollowingIds.length,
            }),
            databases.updateDocument(DATABASE_ID, USERS_COLLECTION_ID, targetUserId, {
                followerIds: updatedFollowerIds,
                followers: updatedFollowerIds.length,
            })
        ]);
    }
}

export async function toggleBlock(currentUserId: string, targetUserId: string, isCurrentlyBlocked: boolean): Promise<void> {
    if (!currentUserId) throw new Error("Not authenticated");

    const currentUserDoc = await databases.getDocument(DATABASE_ID, USERS_COLLECTION_ID, currentUserId);
    if (!currentUserDoc) throw new Error("Current user not found");

    const currentUserBlockedIds: string[] = currentUserDoc.blockedUserIds || [];

    let updatedBlockedIds: string[];

    if (isCurrentlyBlocked) {
        // Unblock
        updatedBlockedIds = currentUserBlockedIds.filter(id => id !== targetUserId);
    } else {
        // Block
        updatedBlockedIds = [...currentUserBlockedIds, targetUserId];
    }
    
    await databases.updateDocument(DATABASE_ID, USERS_COLLECTION_ID, currentUserId, {
        blockedUserIds: updatedBlockedIds,
    });
}

export async function getBlockedUsers(userId: string): Promise<User[]> {
    const user = await getUser(userId);
    if (!user || !user.blockedUserIds || user.blockedUserIds.length === 0) {
        return [];
    }
    const response = await databases.listDocuments(
        DATABASE_ID,
        USERS_COLLECTION_ID,
        [Query.equal('$id', user.blockedUserIds)]
    );
    return response.documents.map(fromAppwrite);
}

export async function getFriendSuggestions(userId: string, limit: number = 20): Promise<User[]> {
    const user = await getUser(userId);
    const followingIds = user?.followingIds || [];

    // Fetch a pool of potential suggestions
    const response = await databases.listDocuments(DATABASE_ID, USERS_COLLECTION_ID, [
        Query.orderDesc('$createdAt'),
        Query.limit(100), // Fetch a larger pool to filter from
    ]);
    
    // Filter out the current user and people they already follow
    const suggestions = response.documents
        .map(fromAppwrite)
        .filter(u => u.id !== userId && !followingIds.includes(u.id));

    return suggestions.slice(0, limit);
}
