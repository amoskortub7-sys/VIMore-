'use server';

import { databases, ID } from '@/lib/appwrite';
import { Query } from 'appwrite';
import type { User, WelcomeNotification, AppNotification } from '@/lib/data';
import { getUser } from './userService';

const DATABASE_ID = process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID!;
const NOTIFICATIONS_COLLECTION_ID = process.env.NEXT_PUBLIC_APPWRITE_NOTIFICATIONS_COLLECTION_ID!;


const welcomeTitle = "Your VIMore Adventure Begins! 🚀";
const welcomeBody = "Welcome to the VIMore family! We're thrilled to have you. Here's a quick quest to get you started:\n\n🧭 **Explore Your World:** Dive into the feed and see what's happening.\n✨ **Share Your Spark:** Create your first post—a photo, a video, or just your thoughts.\n🤝 **Build Your Crew:** Find and follow friends or discover amazing new creators.\n\nWant to learn more? Check out **How VIMore Works** from the application menu!\n\nReady to make your mark? Let's go!";


export async function createWelcomeNotification(userId: string): Promise<string> {
    
    const notificationData: Omit<WelcomeNotification, 'id' | 'timestamp' | 'read'> & { userId: string } = {
        type: 'welcome',
        userId: userId,
        title: welcomeTitle,
        body: welcomeBody,
        read: false,
    };
    
    const doc = await databases.createDocument(DATABASE_ID, NOTIFICATIONS_COLLECTION_ID, ID.unique(), notificationData);
    
    return doc.$id;
}


// Helper for mapping Appwrite doc to Notification type.
const fromAppwrite = async (doc: any): Promise<AppNotification | null> => {
    const { $id, $createdAt, ...data } = doc;
    const base = {
        id: $id,
        userId: data.userId,
        timestamp: new Date($createdAt),
        read: data.read,
        type: data.type
    };

    try {
        switch (data.type) {
            case 'like':
            case 'comment':
            case 'mention':
                const interactingUser = await getUser(data.user.id);
                if (!interactingUser) return null;
                return { ...base, ...data, user: interactingUser };
            case 'follow':
                const follower = await getUser(data.user.id);
                if (!follower) return null;
                return { ...base, ...data, user: follower };
            case 'new_release':
                const artist = await getUser(data.artist.id);
                if (!artist) return null;
                return { ...base, ...data, artist };
            case 'welcome':
                return { ...base, ...data } as WelcomeNotification;
            default:
                return null;
        }
    } catch (e) {
        console.error(`Failed to parse notification ${doc.$id}`, e);
        return null;
    }
}


export async function getNotifications(userId: string): Promise<AppNotification[]> {
    if (!userId) return [];
    
    const response = await databases.listDocuments(
        DATABASE_ID,
        NOTIFICATIONS_COLLECTION_ID,
        [
            Query.equal('userId', userId),
            Query.orderDesc('$createdAt')
        ]
    );

    const notifications = await Promise.all(response.documents.map(doc => fromAppwrite(doc)));
    return notifications.filter(n => n !== null) as AppNotification[];
}
