
'use server';

import { databases } from '@/lib/appwrite';
import { Query } from 'appwrite';
import type { User, Post, Song, Album } from '@/lib/data';

const DATABASE_ID = process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID!;
const USERS_COLLECTION_ID = process.env.NEXT_PUBLIC_APPWRITE_USERS_COLLECTION_ID!;
const POSTS_COLLECTION_ID = process.env.NEXT_PUBLIC_APPWRITE_POSTS_COLLECTION_ID!;
const SONGS_COLLECTION_ID = process.env.NEXT_PUBLIC_APPWRITE_SONGS_COLLECTION_ID!;
const ALBUMS_COLLECTION_ID = process.env.NEXT_PUBLIC_APPWRITE_ALBUMS_COLLECTION_ID!;

// Simplified 'fromAppwrite' converters for search results
const fromAppwriteUser = (doc: any): User => ({ id: doc.$id, ...doc } as User);
const fromAppwritePost = (doc: any): Post => ({ id: doc.$id, ...doc } as Post);
const fromAppwriteSong = (doc: any): Song => ({ id: doc.$id, ...doc } as Song);
const fromAppwriteAlbum = (doc: any): Album => ({ id: doc.$id, ...doc } as Album);

export async function searchAll(query: string): Promise<{
    users: User[];
    posts: Post[];
    songs: Song[];
    albums: Album[];
    artists: User[];
}> {
    if (!query) {
        return { users: [], posts: [], songs: [], albums: [], artists: [] };
    }

    const [usersRes, postsRes, songsRes, albumsRes, artistsRes] = await Promise.all([
        databases.listDocuments(DATABASE_ID, USERS_COLLECTION_ID, [Query.search('name', query)]),
        databases.listDocuments(DATABASE_ID, POSTS_COLLECTION_ID, [Query.search('content', query)]),
        databases.listDocuments(DATABASE_ID, SONGS_COLLECTION_ID, [Query.search('title', query)]),
        databases.listDocuments(DATABASE_ID, ALBUMS_COLLECTION_ID, [Query.search('title', query)]),
        databases.listDocuments(DATABASE_ID, USERS_COLLECTION_ID, [Query.search('name', query), Query.equal('role', 'artist')]),
    ]);

    return {
        users: usersRes.documents.map(fromAppwriteUser),
        posts: postsRes.documents.map(fromAppwritePost),
        songs: songsRes.documents.map(fromAppwriteSong),
        albums: albumsRes.documents.map(fromAppwriteAlbum),
        artists: artistsRes.documents.map(fromAppwriteUser),
    };
}
