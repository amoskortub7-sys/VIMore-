'use server';

import { databases, ID } from '@/lib/appwrite';
import { Query } from 'appwrite';
import type { CurrencyPackage, Transaction, PayoutRequest, PurchaseRequest, MobileMoneyAccount, ConversionRates, User, Earning } from '@/lib/data';
import { getUser } from './userService';

const DATABASE_ID = process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID!;
const USERS_COLLECTION_ID = process.env.NEXT_PUBLIC_APPWRITE_USERS_COLLECTION_ID!;
const APP_CONFIG_COLLECTION_ID = process.env.NEXT_PUBLIC_APPWRITE_APP_CONFIG_COLLECTION_ID!;
const PURCHASE_REQUESTS_COLLECTION_ID = process.env.NEXT_PUBLIC_APPWRITE_PURCHASE_REQUESTS_COLLECTION_ID!;
const PAYOUT_REQUESTS_COLLECTION_ID = process.env.NEXT_PUBLIC_APPWRITE_PAYOUT_REQUESTS_COLLECTION_ID!;
const TRANSACTIONS_COLLECTION_ID = process.env.NEXT_PUBLIC_APPWRITE_TRANSACTIONS_COLLECTION_ID!;


// --- Configuration Management ---

export async function getMonetizationConfig(): Promise<{ goldPackages: CurrencyPackage[], diamondPackages: CurrencyPackage[], conversionRates: ConversionRates, platformFee: number }> {
  // In Appwrite, config is often stored in a document with a specific ID.
  const doc = await databases.getDocument(DATABASE_ID, APP_CONFIG_COLLECTION_ID, 'monetization');
  return doc as any;
}

export async function updateMonetizationConfig(data: Partial<{ goldPackages: CurrencyPackage[], diamondPackages: CurrencyPackage[], conversionRates: ConversionRates, platformFee: number }>): Promise<void> {
  await databases.updateDocument(DATABASE_ID, APP_CONFIG_COLLECTION_ID, 'monetization', data);
}

export async function getPaymentDetails(): Promise<{ orange: MobileMoneyAccount; mtn: MobileMoneyAccount; momoPSB: MobileMoneyAccount; }> {
    const doc = await databases.getDocument(DATABASE_ID, APP_CONFIG_COLLECTION_ID, 'paymentDetails');
    return doc as any;
}

export async function updatePaymentDetails(details: { orange: MobileMoneyAccount; mtn: MobileMoneyAccount; momoPSB: MobileMoneyAccount; }): Promise<void> {
    await databases.updateDocument(DATABASE_ID, APP_CONFIG_COLLECTION_ID, 'paymentDetails', details);
}

// --- Purchase and Payout Requests ---
const requestFromAppwrite = async (doc: any): Promise<any> => {
    const { $id, $createdAt, ...data } = doc;
    const user = await getUser(data.user.id); // Fetch full user object
    return {
        id: $id,
        ...data,
        user,
        timestamp: new Date($createdAt),
    };
};


export async function getPurchaseRequests(status: 'pending' | 'approved' | 'rejected' | 'all' = 'all'): Promise<PurchaseRequest[]> {
  const queries = status !== 'all' ? [Query.equal('status', status)] : [];
  const response = await databases.listDocuments(DATABASE_ID, PURCHASE_REQUESTS_COLLECTION_ID, queries);
  return Promise.all(response.documents.map(doc => requestFromAppwrite(doc)));
}

export async function createPurchaseRequest(request: Omit<PurchaseRequest, 'id' | 'timestamp' | 'status'>): Promise<string> {
    const requestData = {
        ...request,
        user: { id: request.user.id, name: request.user.name, username: request.user.username }, // Store a snapshot
        status: 'pending'
    };
    const doc = await databases.createDocument(DATABASE_ID, PURCHASE_REQUESTS_COLLECTION_ID, ID.unique(), requestData);
    return doc.$id;
}

export async function updatePurchaseRequestStatus(id: string, status: 'approved' | 'rejected'): Promise<void> {
    await databases.updateDocument(DATABASE_ID, PURCHASE_REQUESTS_COLLECTION_ID, id, { status });
}


export async function getPayoutRequests(status: 'pending' | 'completed' | 'rejected' | 'all' = 'all'): Promise<PayoutRequest[]> {
  const queries = status !== 'all' ? [Query.equal('status', status)] : [];
  const response = await databases.listDocuments(DATABASE_ID, PAYOUT_REQUESTS_COLLECTION_ID, queries);
  return Promise.all(response.documents.map(doc => requestFromAppwrite(doc)));
}

export async function createPayoutRequest(request: Omit<PayoutRequest, 'id' | 'timestamp' | 'status' | 'finalAmount'>): Promise<string> {
    const user = await getUser(request.user.id);
    if (!user) throw new Error("User not found.");

    const balance = user.creatorBalance?.[request.platformCurrency] || 0;
    if (balance < request.amount) {
        throw new Error("Insufficient creator balance.");
    }

    const newBalance = balance - request.amount;
    await databases.updateDocument(DATABASE_ID, USERS_COLLECTION_ID, user.id, {
        creatorBalance: { ...user.creatorBalance, [request.platformCurrency]: newBalance }
    });

    const requestData = {
        ...request,
        user: { id: request.user.id, name: request.user.name, username: request.user.username },
        status: 'pending'
    };
    const doc = await databases.createDocument(DATABASE_ID, PAYOUT_REQUESTS_COLLECTION_ID, ID.unique(), requestData);
    return doc.$id;
}

export async function updatePayoutRequestStatus(id: string, status: 'completed' | 'rejected' | 'cancelled'): Promise<void> {
    await databases.updateDocument(DATABASE_ID, PAYOUT_REQUESTS_COLLECTION_ID, id, { status });
}


export async function getTransactions(userId?: string): Promise<Transaction[]> {
   const queries = userId ? [Query.equal('userId', userId), Query.orderDesc('$createdAt')] : [Query.orderDesc('$createdAt')];
   const response = await databases.listDocuments(DATABASE_ID, TRANSACTIONS_COLLECTION_ID, queries);
   return response.documents.map(doc => ({
      id: doc.$id,
      ...doc,
      date: new Date(doc.$createdAt),
   })) as Transaction[];
}

export async function getEarnings(userId: string): Promise<Earning[]> {
  if (!userId) return [];

  const response = await databases.listDocuments(DATABASE_ID, TRANSACTIONS_COLLECTION_ID, [
    Query.equal('toUserId', userId),
    Query.orderDesc('$createdAt'),
  ]);

  const earningsPromises = response.documents.map(async (doc): Promise<Earning | null> => {
    try {
      const fromUser = await getUser(doc.fromUserId);
      if (!fromUser) return null;

      return {
        id: doc.$id,
        type: doc.type,
        from: fromUser,
        amount: doc.cost, // 'cost' in transaction log is the amount transferred
        currency: doc.currency,
        timestamp: new Date(doc.$createdAt),
        // 'post' is optional and not currently logged, so we omit it
      };
    } catch (e) {
      console.error(`Failed to process earning for transaction ${doc.$id}`, e);
      return null;
    }
  });

  const earnings = await Promise.all(earningsPromises);
  return earnings.filter(e => e !== null) as Earning[];
}

export async function addTransaction(transaction: Omit<Transaction, 'id' | 'date'> & { userId: string }): Promise<string> {
    const doc = await databases.createDocument(DATABASE_ID, TRANSACTIONS_COLLECTION_ID, ID.unique(), transaction);
    return doc.$id;
}


export async function subscribeToCreator(currentUserId: string, creatorId: string, isCancelling: boolean): Promise<{ success: boolean; message: string; newBalance?: number; }> {
    if (!currentUserId) throw new Error("Not authenticated");

    const cost = 10;
    const user = await getUser(currentUserId);
    if (!user) throw new Error("Current user not found in database.");

    if (isCancelling) {
        const updatedSubs = (user.subscriptions || []).filter(id => id !== creatorId);
        await databases.updateDocument(DATABASE_ID, USERS_COLLECTION_ID, currentUserId, { subscriptions: updatedSubs });
        return { success: true, message: 'Subscription cancelled.' };
    } else {
        if ((user.diamonds || 0) < cost) {
            return { success: false, message: 'Insufficient funds.' };
        }
        
        const newBalance = user.diamonds - cost;
        const updatedSubs = [...(user.subscriptions || []), creatorId];
        await databases.updateDocument(DATABASE_ID, USERS_COLLECTION_ID, currentUserId, { diamonds: newBalance, subscriptions: updatedSubs });
        
        return { success: true, message: 'Subscription successful!', newBalance };
    }
}

export async function processCurrencyTransaction(input: { fromUserId: string, toUserId: string, amount: number, currency: 'gold' | 'diamond', type: 'gift' | 'tip' | 'subscription' | 'unlock'}) {
  const PLATFORM_FEE = 0.20;
  
  const sender = await getUser(input.fromUserId);
  const receiver = await getUser(input.toUserId);

  if (!sender) throw new Error('Sender not found.');
  if (!receiver) throw new Error('Receiver not found.');
  
  const currentBalance = sender[input.currency] || 0;
  if (currentBalance < input.amount) {
      return { success: false, message: 'Insufficient funds.' };
  }

  // Deduct from sender
  const newSenderBalance = currentBalance - input.amount;
  await databases.updateDocument(DATABASE_ID, USERS_COLLECTION_ID, input.fromUserId, { [input.currency]: newSenderBalance });

  // Add to receiver's creator balance
  const earnings = input.amount * (1 - PLATFORM_FEE);
  const currentCreatorBalance = receiver.creatorBalance?.[input.currency] || 0;
  const newCreatorBalance = currentCreatorBalance + earnings;
  
  await databases.updateDocument(DATABASE_ID, USERS_COLLECTION_ID, input.toUserId, {
    creatorBalance: { ...(receiver.creatorBalance || {}), [input.currency]: newCreatorBalance }
  });

  // Log transaction
  await databases.createDocument(DATABASE_ID, TRANSACTIONS_COLLECTION_ID, ID.unique(), {
    userId: input.fromUserId,
    type: input.type,
    fromUserId: input.fromUserId,
    toUserId: input.toUserId,
    cost: input.amount,
    currency: input.currency,
    status: 'Completed',
  });
    
  return { success: true, message: 'Transaction successful!', newBalance: newSenderBalance };
}

export async function executeVerificationPurchase(userId: string): Promise<{ success: boolean; message: string; newBalance?: number; }> {
    const user = await getUser(userId);
    if (!user) return { success: false, message: 'User not found.' };

    const cost = user.lastVerified ? 5 : 2; 

    if ((user.diamonds || 0) < cost) {
      return { success: false, message: `Insufficient Diamonds. You need ${cost} 💎.` };
    }

    const newBalance = user.diamonds - cost;

    await databases.updateDocument(DATABASE_ID, USERS_COLLECTION_ID, userId, {
      diamonds: newBalance,
      isVerified: true,
      lastVerified: new Date().toISOString(),
    });

    return { success: true, message: 'Verification successful!', newBalance };
}
