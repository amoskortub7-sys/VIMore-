
'use server';

import { databases, ID } from '@/lib/appwrite';
import { Query } from 'appwrite';
import type { Post, User } from '@/lib/data';
import { getUser } from './userService';

const DATABASE_ID = process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID!;
const POSTS_COLLECTION_ID = process.env.NEXT_PUBLIC_APPWRITE_POSTS_COLLECTION_ID!;

const fromAppwrite = (doc: any): Post => {
    const { $id, $createdAt, ...data } = doc;
    return {
        id: $id,
        ...data,
        createdAt: data.$createdAt ? new Date(data.$createdAt).toLocaleDateString() : 'Just now',
    } as Post;
}

export async function getPosts(authorId?: string): Promise<Post[]> {
    const queries = [Query.orderDesc('$createdAt')];
    if (authorId) {
        // Appwrite queries on nested objects require specific indexing
        // and a slightly different syntax. Assuming `author` is a JSON object.
        queries.push(Query.equal('author.id', authorId));
    }
    
    const response = await databases.listDocuments(DATABASE_ID, POSTS_COLLECTION_ID, queries);
    return response.documents.map(doc => fromAppwrite(doc));
}

export async function createPost(postData: Omit<Post, 'id' | 'createdAt' | 'shares' | 'comments' | 'reactions'>): Promise<string> {
    const docData = {
        ...postData,
        author: {
            id: postData.author.id,
            name: postData.author.name,
            username: postData.author.username,
            avatar: postData.author.avatar,
        },
        shares: 0,
        comments: [],
        reactions: [],
    };
    
    const response = await databases.createDocument(DATABASE_ID, POSTS_COLLECTION_ID, ID.unique(), docData);
    return response.$id;
}

export async function updatePost(postId: string, data: Partial<Post>): Promise<void> {
    await databases.updateDocument(DATABASE_ID, POSTS_COLLECTION_ID, postId, data);
}


export async function initiateBoost(input: { userId: string; postId: string; budget: number; }): Promise<{ success: boolean; message: string; }> {
    try {
        const user = await getUser(input.userId);
        if (!user) {
            throw new Error("User not found");
        }

        const isAdmin = user.isSuperAdmin || !!user.adminRole;

        // If the user is not an admin, deduct payment.
        if (!isAdmin) {
            const currentBalance = user.diamonds || 0;
            if (currentBalance < input.budget) {
                return { success: false, message: "Insufficient Diamonds for this boost budget." };
            }

            const newBalance = currentBalance - input.budget;
            await databases.updateDocument(DATABASE_ID, process.env.NEXT_PUBLIC_APPWRITE_USERS_COLLECTION_ID!, input.userId, { diamonds: newBalance });
        }

        // Admins get free boosts, non-admins have payment deducted above.
        // Now, set the post as boosted.
        await databases.updateDocument(DATABASE_ID, POSTS_COLLECTION_ID, input.postId, { isBoosted: true });

        return { success: true, message: "Boost initiated." };

    } catch (error: any) {
        console.error("Boost payment/setup failed:", error);
        throw new Error(error.message || 'An error occurred during payment processing.');
    }
}
