
'use server';

import { databases, ID } from '@/lib/appwrite';
import { Query } from 'appwrite';
import type { Album, Song, User, Playlist, MusicFeedItem } from '@/lib/data';
import { getFollowing, getUser } from './userService';

const DATABASE_ID = process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID!;
const USERS_COLLECTION_ID = process.env.NEXT_PUBLIC_APPWRITE_USERS_COLLECTION_ID!;
const SONGS_COLLECTION_ID = process.env.NEXT_PUBLIC_APPWRITE_SONGS_COLLECTION_ID!;
const ALBUMS_COLLECTION_ID = process.env.NEXT_PUBLIC_APPWRITE_ALBUMS_COLLECTION_ID!;
const PLAYLISTS_COLLECTION_ID = process.env.NEXT_PUBLIC_APPWRITE_PLAYLISTS_COLLECTION_ID!;

const fromAppwriteSong = (doc: any): Song => {
    const { $id, $createdAt, ...data } = doc;
    return {
        id: $id,
        ...data,
    } as Song;
};

const fromAppwriteAlbum = (doc: any): Album => {
    const { $id, $createdAt, ...data } = doc;
    return {
        id: $id,
        ...data,
    } as Album;
};

const fromAppwritePlaylist = (doc: any): Playlist => {
    const { $id, $createdAt, ...data } = doc;
    return {
        id: $id,
        ...data,
    } as Playlist;
};

export async function getSongs(limit: number = 50, sortBy: keyof Song = 'streams'): Promise<Song[]> {
    const response = await databases.listDocuments(DATABASE_ID, SONGS_COLLECTION_ID, [
        Query.limit(limit),
        Query.orderDesc(sortBy),
    ]);
    return response.documents.map(fromAppwriteSong);
}

export async function getAlbums(limit: number = 20, sortBy: '$createdAt' | 'streams' = '$createdAt'): Promise<Album[]> {
    const response = await databases.listDocuments(DATABASE_ID, ALBUMS_COLLECTION_ID, [
        Query.limit(limit),
        Query.orderDesc(sortBy),
    ]);
    return response.documents.map(fromAppwriteAlbum);
}

export async function getArtists(limit: number = 50, sortBy: 'monthlyListeners' = 'monthlyListeners'): Promise<User[]> {
    const response = await databases.listDocuments(DATABASE_ID, USERS_COLLECTION_ID, [
        Query.equal('role', 'artist'),
        Query.limit(limit),
        Query.orderDesc(sortBy),
    ]);
    // The user service's fromAppwrite can be used if it's compatible
    return response.documents as User[];
}

export async function getAlbumById(albumId: string): Promise<Album | null> {
    try {
        const doc = await databases.getDocument(DATABASE_ID, ALBUMS_COLLECTION_ID, albumId);
        // We need to fetch songs for the album
        const songsRes = await databases.listDocuments(DATABASE_ID, SONGS_COLLECTION_ID, [
            Query.equal('album.id', albumId)
        ]);
        const album = fromAppwriteAlbum(doc);
        album.songs = songsRes.documents.map(fromAppwriteSong);
        return album;
    } catch (error) {
        console.error(`Failed to get album ${albumId}`, error);
        return null;
    }
}

export async function getPlaylistById(playlistId: string): Promise<Playlist | null> {
    try {
        const doc = await databases.getDocument(DATABASE_ID, PLAYLISTS_COLLECTION_ID, playlistId);
        // Assuming songs are embedded in the playlist document based on data model
        return fromAppwritePlaylist(doc);
    } catch (error) {
        console.error(`Failed to get playlist ${playlistId}`, error);
        return null;
    }
}

export async function createAlbum(albumData: Omit<Album, 'id' | 'songs' | 'streams'>): Promise<string> {
    const docData = {
        ...albumData,
        artist: { // Store a snapshot of the artist
            id: albumData.artist.id,
            name: albumData.artist.name,
            username: albumData.artist.username,
        },
        streams: 0,
    };
    const doc = await databases.createDocument(DATABASE_ID, ALBUMS_COLLECTION_ID, ID.unique(), docData);
    return doc.$id;
}

export async function createSong(songData: Omit<Song, 'id' | 'streams' | 'downloads'>): Promise<string> {
    const docData = {
        ...songData,
        artist: {
            id: songData.artist.id,
            name: songData.artist.name,
            username: songData.artist.username,
        },
        album: { // Store a snapshot of album info
            id: songData.album.id,
            title: songData.album.title,
            cover: songData.album.cover,
        },
        streams: 0,
        downloads: 0,
    };
    const doc = await databases.createDocument(DATABASE_ID, SONGS_COLLECTION_ID, ID.unique(), docData);
    return doc.$id;
}

export async function getMusicFeedForUser(userId: string): Promise<MusicFeedItem[]> {
    if (!userId) return [];
    
    const following = await getFollowing(userId);
    const followingArtistIds = following.filter(u => u.role === 'artist').map(u => u.id);

    if (followingArtistIds.length === 0) {
        return [];
    }
    
    const albumDocs = await databases.listDocuments(DATABASE_ID, ALBUMS_COLLECTION_ID, [
        Query.equal('artist.id', followingArtistIds),
        Query.orderDesc('$createdAt'),
        Query.limit(25)
    ]);
    
    const albumFeedItems: MusicFeedItem[] = albumDocs.documents.map(doc => ({
        id: `album-${doc.$id}`,
        type: 'new-album',
        user: doc.artist,
        album: fromAppwriteAlbum(doc),
        timestamp: new Date(doc.$createdAt).toISOString(),
    }));
    
    // In a future version, we could also fetch and merge playlists.
    
    return albumFeedItems.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
}

export async function getSavedAlbums(userId: string): Promise<Album[]> {
    const user = await getUser(userId);
    if (!user?.savedAlbumIds || user.savedAlbumIds.length === 0) {
        return [];
    }
    const response = await databases.listDocuments(DATABASE_ID, ALBUMS_COLLECTION_ID, [
        Query.equal('$id', user.savedAlbumIds)
    ]);
    return response.documents.map(fromAppwriteAlbum);
}

export async function getSavedPlaylists(userId: string): Promise<Playlist[]> {
    const user = await getUser(userId);
    if (!user?.savedPlaylistIds || user.savedPlaylistIds.length === 0) {
        return [];
    }
    const response = await databases.listDocuments(DATABASE_ID, PLAYLISTS_COLLECTION_ID, [
        Query.equal('$id', user.savedPlaylistIds)
    ]);
    return response.documents.map(fromAppwritePlaylist);
}
